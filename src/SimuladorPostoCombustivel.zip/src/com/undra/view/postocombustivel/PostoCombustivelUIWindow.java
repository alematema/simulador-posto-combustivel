/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.postocombustivel;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.delegator.excpetion.DelegatorException;
import com.undra.view.interfaces.FadableAndRaisableUI;
import com.undra.menu.MenuNavigator;
import com.undra.menu.MyMenuBar;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.combustivel.bomba.excetion.BombaCombustivelException;
import com.undra.modelo.combustivel.reservatorio.exception.ReservatorioExeption;
import com.undra.modelo.contabilidade.Caixa;
import com.undra.modelo.contabilidade.exception.AbastecimentoException;
import com.undra.modelo.contabilidade.exception.CaixaException;
import com.undra.modelo.postocombustivel.PostoCombustivel;
import com.undra.modelo.postocombustivel.PostoGasolinaException;
import com.undra.modelo.recursoshumanos.Frentista;
import com.undra.modelo.recursoshumanos.exception.RecursosHumanosException;
import com.undra.view.mesaControleRemotoDasBombasCombustivelUI.MesaControleRemotoDasBombasUIWindow;
import com.undra.view.pistaDasBombas.PistaDasBombasUIWindow;
import com.undra.view.relatorios.RelatoriosFrentistasAbastecimentosUIWindow;
import com.undra.view.reservatorio.ReservatorioCombustiveisUIWindow;
import com.undra.view.turno.TurnoFrentistasUI;
import com.undra.view.turno.TurnoFrentistasUIImpl;
import com.undra.view.turno.TurnoFrentistasUIWindow;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JMenuBar;

/**
 * Window do posto de combustivel UI
 *
 * @author alexandre
 */
public class PostoCombustivelUIWindow extends JFrame implements FadableAndRaisableUI {

    private PostoCombustivel modelo;
    private UIDelegator uIDelegator;
    private JMenuBar mainMenuBar;

    private final MesaControleRemotoDasBombasUIWindow mesaControleRemotoDasBombasUIWindow;
    private final PistaDasBombasUIWindow pistaDasBombasUIWindow;
    private final ReservatorioCombustiveisUIWindow reservatorioCombustiveisUIWindow;
    private final RelatoriosFrentistasAbastecimentosUIWindow relatoriosFrentistasAbastecimentosUIWindow;
    private final TurnoFrentistasUI turnoFrentistasUIWindow;
    
    

    private ModelDelegator modelDelegator;

    private List<Frentista> modeloFrentistas;

    public PostoCombustivelUIWindow(PostoCombustivel modelo) {

        if (modelo == null) {
            throw new NullPointerException("O modelo não pode ser null ");
        }

        this.modelo = modelo;

        this.uIDelegator = modelo.getuIDelegator();
        this.modelDelegator = modelo.getModelDelegator();

        pistaDasBombasUIWindow = new PistaDasBombasUIWindow((List<BombaCombustivel>) modelo.getModeloPistaBombasCombustivel(), (List<Caixa>) modelo.getModeloCaixas(), modelo.getuIDelegator());
        pistaDasBombasUIWindow.configure();

        mesaControleRemotoDasBombasUIWindow = new MesaControleRemotoDasBombasUIWindow((List<BombaCombustivel>) modelo.getModeloPistaBombasCombustivel(), modelo.getuIDelegator());
        mesaControleRemotoDasBombasUIWindow.configure();

        relatoriosFrentistasAbastecimentosUIWindow = new RelatoriosFrentistasAbastecimentosUIWindow(uIDelegator);
        relatoriosFrentistasAbastecimentosUIWindow.configure();
        
        reservatorioCombustiveisUIWindow = new ReservatorioCombustiveisUIWindow(modelo.getReservatorio());
        reservatorioCombustiveisUIWindow.configure();
        
        turnoFrentistasUIWindow = new TurnoFrentistasUIWindow(modelDelegator, uIDelegator);
                

        modeloFrentistas = new ArrayList();

        Frentista f1 = new Frentista(1, "JOLIE", "91273490", "329074", "/imagens/jolie+.jpg",uIDelegator);
        Frentista f2 = new Frentista(2, "FACEBOOK", "908345", "92374095", "/imagens/facebook+.jpg",uIDelegator);
        Frentista f3 = new Frentista(3, "JOINHA", "298374980", "245297", "/imagens/joinha+.jpg",uIDelegator);
        Frentista f4 = new Frentista(4, "BONITO", "2349702198347", "7095732495", "/imagens/bonito+.jpg",uIDelegator);
        Frentista f5 = new Frentista(5, "VAMPIRO", "398274987", "9073495", "/imagens/vampiro+.jpg",uIDelegator);
        Frentista f6 = new Frentista(6, "PINTADA", "298374", "2908345", "/imagens/PINTADA+.jpg",uIDelegator);
        Frentista f7 = new Frentista(7, "ELLEN", "54636545", "3456", "/imagens/ellenRoche.jpg",uIDelegator);
        Frentista f8 = new Frentista(8, "CHRIS", "567", "E456", "/imagens/Chris.jpg",uIDelegator);

        modeloFrentistas.add(f1);
        modeloFrentistas.add(f2);
        modeloFrentistas.add(f3);
        modeloFrentistas.add(f4);
        modeloFrentistas.add(f5);
        modeloFrentistas.add(f6);
        modeloFrentistas.add(f7);
        modeloFrentistas.add(f8);

        try {
            
            modelo.admitirFuncionario(f1);
            modelo.admitirFuncionario(f2);
            modelo.admitirFuncionario(f3);
            modelo.admitirFuncionario(f4);
            modelo.admitirFuncionario(f5);
            modelo.admitirFuncionario(f6);
            modelo.admitirFuncionario(f7);
            modelo.admitirFuncionario(f8);
            
        } catch (RecursosHumanosException ex) {
            Logger.getLogger(PostoCombustivel.class.getName()).log(Level.SEVERE, null, ex);
        } catch (PostoGasolinaException ex) {
            Logger.getLogger(PostoCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
        }

//        modelo.setFrentistasNesteTurno(modeloFrentistas);
//        pistaDasBombasUIWindow.getPistaDasBombasUI().setModeloBancoFrentistasNesteTurno(modeloFrentistas);

        new Thread(() -> {
            
            //algumas quantidades de combustivel
            float[] quantidades = {10.63f, 80f, 75f, 70f, 40f, 55f, 75f, 20.78f, 78f, 60f, 20f, 7.89f, 5.21f, 89f, 32.43f, 67f, 10.5f, 21.67f, 45.67f, 11.67f, 12.5f, 13.5f};

            //os cumbustiveis deste posto de gasolina
            Combustivel[] combustiveis = {
                new Combustivel(Combustivel.GASOLINA, 2.99f, Combustivel.LITRO),
                new Combustivel(Combustivel.ETANOL, 1.99f, Combustivel.LITRO),
                new Combustivel(Combustivel.DIESEL, 3.69f, Combustivel.LITRO),
                new Combustivel(Combustivel.GNV, 1.69f, Combustivel.METRO_CUBICO)

            };

            SecureRandom myRandom = new SecureRandom();

            //Simula uma solicitação de abastecimento a cada alguns segundos
            //Tando o combustivel quando o valor quanto o frentista a realizar o abastecimento sao aleatoriamente escolhidos
            int i = 0;
            while (true) {

                Combustivel combustivel = combustiveis[myRandom.nextInt(4)];
                float quantidadeCombustivel = quantidades[myRandom.nextInt(quantidades.length)];


                if (true) {

                    try {

                        modelo.abastecer(combustivel, quantidadeCombustivel);

                        Thread.sleep(myRandom.nextInt(11 * 200));

                    } catch (InterruptedException ex) {
                        Logger.getLogger(PistaDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (PostoGasolinaException ex) {
                        Logger.getLogger(PostoCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (BombaCombustivelException ex) {
                        Logger.getLogger(PostoCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (ReservatorioExeption ex) {
                        Logger.getLogger(PostoCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (AbastecimentoException ex) {
                        Logger.getLogger(PostoCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (DelegatorException ex) {
                        Logger.getLogger(PostoCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (CaixaException ex) {
                        Logger.getLogger(PostoCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }else{
                    System.err.println("erro ao alocar frentista livre ou bomba livre");
                }

            }
        }).start();

    }

    public void configure() {

        addWindowListener(new WindowAdapter() {
            
            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }

        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setTitle("Início - SIMULADOR POSTO COMBUSTÍVEL");

        getContentPane().setBackground(new Color(35,87,253));

        setResizable(false);

        //sets frame's size to 1/4 screen area
        setSize(new Dimension(Toolkit.getDefaultToolkit().getScreenSize().width, Toolkit.getDefaultToolkit().getScreenSize().height));

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

        setUndecorated(true);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

    }

    private void placeComponentsAtFrame() {

        MenuNavigator.setUiDelegator(uIDelegator);
        
        MenuNavigator.registerUI(this);
        MenuNavigator.registerUI(mesaControleRemotoDasBombasUIWindow);
        MenuNavigator.registerUI(pistaDasBombasUIWindow);
        MenuNavigator.registerUI(reservatorioCombustiveisUIWindow);
        
        MenuNavigator.setFrom(this.getClass().getSimpleName());

        mainMenuBar = new MyMenuBar(uIDelegator, modelDelegator);
        MenuNavigator.registerMYMENUBAR((MyMenuBar) mainMenuBar);
        setJMenuBar(mainMenuBar);

        mainMenuBar = new MyMenuBar(uIDelegator, modelDelegator);
        MenuNavigator.registerMYMENUBAR((MyMenuBar) mainMenuBar);
        pistaDasBombasUIWindow.setJMenuBar(mainMenuBar);

        mainMenuBar = new MyMenuBar(uIDelegator, modelDelegator);
        MenuNavigator.registerMYMENUBAR((MyMenuBar) mainMenuBar);
        mesaControleRemotoDasBombasUIWindow.setJMenuBar(mainMenuBar);
        
        mainMenuBar = new MyMenuBar(uIDelegator, modelDelegator);
        MenuNavigator.registerMYMENUBAR((MyMenuBar) mainMenuBar); 
        reservatorioCombustiveisUIWindow.setJMenuBar(mainMenuBar);

    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }

    @Override
    public void fade() {

        new Thread(() -> {
            for (int i = 100; i > 1; i--) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(PostoCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            setVisible(false);
            transferFocus();
        }).start();

    }

    @Override
    public void raise() {
        setOpacity(0.11f);
        new Thread(() -> {
            float opacity1 = 1.0f;
            setVisible(true);
            for (int i = 0; i < 100; i++) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(PostoCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            requestFocus();
        }).start();

    }

    @Override
    public String toString() {
        return "PostoCombustivelUIWindow UI".toUpperCase();
    }

}
