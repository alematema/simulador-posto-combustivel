package com.undra.view.pistaDasBombas;

import com.undra.delegator.UIDelegator;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.combustivel.bomba.excetion.BombaCombustivelException;
import com.undra.modelo.contabilidade.Caixa;
import com.undra.modelo.recursoshumanos.Frentista;
import com.undra.modelo.recursoshumanos.TipoFuncioinario;
import com.undra.view.bombacombustivel.BombaCombustivelUI;
import com.undra.view.bombacombustivel.DisplayDigitalException;
import com.undra.view.caixa.CaixaUI;
import com.undra.view.frentistasnesteturno.BancoDeFrentistasNesteTurnoUI;
import com.undra.view.genericsliderwindow.JSliderGenericoUIWindow;
import com.undra.view.interfaces.UI;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;

/**
 * UI da pista das bombas do posto de combustível.
 *
 * @author alexandre
 */
public class PistaDasBombasUI extends JPanel implements UI {

    private final UIDelegator uIDelegator;

    private List<BombaCombustivel> modeloPistaDasBombas;
    private List<Frentista> modeloBancoFrentistasNesteTurno;
    private List<Caixa> modeloCaixas;
    private List<BombaCombustivelUI> listaBombaCombustivelUI;

    private BombaCombustivelUI bombaUI0;
    private BombaCombustivelUI bombaUI1;
    private BombaCombustivelUI bombaUI2;
    private BombaCombustivelUI bombaUI3;
    private BombaCombustivelUI bombaUI4;
    private BombaCombustivelUI bombaUI5;
    private BombaCombustivelUI bombaUI6;
    private BombaCombustivelUI bombaUI7;

    private CaixaUI caixaUI;

    private boolean luzAcesa = false;

    private BancoDeFrentistasNesteTurnoUI bancoDeFrentistasNesteTurnoUI;

    private JSliderGenericoUIWindow velocidadeDoCaixaSliderWindow;

    public PistaDasBombasUI(List<BombaCombustivel> modeloPistaDasBombas, List<Caixa> modeloCaixas, UIDelegator uIDelegator) throws BombaCombustivelException {

        this.uIDelegator = uIDelegator;

        if (modeloPistaDasBombas == null) {
            throw new BombaCombustivelException("O modelo da pista de bombas não pode ser null !!!");
        }

        if (modeloPistaDasBombas.size() != 8) {
            throw new BombaCombustivelException("O modelo da pista de bombas deve ter 8 bombas de combustível !!!");
        }

        this.modeloPistaDasBombas = modeloPistaDasBombas;
        this.modeloCaixas = modeloCaixas;

        modeloBancoFrentistasNesteTurno = new ArrayList();
        listaBombaCombustivelUI = new ArrayList();

        construirPistaDasBombas();

    }

    private void construirPistaDasBombas() {

        GridBagConstraints gridConstraints;

        setPreferredSize(new Dimension(Toolkit.getDefaultToolkit().getScreenSize().width, Toolkit.getDefaultToolkit().getScreenSize().height - 20));

        setLayout(new GridBagLayout());

        gridConstraints = new GridBagConstraints();

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(0, 0, 1, 15);

        try {
            bombaUI0 = new BombaCombustivelUI(modeloPistaDasBombas.get(0), uIDelegator);
            add(bombaUI0, gridConstraints);

        } catch (DisplayDigitalException ex) {
            Logger.getLogger(PistaDasBombasUI.class.getName()).log(Level.SEVERE, null, ex);
        }

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(1, 0, 0, 15);

        try {

            bombaUI1 = new BombaCombustivelUI(modeloPistaDasBombas.get(1), uIDelegator);
            add(bombaUI1, gridConstraints);

        } catch (DisplayDigitalException ex) {
            Logger.getLogger(PistaDasBombasUI.class.getName()).log(Level.SEVERE, null, ex);
        }

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(0, 15, 1, 15);

        try {
            bombaUI2 = new BombaCombustivelUI(modeloPistaDasBombas.get(2), uIDelegator);
            add(bombaUI2, gridConstraints);
        } catch (DisplayDigitalException ex) {
            Logger.getLogger(PistaDasBombasUI.class.getName()).log(Level.SEVERE, null, ex);
        }

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(1, 15, 0, 15);

        try {
            bombaUI3 = new BombaCombustivelUI(modeloPistaDasBombas.get(3), uIDelegator);
            add(bombaUI3, gridConstraints);
        } catch (DisplayDigitalException ex) {
            Logger.getLogger(PistaDasBombasUI.class.getName()).log(Level.SEVERE, null, ex);
        }

        gridConstraints.gridx = 2;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(0, 15, 1, 15);

        try {
            bombaUI4 = new BombaCombustivelUI(modeloPistaDasBombas.get(4), uIDelegator);
            add(bombaUI4, gridConstraints);
        } catch (DisplayDigitalException ex) {
            Logger.getLogger(PistaDasBombasUI.class.getName()).log(Level.SEVERE, null, ex);
        }

        gridConstraints.gridx = 2;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(1, 15, 0, 15);

        try {
            bombaUI5 = new BombaCombustivelUI(modeloPistaDasBombas.get(5), uIDelegator);
            add(bombaUI5, gridConstraints);
        } catch (DisplayDigitalException ex) {
            Logger.getLogger(PistaDasBombasUI.class.getName()).log(Level.SEVERE, null, ex);
        }

        gridConstraints.gridx = 3;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(0, 15, 1, 15);

        try {
            bombaUI6 = new BombaCombustivelUI(modeloPistaDasBombas.get(6), uIDelegator);
            add(bombaUI6, gridConstraints);
        } catch (DisplayDigitalException ex) {
            Logger.getLogger(PistaDasBombasUI.class.getName()).log(Level.SEVERE, null, ex);
        }

        gridConstraints.gridx = 3;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(1, 15, 0, 15);

        try {
            bombaUI7 = new BombaCombustivelUI(modeloPistaDasBombas.get(7), uIDelegator);
            add(bombaUI7, gridConstraints);
        } catch (DisplayDigitalException ex) {
            Logger.getLogger(PistaDasBombasUI.class.getName()).log(Level.SEVERE, null, ex);
        }

        gridConstraints.gridx = 4;
        gridConstraints.gridy = 0;
        gridConstraints.gridheight = 2;
        gridConstraints.insets = new Insets(0, 5, 250, 20);

        caixaUI = new CaixaUI(uIDelegator, modeloCaixas.get(0));

        add(caixaUI, gridConstraints);

        velocidadeDoCaixaSliderWindow = new JSliderGenericoUIWindow(caixaUI, "VELOCIDADE DO CAIXA");

        bancoDeFrentistasNesteTurnoUI = new BancoDeFrentistasNesteTurnoUI(modeloBancoFrentistasNesteTurno, uIDelegator);

        gridConstraints.gridx = 4;
        gridConstraints.gridy = 1;
        gridConstraints.gridheight = 2;
        gridConstraints.insets = new Insets(200, 5, 0, 20);

        add(bancoDeFrentistasNesteTurnoUI, gridConstraints);

        listaBombaCombustivelUI.add(bombaUI0);
        listaBombaCombustivelUI.add(bombaUI1);
        listaBombaCombustivelUI.add(bombaUI2);
        listaBombaCombustivelUI.add(bombaUI3);
        listaBombaCombustivelUI.add(bombaUI4);
        listaBombaCombustivelUI.add(bombaUI5);
        listaBombaCombustivelUI.add(bombaUI6);
        listaBombaCombustivelUI.add(bombaUI7);

        setAsPostoFechado();

    }

    public CaixaUI getCaixaUI() {
        return caixaUI;
    }

    public void setAsPostoFechado() {
        //Color c = new Color(77, 28, 180);
        Color c = Color.LIGHT_GRAY;
//        Color c = new Color(35,87,253);
        setBackground(c);
        caixaUI.setBackground(c);
        luzAcesa = false;
        caixaUI.setLuzAcesa(luzAcesa);
    }

    public void setAsPostoAberto() {
        //Color c = new Color(39, 135, 252);
        Color c = new Color(255, 255, 255);
        setBackground(c);
        caixaUI.setBackground(c);
        luzAcesa = true;
        caixaUI.setLuzAcesa(luzAcesa);
    }

    public void setModeloBancoFrentistasNesteTurno(List<Frentista> modeloBancoFrentistasNesteTurno) {
        this.modeloBancoFrentistasNesteTurno = modeloBancoFrentistasNesteTurno;
        bancoDeFrentistasNesteTurnoUI.setFrentistasNesteTurno(modeloBancoFrentistasNesteTurno);
    }

    public void addFrentistaNoModeloBancoFrentistasNesteTurno(Frentista frentista) {

        if (modeloBancoFrentistasNesteTurno != null) {
            modeloBancoFrentistasNesteTurno.add(frentista);
            bancoDeFrentistasNesteTurnoUI.addFrentista(frentista);
        }

    }

    public void removeFrentistaNoModeloBancoFrentistasNesteTurno(Frentista frentista) {

        if (modeloBancoFrentistasNesteTurno != null) {
            modeloBancoFrentistasNesteTurno.remove(frentista);
            bancoDeFrentistasNesteTurnoUI.removeFrentista(frentista);
        }

    }

    public boolean isLuzAcesa() {
        return luzAcesa;
    }

    public Frentista getFrentistaLivre() {

        Frentista funcionario = null;

        Collections.shuffle((List<Frentista>) modeloBancoFrentistasNesteTurno);

        for (Frentista f : modeloBancoFrentistasNesteTurno) {
            if (f.getTipo() == TipoFuncioinario.FRENTISTA) {
                if (f.estaLiberado()) {
                    funcionario = f;
                    break;
                }
            }
        }

        return funcionario;

    }

    public BombaCombustivelUI getBombaCombustivelUILivre(Combustivel combustivel) {

        BombaCombustivelUI bombaCombustivelUI = null;

        Collections.shuffle((List<BombaCombustivelUI>) listaBombaCombustivelUI);

        for (BombaCombustivelUI bomba : listaBombaCombustivelUI) {

            if (bomba.getModelo().getCombustivel().equals(combustivel)) {

                if (bomba.getModelo().isLiberada()) {
                    bombaCombustivelUI = bomba;
                    break;
                }
            }
        }

        return bombaCombustivelUI;
    }

    public List<BombaCombustivelUI> getBombasCombustivelUI() {
        return listaBombaCombustivelUI;
    }

    public JSliderGenericoUIWindow getVelocidadeDoCaixaSliderWindow() {
        return velocidadeDoCaixaSliderWindow;
    }

}
