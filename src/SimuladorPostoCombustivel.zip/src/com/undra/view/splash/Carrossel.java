/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.splash;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 * Simula um carrosel de imagens
 *
 * @author alexandre
 * @param <T> U JComponent
 */
public class Carrossel<T extends JLabel> {

    private final ImageIcon[] carrosselIcons;
    private final T[] carrosselElements;
    private final T[] carrosselElementsNames;

    private int currentPoint;

    public Carrossel(ImageIcon[] carrosselIcons, T[] carrosselElements, T[] carrosselElementsNames) {
        this.carrosselIcons = carrosselIcons;
        this.carrosselElements = carrosselElements;
        this.carrosselElementsNames = carrosselElementsNames;
        currentPoint = -(carrosselElements.length - 1);
    }

    public void move(int value) {

        int iconNamePosition = 0;

        if (value % 9 == 0 || value % 10 == 0) {

            if (currentPoint > carrosselIcons.length-2) {
                currentPoint = -(carrosselElements.length - 1);
            }

            int index = 0;
            
            for (T carrosselElement : carrosselElements) {
                               
                try {

                    ImageIcon icon = carrosselIcons[currentPoint + carrosselElements.length - 1 - index];

                    carrosselElement.setIcon(icon);
                    
                    iconNamePosition = icon.getDescription().split("/").length - 1;
                    
                    carrosselElementsNames[index].setText(icon.getDescription().split("/")[iconNamePosition]);

                } catch (Exception e) {
                }
                
                index++;
            }

            currentPoint++;
        }

    }

    //getter for unit test
    public T[] getCarrosselElements() {
        return carrosselElements;
    }

    //getter for unit test
    public T[] getCarrosselElementsNames() {
        return carrosselElementsNames;
    }
    
}
