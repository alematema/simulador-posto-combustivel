package com.undra.view.relatorios;

import com.undra.modelo.contabilidade.Caixa;
import com.undra.view.caixa.CaixaUI;
import com.undra.view.interfaces.UI;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

/**
 * UI do relatorio do caixa
 * @author alexandre
 */
public class RelatorioCaixaUI extends JPanel implements UI{

    private final CaixaUI caixaUi;
    private final Caixa modelo;
    private final CaixaUI relatorioUI;//reaproveita CaixaUI
    private final RelatorioCaixaWindow relatorioCaixaWindow;
    

    public RelatorioCaixaUI(CaixaUI ui, RelatorioCaixaWindow relatorioCaixaWindow) {
        this.caixaUi = ui;
        this.modelo = this.caixaUi.getModelo();
        relatorioUI = new CaixaUI();
        this.relatorioCaixaWindow = relatorioCaixaWindow;
        configure();
    }

    private void configure() {
        
                //setBorder(BorderFactory.createLineBorder(Color.BLACK,6,true));
        setBorder(null);
        //setBackground(Color.BLACK);
        setBackground(new Color(35,87,253));
        relatorioUI.setBackground(getBackground());
        relatorioUI.getConsole().setBackground(Color.WHITE);
        relatorioUI.getConsole().setForeground(Color.BLUE);
        relatorioUI.setBorder(null);
        relatorioUI.setPreferredSize(new Dimension(565, 600));
        add(relatorioUI);

        setPreferredSize(new Dimension(565, 600));
        
    }
    
   public void limparEEAtualizar(){
       
       relatorioUI.limparEAtualizar("");
       atualizar();
       
   } 
    
   public void atualizar(){
       
       //SUBTOTAIS POR TIPO PAGAMENTO
       relatorioUI.escreverNoConsole("RECEBIDOS, "+modelo.getPagamentos().size()+" pagamentos"+"\n\n");
       relatorioUI.escreverNoConsole("      DINHEIRO, R$"+String.format("%.2f",modelo.getTotalRecebidoEmDinheiro())+ " - "+caixaUi.getModelo().getQuantosPgtosRecebidosEmDinheiro()+" pgtos"+"\n");
       relatorioUI.escreverNoConsole("      CHEQUE, R$"+String.format("%.2f",modelo.getTotalRecebidoEmCheque())+ " - "+modelo.getQuantosPgtosRecebidosEmCheque()+" pgtos"+"\n");
       relatorioUI.escreverNoConsole("      CARTÃO DÉBITO , R$"+String.format("%.2f",modelo.getTotalRecebidoEmCartaoDebito())+ " - "+modelo.getQuantosPgtosRecebidosEmCartaoDebito()+" pgtos"+"\n");
       relatorioUI.escreverNoConsole("      CARTÃO CRÉDITO, R$"+String.format("%.2f",modelo.getTotalRecebidoEmCartaoCredito())+ " - "+modelo.getQuantosPgtosRecebidosEmCartaoCredito()+" pgtos"+"\n");
       relatorioUI.escreverNoConsole("      OUTROS , R$"+String.format("%.2f",modelo.getTotalRecebidoEmOutros())+ " - "+modelo.getQuantosPgtosRecebidosEmOutros()+" pgtos"+"\n\n");
       relatorioUI.escreverNoConsole("TOTAL , R$"+String.format("%.2f",modelo.getTotalRecebido())+"\n");
       relatorioUI.escreverNoConsole("---------------------------------------------------------------------------------------------------\n\n\n");
       
       //SUBTOTAIS POR COMBUSTÍVEL
       relatorioUI.escreverNoConsole("      VENDIDOS "+String.format("%.2f",modelo.getQuantoAbasteceuDeGNV())+     " m3       de GNV - "+modelo.getQuantosAbatecimentosGNV() +" abastecimento(s)"+"\n");
       relatorioUI.escreverNoConsole("      VENDIDOS "+String.format("%.2f",modelo.getQuantoAbasteceuDeEtanol())+  " litro(s) de ETANOL - "+modelo.getQuantosAbatecimentosEtanol()+" abastecimento(s)"+"\n");
       relatorioUI.escreverNoConsole("      VENDIDOS "+String.format("%.2f",modelo.getQuantoAbasteceuDeGasolina())+" litro(s) de GASOLINA - "+modelo.getQuantosAbatecimentosGasolina() +" abastecimento(s)"+"\n");
       relatorioUI.escreverNoConsole("      VENDIDOS "+String.format("%.2f",modelo.getQuantoAbasteceuDeDiesel())+" litro(s) de DIESEL - "+modelo.getQuantosAbatecimentosDiesel()+" abastecimento(s)"+"\n\n");
       relatorioUI.escreverNoConsole("TOTAL COMBUSTÍVEL, "+String.format("%.2f",modelo.getTotalQuantoAbasteceu())+" litro(s) e/ou metro(s) cúbico(s)"+"\n");
       
       
   }
   
   public void clear(){
       relatorioUI.limparEAtualizar("");
   }

    public CaixaUI getRelatorioUI() {
        return relatorioUI;
    }
   
   
    
}
