package com.undra.delegator;

import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.combustivel.reservatorio.Reservatorio;
import com.undra.modelo.combustivel.reservatorio.exception.SemCombustivelException;
import com.undra.modelo.combustivel.reservatorio.exception.NivelCriticoDeCombustivelException;
import com.undra.modelo.contabilidade.Abastecimento;
import com.undra.modelo.contabilidade.Caixa;
import com.undra.modelo.recursoshumanos.Funcionario;
import com.undra.view.interfaces.UI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * O delegator do modelo.
 *
 * @author alexandre
 */
public final class ModelDelegator extends Delegator {

    private Caixa caixa;
    private Collection<BombaCombustivel> bombasDeCombustivel;
    private Reservatorio reservatorio;
    private Collection<Object> modelos;

    public ModelDelegator() {
        registrarNoDelegator();
        modelos = new ArrayList();
    }

    public void registrarNoDelegator() {
        registrar(this);
    }

    @Override
    public void registrar(Object delegator) {
        Delegator.registrarDelegator(delegator);
    }

    @Override
    public void desregistrar(Object delegator) {
        Delegator.desregistrarDelegator(delegator);
    }

    public ModelDelegator(Reservatorio reservatorio, Caixa caixa) {

        this();

        if (reservatorio == null) {
            throw new IllegalArgumentException("O reservatório não pode ser null!!!");
        }
        if (caixa == null) {
            throw new IllegalArgumentException("O caixa não pode ser null!!!");
        }

        this.caixa = caixa;
        this.reservatorio = reservatorio;

        bombasDeCombustivel = new ArrayList();

    }

    public void registrarModelo(Object modelo) {

        if (modelo == null) {
            throw new NullPointerException("O modelo não pode ser null!!!");
        }

        if (modelos.add(modelo)) {
            //System.out.println("[MODEL DELEGATOR] : MODELO registrado -> " + modelo);
            
        } else {
            //System.err.println("[MODEL DELEGATOR] : MODELO JÁ ESTAVA registrado -> " + modelo);
        }
    }

    public Object getModelo(Class aClass) {

        Object modelo = null;

        try {

            for (Object obj : modelos) {
                if (obj.getClass().equals(aClass)) {
                    modelo = obj;
                    break;
                }
            }

        } catch (Exception e) {

            //System.err.println("Algo excepcional ocorreu em  ModelDelegator.getModel " + e.getLocalizedMessage());

        }

        return modelo;

    }

    public Collection<Object> getModelos(Class clazz) {

        Collection<Object> models = new ArrayList();

        try {

            this.modelos.stream().filter((modelo) -> (modelo.getClass().equals(clazz))).forEachOrdered((modelo) -> {
                models.add(modelo);
            });

        } catch (Exception e) {
            //System.err.println("Algo excepcional ocorreu em  ModelDelegator.getModelos " + e.getLocalizedMessage());
        }

        return models;

    }

    public Collection<BombaCombustivel> getBombas(Combustivel combustivel) {

        Collection<BombaCombustivel> bombas = new ArrayList();

        try {

            for (Object obj : getModelos(BombaCombustivel.class)) {

                if (((BombaCombustivel) obj).getCombustivel().equals(combustivel)) {

                    bombas.add(((BombaCombustivel) obj));

                }

            }

        } catch (Exception e) {
            //System.err.println("Algo excepcional ocorreu em  ModelDelegator.getBombas " + e.getLocalizedMessage());
        }

        return bombas;

    }

    public void registrarBombaCombustivel(BombaCombustivel bombaCombustivel) {

        if (bombaCombustivel == null) {
            throw new NullPointerException("A bomba de combustivel não pode ser null!!!");
        }

        if (!bombasDeCombustivel.contains(bombaCombustivel)) {

            bombasDeCombustivel.add(bombaCombustivel);
            //System.out.println("[MODEL DELEGATOR] : MODEL registrado -> " + bombaCombustivel.toStringShorter());

        } else {

            //.err.println("[MODEL DELEGATOR] : MODEL JÁ ESTAVA registrado -> " + bombaCombustivel.toStringShorter());

        }

    }

    public void desregistrarBombaCombustivel(BombaCombustivel bombaCombustivel) {

        if (bombaCombustivel == null) {
            throw new RuntimeException("A bomba de combustivel não pode ser null!!!");
        }

        bombasDeCombustivel.remove(bombaCombustivel);
        //System.out.println("[MODEL DELEGATOR] : MODEL DESregistrado -> " + bombaCombustivel.toStringShorter());
    }

    /**
     * Fornece a quantidade de combustível solicitada, se o reservatório NÂO for
     * pra nível critico.<br>
     *
     * @param combustivel o combustivel que o posto vende: gnv, etanol, diesel,
     * gasolina etc
     * @param quantidade a quantidade solicilitada
     * @return a quantidade solicitada de combustivel
     * @throws NullPointerException caso combustível seja null
     * @throws IllegalArgumentException caso quantidade < do que zero
     * @throws com.undra.modelo.combustivel.reservatorio.exception.SemCombustivelException
     * caso nao haja combustível no reservatório deste combustivel
     * @throws NivelCriticoDeCombustivelException caso reservatório fosse pra
     * nível crítico se fornecesse a quantidade;
     */
    public float solicitarAoReservatorio(Combustivel combustivel, float quantidade) throws NivelCriticoDeCombustivelException, SemCombustivelException {
        return getReservatorio().fornecer(combustivel, quantidade);
    }

    /**
     * Verifica a quantidade de combustível no tanque deste combustível e o impacto neste
     * tanque,<br> caso fosse retirada a quantidade solicitada do
     * combustível.
     * <br>
     *
     * @param combustivel o combustivel que o posto vende: gnv, etanol, diesel,
     * gasolina etc
     * @param quantidade a quantidade solicitada do combustível
     * * @throws NullPointerException caso combustível seja null
     * @throws IllegalArgumentException caso quantidade menor do que zero
     * @throws SemCombustivelException caso o tanque esteja vazio
     * @throws NivelCriticoDeCombustivelException caso reservatório já esteja em
     * NÍVEL CRÍTICO ou fosse pra esse nível, se fornecesse a quantidade.
     */
    public void solicitarVerificacaoAoReservatorio(Combustivel combustivel, float quantidade) throws SemCombustivelException, NivelCriticoDeCombustivelException {
        getReservatorio().verificar(combustivel, quantidade);
    }

    public synchronized void delegarAoCaixa(Abastecimento abastecimento) {

        if (abastecimento == null) {
            throw new NullPointerException("O abastecimento não pode ser null!!!");
        }

        Thread t;

        t = new Thread(() -> {
            getCaixa().receber(abastecimento);
        });

        t.start();

    }

    public void notificarDesligamentoDestaBombaCombustivelEnquantoCaixaProcessaAbastecimento(BombaCombustivel bombaCombustivel) {

        if (bombaCombustivel == null) {
            throw new NullPointerException("A bomba combustível não pode ser null!!!");
        }

        bombaCombustivel.getUIDelegator().notificarDesligamentoDaBombaEnquantoCaixaProcessaAbastecimento(bombaCombustivel);
    }

    public synchronized void desbloquearBomba(BombaCombustivel bombaCombustivel) {

        if (bombaCombustivel == null) {
            throw new NullPointerException("A bomba combustível não pode ser null!!!");
        }

        //faz algo aqui com a bomba e etc se necessario e desbloqueia a bomba depois
        bombaCombustivel.desbloquear();
        bombaCombustivel.getUIDelegator().desbloquearABomba(bombaCombustivel);
        bombaCombustivel.getUIDelegator().setAbastecendoEmControleRemoto(0, bombaCombustivel);

    }

    public synchronized boolean alocarBomba(BombaCombustivel bombaCombustivel) {

        if (bombaCombustivel == null) {
            throw new NullPointerException("A bomba combustível não pode ser null!!!");
        }

        if (bombaCombustivel.isLiberada()) {
            bombaCombustivel.alocar();
            return true;
        }

        return false;
    }

    public synchronized void alocarFrentista(Funcionario funcionario) {

        if (funcionario == null) {
            throw new NullPointerException("O funcionário não pode ser null!!!");
        }

        funcionario.setEstado(Funcionario.EM_ESPERA);

    }

    public synchronized void liberarFrentista(Funcionario frentista) {

        if (frentista == null) {
            throw new NullPointerException("O frentista não pode ser null!!!");
        }

        frentista.setEstado(Funcionario.PRONTO);//frentista abasteceu. liberado pra abastecer outra vez
    }

    public synchronized void bloquearFrentista(Funcionario frentista) {

        if (frentista == null) {
            throw new NullPointerException("O frentista não pode ser null!!!");
        }

        frentista.setEstado(Funcionario.EM_ESPERA);//frentista IRA ABASTECER. BLOQUEIA FRENTISTA PARA NAO SER USADO EM OUTRA BOMBA ENQTO NAO ABASTECER A ATUAL
    }

    public boolean isReservatorioVazio(Combustivel combustivel) {
        return getReservatorio().isVazio(combustivel);
    }

    public boolean isReservatorioEmNivelCritico(Combustivel combustivel) {
        return getReservatorio().isEmNivelCritico(combustivel);
    }

    public float getNivelReservatorio(Combustivel combustivel) {
        return getReservatorio().getNivel(combustivel);
    }

    public float retirarDoReservatorio(Combustivel combustivel, float quantidade) {
        return getReservatorio().retirar(combustivel, quantidade);
    }

    public Abastecimento delegarAoCaixaAbastecimento(Funcionario frentista, Combustivel combustivel, float quantidadeAbastecido, float valorAbastecimento, Date date, Date quandoFinalizado, BombaCombustivel bombaCombustivel, String estadoDaBomba) {

        Abastecimento abastecimento;

        valorAbastecimento = combustivel.getPrecoDaUnidade() * quantidadeAbastecido;

        abastecimento = new Abastecimento(frentista, combustivel, quantidadeAbastecido, valorAbastecimento, date, quandoFinalizado, bombaCombustivel, estadoDaBomba);

        delegarAoCaixa(abastecimento);

        return abastecimento;

    }

    public void devolverAoResevartorio(Combustivel combustivel, float quantidade) {
        try {
            getReservatorio().abastecer(combustivel, quantidade);
        } catch (NivelCriticoDeCombustivelException ex) {
            Logger.getLogger(ModelDelegator.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public synchronized void atualizarPrecoCombustivelEmTodasBombasDesteCombustivel(Combustivel combustivel, float novoPreco) {

        for (BombaCombustivel bombaCombustivel : getBombas(combustivel)) {

            if (!bombaCombustivel.isAbastecendo()) {

                //atualiza preço
                bombaCombustivel.setPrecoDaUnidade(novoPreco);

            } else {

                new Thread(() -> {

                    //aloca bomba
                    while (!bombaCombustivel.alocar()) {
                    }

                    //atualiza preço
                    bombaCombustivel.setPrecoDaUnidade(novoPreco);

                    //libera bomba
                    bombaCombustivel.desbloquear();

                }).start();

            }
        }

    }

    private Reservatorio getReservatorio() {

        return (Reservatorio) getModelo(Reservatorio.class);

    }

    private Caixa getCaixa() {
        return (Caixa) getModelo(Caixa.class);
    }

    @Override
    public String toString() {
        return "MODEL DELEGATOR : delegator do modelo";
    }

}
