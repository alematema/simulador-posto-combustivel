package com.undra.modelo.combustivel;

import java.util.Objects;

/**
 * Classe modeladora de um combustível
 * @author alexandre
 */
public class Combustivel {
    
    static public String GASOLINA="GASOLINA";
    static public String ETANOL="ETANOL";
    static public String DIESEL="DIESEL";
    static public String GNV="GNV";
    static public String ELETRICIDADE="ELETRICIDADE";
    static public String LITRO="LITRO";
    static public String METRO_CUBICO="METRO CÚBICO";
    static public String KILOWATT_HORA="KILOWATT HORA";
    static public String SI_LITRO="l";
    static public String SI_METRO_CUBICO="m3";
    static public String SI_KILOWATT_HORA="KWh";
    static public String UNIDADE_MONETÁRIA="R$";
    
    private final String nome;
    private float precoDaUnidade;
    private String nomeDaUnidade;

    public Combustivel(String nomeDoCombustivel, float precoDaUnidade, String nomeDaUnidade) {
        this.nome = nomeDoCombustivel;
         if(precoDaUnidade<0.0)throw new IllegalArgumentException("\nO preço " + (nomeDaUnidade!=null?"do "+ nomeDaUnidade.toLowerCase():"")+ " deve ser maior ou igual do que zero!!! \nO preço passado foi de "+ UNIDADE_MONETÁRIA + precoDaUnidade );
        this.precoDaUnidade = precoDaUnidade;
        this.nomeDaUnidade = nomeDaUnidade;
    }

    public String getNome() {
        return nome;
    }

    public float getPrecoDaUnidade() {
        return precoDaUnidade;
    }

    public void setPrecoDaUnidade(float precoDaUnidade) {
        if(precoDaUnidade<0.0)throw new IllegalArgumentException("\nO preço " + (nomeDaUnidade!=null?"do "+ nomeDaUnidade.toLowerCase():"")+ " deve ser maior ou igual do que zero!!! \nO preço passado foi de "+ UNIDADE_MONETÁRIA + precoDaUnidade );
        this.precoDaUnidade = precoDaUnidade;
    }

    public String getNomeDaUnidade() {
        return nomeDaUnidade;
    }
    
    public String getNomeDaUnidade(float unidades) {
        if(nomeDaUnidade!=null&&nomeDaUnidade.equals(METRO_CUBICO)) return unidades<=1?nomeDaUnidade:"METROS CÚBICOS";
        if(nomeDaUnidade!=null&&nomeDaUnidade.equals(KILOWATT_HORA)) return unidades<=1?nomeDaUnidade:"KILOWATTS HORA";
        return unidades<=1?nomeDaUnidade:nomeDaUnidade+"S";
    }
    
    public String getNomeDaUnidadeSI(float unidades) {
        
        if(nomeDaUnidade!=null&&nomeDaUnidade.equals(METRO_CUBICO)) return SI_METRO_CUBICO;
        if(nomeDaUnidade!=null&&nomeDaUnidade.equals(KILOWATT_HORA)) return SI_KILOWATT_HORA;
        if(nomeDaUnidade!=null&&nomeDaUnidade.equals(LITRO)) return SI_LITRO;
        
        return "";
    }

    public void setNomeDaUnidade(String nomeDaUnidade) {
        this.nomeDaUnidade = nomeDaUnidade;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + Objects.hashCode(this.nome);
        hash = 79 * hash + Float.floatToIntBits(this.precoDaUnidade);
        hash = 79 * hash + Objects.hashCode(this.nomeDaUnidade);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }

        final Combustivel other = (Combustivel) obj;

        return Objects.equals(this.nome, other.nome);
    }

    @Override
    public String toString() {
        return "Combustivel{" + nome + ", precoDaUnidade=" + precoDaUnidade + ", nomeDaUnidade=" + nomeDaUnidade + '}';
    }
    
    public String toStringShort() {
        return "[COMBUSTÍVEL_" + getNome()+"]";
    }
    
    
    public static void main(String[] args) {
        Combustivel combustivel = new Combustivel(Combustivel.GASOLINA, 2.7f, Combustivel.LITRO);
        System.out.println(combustivel);
        combustivel = new Combustivel(Combustivel.ETANOL, 1.99f, Combustivel.LITRO);
        System.out.println(combustivel);
//        combustivel = new Combustivel(Combustivel.DIESEL, -3.22f, Combustivel.LITRO);
    }

}
