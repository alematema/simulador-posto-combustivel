/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.modelo.recursoshumanos;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.modelo.recursoshumanos.exception.RecursosHumanosException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * Classe modela o depto de recursos humanos
 *
 * @author alexandre
 */
public class DepartamentoRecursosHumanos {

    private final Collection<Funcionario> funcionariosAdmitidos;
    private ModelDelegator modelDelegator;
    private UIDelegator uIDelegator;

    public DepartamentoRecursosHumanos() {
        funcionariosAdmitidos = new ArrayList();
    }

    public DepartamentoRecursosHumanos(ModelDelegator modelDelegator, UIDelegator uIDelegator) {
        this();

        if (modelDelegator == null) {
            throw new NullPointerException("O ModelDelegator não pode ser null !!!");
        }

        if (uIDelegator == null) {
            throw new NullPointerException("O UIDelegator não pode ser null !!!");
        }

        this.modelDelegator = modelDelegator;
        this.uIDelegator = uIDelegator;
        registrarNoModelDelegator();

    }

    private void registrarNoModelDelegator() {
        modelDelegator.registrarModelo(this);
    }

    public Collection<Frentista> getFrentistasAdmitidos() {

        Collection<Frentista> frentistas = new ArrayList();

        try {

            funcionariosAdmitidos.stream().filter((funcionario) -> (funcionario.isFrentista() && !funcionario.isDemitido())).forEachOrdered((funcionario) -> {
                frentistas.add((Frentista)funcionario);
            });

        } catch (Exception e) {
            System.err.println("Algo deu errado em DepartamentoRecursosHumanos.getFrentistasAdmitidos " + e.getLocalizedMessage());
            throw new RuntimeException(e);
        }

        return frentistas;

    }

    public void admitirFuncionario(Funcionario funcionario) throws RecursosHumanosException {

        if (funcionario == null) {
            throw new RecursosHumanosException("Funcionário não pode ser null!!!");
        }

        if (funcionariosAdmitidos.contains(funcionario)) {
            throw new RecursosHumanosException("Funcionário " + funcionario.getNome() + " já estava admitido!!!");
        }

        //faz montes de coisas com dados funcionario e dpois add 
        funcionario.setDataAdmissao(new Date());
        funcionario.setEstado(Funcionario.PRONTO);
        funcionario.setDemitido(false);

        funcionariosAdmitidos.add(funcionario);

        //System.out.println("[RECURSOS HUMANOS] : " + funcionario.toStringShort() + " ADMITIDO.");
        
        uIDelegator.atualizarSplash("[RECURSOS HUMANOS] : " + funcionario.toStringShort() + " ADMITIDO.");

    }

    public void demitirFuncionario(Funcionario funcionario) throws RecursosHumanosException {

        if (funcionario == null) {
            throw new RecursosHumanosException("Funcionário não pode ser null!!!");
        }

        if (!funcionariosAdmitidos.contains(funcionario)) {
            throw new RecursosHumanosException("Funcionário " + funcionario.getNome() + " não estava admitido!!!");
        }

        //faz montes de coisas com dados funcionario e dpois remove
        //...
        //...
        funcionario.setDataDemissao(new Date());
        funcionario.setDemitido(true);

        funcionariosAdmitidos.remove(funcionario);

        System.out.println("[RECURSOS HUMANOS] : " + funcionario.toStringShort() + " DEMITIDO.");

    }

    public Collection<Funcionario> getFuncionariosAdmitidos() {
        return funcionariosAdmitidos;//modifiable ?? yes ?? no?? should think better
    }

    @Override
    public String toString() {
        return "Departamento de Recursos Humanos".toUpperCase();
    }

    public static void main(String[] args) throws RecursosHumanosException {

        DepartamentoRecursosHumanos rh = new DepartamentoRecursosHumanos();

        Funcionario funcionario = new Funcionario(1, "ALBERTO", "76767676", "12121212121", TipoFuncioinario.FRENTISTA);

        rh.admitirFuncionario(funcionario);

        funcionario = new Funcionario(2, "ALBERTO", "7676767670987098", "12121212121", TipoFuncioinario.FRENTISTA);

        rh.admitirFuncionario(funcionario);

        rh.demitirFuncionario(funcionario);

    }

}
