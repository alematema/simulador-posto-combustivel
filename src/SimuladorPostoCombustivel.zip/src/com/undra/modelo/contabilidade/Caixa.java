package com.undra.modelo.contabilidade;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Classe modela o caixa
 *
 * @author alexandre
 */
public class Caixa {

    private final String dateFormat = "HH:mm:ss";//"yyyy-MM-dd HH:mm:ss"
    private final SimpleDateFormat dateFormatter = new SimpleDateFormat(dateFormat);

    private volatile boolean recebendoPgto = false;

    private ModelDelegator modelDelegator;

    private final Collection<Pagamento> pagamentos;

    private final Random myRandom;

    private float totalRecebidoEmDinheiro;
    private float totalRecebidoEmCheque;
    private float totalRecebidoEmCartaoCredito;
    private float totalRecebidoEmCartaoDebito;
    private float totalRecebidoEmOutros;
    private float totalRecebido;

    private int quantosPgtosRecebidosEmDinheiro;
    private int quantosPgtosRecebidosEmCheque;
    private int quantosPgtosRecebidosEmCartaoDebito;
    private int quantosPgtosRecebidosEmCartaoCredito;
    private int quantosPgtosRecebidosEmOutros;

    private float quantoAbasteceuDeGNV;
    private int quantosAbatecimentosGNV;
    private int quantosAbatecimentosEtanol;
    private int quantosAbatecimentosGasolina;
    private int quantosAbatecimentosDiesel;
    private float quantoAbasteceuDeEtanol;
    private float quantoAbasteceuDeGasolina;
    private float quantoAbasteceuDeDiesel;
    private float totalQuantoAbasteceu;

    private boolean verbose = false;

    private UIDelegator uIDelegator;

    private int id;

    volatile private boolean ligado = false;// volatile forces memory barrier crossing
    volatile private int velocidade = 50;// volatile forces memory barrier crossing

    public Caixa() {
        pagamentos = new ArrayList();
        myRandom = new Random();
    }

    public Caixa(UIDelegator uIDelegator, int id) {
        this();

        if (uIDelegator == null) {
            throw new NullPointerException("O UI delegator não pode ser null!!!");
        }

        this.uIDelegator = uIDelegator;

        this.id = id;
    }

    public Caixa(ModelDelegator modelDelegator, UIDelegator uIDelegator, int id) {

        this(uIDelegator, id);

        if (modelDelegator == null) {
            throw new NullPointerException("O model delegator não pode ser null!!!");
        }

        this.modelDelegator = modelDelegator;

        registrarNoModelDelegator();

    }

    private void registrarNoModelDelegator() {
        modelDelegator.registrarModelo(this);
    }

    public void setDelegator(ModelDelegator businessDelegator) {
        if (businessDelegator == null) {
            throw new NullPointerException("O delegator não pode ser null!!!");
        }
        this.modelDelegator = businessDelegator;
        modelDelegator.registrarModelo(this);
    }

    public synchronized void receber(Abastecimento abastecimento) {

        while (!ligado) {
        }

        if (abastecimento == null) {
            throw new NullPointerException("O abastecimento não pode ser null!!!");
        }
        verbose = false;
        //faz montes de coisas...
        if (verbose) {
            System.out.println();
            System.out.println("\t[CAIXA] : FAZENDO PAGAMENTO DO ABASTECIMENTO NA " + abastecimento.getBombaCombustivel().toStringShorter());

        }

        recebendoPgto = true;

        //gera forma de pagamento aleatoriamente
        FormaDePagamento[] formasPagamentos = FormaDePagamento.values();
        FormaDePagamento formaPagamento = formasPagamentos[myRandom.nextInt(formasPagamentos.length)];

        //gera pagamento do abastecimento
        Pagamento pagamento = new Pagamento(formaPagamento, abastecimento);

        try {

            if (bombaFoiDesligadaEnquantoCaixaProcessavaAbastecimento(abastecimento)) {
                modelDelegator.notificarDesligamentoDestaBombaCombustivelEnquantoCaixaProcessaAbastecimento(abastecimento.getBombaCombustivel());
            }

            if (bombaFoiDesligadaEnquantoCaixaProcessavaAbastecimento(abastecimento)) {
                modelDelegator.notificarDesligamentoDestaBombaCombustivelEnquantoCaixaProcessaAbastecimento(abastecimento.getBombaCombustivel());
            }

            uIDelegator.limparEEscreverNoConsoleDoCaixa("      PAGAMENTO DO ABASTECIMENTO\n", this);
            uIDelegator.escreverNoConsoleDoCaixa("--------------------------------------------------------------------\n", this);
            uIDelegator.escreverNoConsoleDoCaixa("combustivel            : " + abastecimento.getCombustivel().getNome() + "\n", this);
            Thread.sleep(getSleepTime());
            uIDelegator.escreverNoConsoleDoCaixa("forma pagamento : " + pagamento.getFormaPagamento() + "\n", this);
            Thread.sleep(getSleepTime());
            if (bombaFoiDesligadaEnquantoCaixaProcessavaAbastecimento(abastecimento)) {
                modelDelegator.notificarDesligamentoDestaBombaCombustivelEnquantoCaixaProcessaAbastecimento(abastecimento.getBombaCombustivel());
            }
            uIDelegator.escreverNoConsoleDoCaixa("valor do abastecimento : R$" + String.format("%.2f", abastecimento.getValorAbastecimento()) + "\n", this);
            Thread.sleep(getSleepTime());
            if (bombaFoiDesligadaEnquantoCaixaProcessavaAbastecimento(abastecimento)) {
                modelDelegator.notificarDesligamentoDestaBombaCombustivelEnquantoCaixaProcessaAbastecimento(abastecimento.getBombaCombustivel());
            }
            uIDelegator.escreverNoConsoleDoCaixa("quantidade         : " + String.format("%.2f %s", abastecimento.getQuantidade(), abastecimento.getCombustivel().getNomeDaUnidade(abastecimento.getQuantidade())) + "\n", this);
            Thread.sleep(getSleepTime());
            if (bombaFoiDesligadaEnquantoCaixaProcessavaAbastecimento(abastecimento)) {
                modelDelegator.notificarDesligamentoDestaBombaCombustivelEnquantoCaixaProcessaAbastecimento(abastecimento.getBombaCombustivel());
            }
            uIDelegator.escreverNoConsoleDoCaixa("preço do " + abastecimento.getCombustivel().getNomeDaUnidade(1f) + " : R$" + String.format("%.2f", abastecimento.getCombustivel().getPrecoDaUnidade()) + "\n", this);

            uIDelegator.escreverNoConsoleDoCaixa("--------------------------------------------------------------------\n", this);
            Thread.sleep(getSleepTime() / 2);
            if (bombaFoiDesligadaEnquantoCaixaProcessavaAbastecimento(abastecimento)) {
                modelDelegator.notificarDesligamentoDestaBombaCombustivelEnquantoCaixaProcessaAbastecimento(abastecimento.getBombaCombustivel());
            }
            uIDelegator.escreverNoConsoleDoCaixa("horário do abastecimento : " + dateFormatter.format(abastecimento.getHorarioInicio()) + "\n", this);
            Thread.sleep(getSleepTime() / 2);
            if (bombaFoiDesligadaEnquantoCaixaProcessavaAbastecimento(abastecimento)) {
                modelDelegator.notificarDesligamentoDestaBombaCombustivelEnquantoCaixaProcessaAbastecimento(abastecimento.getBombaCombustivel());
            }
            uIDelegator.escreverNoConsoleDoCaixa("horário do pagamento         :" + dateFormatter.format(pagamento.getHora()) + "\n", this);

            uIDelegator.escreverNoConsoleDoCaixa("--------------------------------------------------------------------\n", this);
            Thread.sleep(getSleepTime() / 2);
            if (bombaFoiDesligadaEnquantoCaixaProcessavaAbastecimento(abastecimento)) {
                modelDelegator.notificarDesligamentoDestaBombaCombustivelEnquantoCaixaProcessaAbastecimento(abastecimento.getBombaCombustivel());
            }
            uIDelegator.escreverNoConsoleDoCaixa("frentista : " + abastecimento.getFrentista().getNome() + "\n", this);
            Thread.sleep(getSleepTime() / 2);
            if (bombaFoiDesligadaEnquantoCaixaProcessavaAbastecimento(abastecimento)) {
                modelDelegator.notificarDesligamentoDestaBombaCombustivelEnquantoCaixaProcessaAbastecimento(abastecimento.getBombaCombustivel());
            }
            uIDelegator.escreverNoConsoleDoCaixa("bomba      : " + abastecimento.getBombaCombustivel().toStringShorter() + "\n", this);

//            uIDelegator.escreverNoConsoleDoCaixa("--------------------------------------------------------------------\n");
            Thread.sleep(getSleepTime());
            if (bombaFoiDesligadaEnquantoCaixaProcessavaAbastecimento(abastecimento)) {
                modelDelegator.notificarDesligamentoDestaBombaCombustivelEnquantoCaixaProcessaAbastecimento(abastecimento.getBombaCombustivel());
            }
            Thread.sleep(getSleepTime());
            if (bombaFoiDesligadaEnquantoCaixaProcessavaAbastecimento(abastecimento)) {
                modelDelegator.notificarDesligamentoDestaBombaCombustivelEnquantoCaixaProcessaAbastecimento(abastecimento.getBombaCombustivel());
            }

            recebendoPgto = false;

            new Thread(new MyRunnable(this)).start();

            verbose = false;
            if (verbose) {
                System.out.println();
                System.out.println("\t\t-------------------------------------------------------------------------------------");
                System.out.printf("\t\tcombustível %s\n", abastecimento.getCombustivel().getNome());
                System.out.printf("\t\tforma de pagamento %s\n", pagamento.getFormaPagamento());
                System.out.printf("\t\tvalor do abastecimento %s%.2f\n", Combustivel.UNIDADE_MONETÁRIA, abastecimento.getValorAbastecimento());
                System.out.printf("\t\tquantidade em %s %.2f\n", abastecimento.getCombustivel().getNomeDaUnidade(abastecimento.getQuantidade()), abastecimento.getQuantidade());
                System.out.printf("\t\tpreço do %s %s %.2f\n", abastecimento.getCombustivel().getNomeDaUnidade(1f), Combustivel.UNIDADE_MONETÁRIA, abastecimento.getCombustivel().getPrecoDaUnidade());

                System.out.println("\t\t------------------------------------------------------");
                System.out.println("\t\thorário do abastecimento : " + abastecimento.getHorarioInicio());
                System.out.println("\t\thorário do pagamento     : " + pagamento.getHora());
                System.out.println("\t\t------------------------------------------------------");
                System.out.printf("\t\tabastecimento feito pelo frentista  %s\n", abastecimento.getFrentista().getNome());
                System.out.printf("\t\tabastecimento efetuado na %s\n", abastecimento.getBombaCombustivel().toStringShorter());
                System.out.println("\t\t--------------------------------------------------------------------------------------");
            }

        } catch (InterruptedException ex) {
            Logger.getLogger(ModelDelegator.class.getName()).log(Level.SEVERE, null, ex);
        }

        addPagamentoRecebido(pagamento);

        //libera bomba apos gerar pagamento do abastecimento
        if (abastecimento.getBombaCombustivel().getEstado().equals(BombaCombustivel.AGUARDANDO_O_CAIXA) || abastecimento.getBombaCombustivel().getEstado().equals(BombaCombustivel.AGUARDANDO_O_CAIXA_EM_NIVEL_CRITICO_COMBUSTIVEL)) {
            modelDelegator.desbloquearBomba(abastecimento.getBombaCombustivel());
            verbose = false;
            if (verbose) {
                System.out.println("\t\t" + abastecimento.getBombaCombustivel().toStringShorter() + " : LIBERADA\n");
            }
            if (verbose) {
                System.out.println("\t" + "ABASTECIMENTO PAGO\n\n");
            }
        }

    }

    class MyRunnable implements Runnable {

        Caixa caixa;

        public MyRunnable(Caixa caixa) {
            this.caixa = caixa;
        }

        int sleep = 180;

        @Override
        public void run() {

            while (!recebendoPgto) {

                try {
                    if(recebendoPgto)break;
                    uIDelegator.limparEEscreverNoConsoleDoCaixa("      CAIXA " + getId() + " PRONTO " + "  -"+"\n", this.caixa);
                    Thread.sleep(getSleepTime());
                    if(recebendoPgto)break;
                    uIDelegator.limparEEscreverNoConsoleDoCaixa("      CAIXA " + getId() + " PRONTO " + "  /"+"\n", this.caixa);
                    Thread.sleep(getSleepTime());
                    if(recebendoPgto)break;
                    uIDelegator.limparEEscreverNoConsoleDoCaixa("      CAIXA " + getId() + " PRONTO " + "  |"+"\n", this.caixa);
                    Thread.sleep(1 * getSleepTime());
                    if(recebendoPgto)break;
                    uIDelegator.limparEEscreverNoConsoleDoCaixa("      CAIXA " + getId() + " PRONTO " + "  \\"+"\n", this.caixa);
                    Thread.sleep(getSleepTime());
//                    if(recebendoPgto)break;
//                    uIDelegator.limparEEscreverNoConsoleDoCaixa("      CAIXA " + getId() + " PRONTO " + "  -"+"\n", this.caixa);
//                    Thread.sleep(getSleepTime());
//                    if(recebendoPgto)break;
//                     uIDelegator.limparEEscreverNoConsoleDoCaixa("      CAIXA " + getId() + " PRONTO " + "  /"+"\n", this.caixa);
//                    Thread.sleep(1 * getSleepTime());
//                    if(recebendoPgto)break;
//                    uIDelegator.limparEEscreverNoConsoleDoCaixa("      CAIXA " + getId() + " PRONTO " + "  |"+"\n", this.caixa);
//                    Thread.sleep(1 * getSleepTime());
//                    if(recebendoPgto)break;
//                    uIDelegator.limparEEscreverNoConsoleDoCaixa("      CAIXA " + getId() + " PRONTO " + "  \\"+"\n", this.caixa);
//                    Thread.sleep(getSleepTime());

                } catch (Exception e) {
                }

            }

        }

    }

    private void addPagamentoRecebido(Pagamento pagamento) {

        if (pagamento.isDinheiro()) {

            totalRecebidoEmDinheiro += pagamento.getValor();
            quantosPgtosRecebidosEmDinheiro++;

        }
        if (pagamento.isCheque()) {

            totalRecebidoEmCheque += pagamento.getValor();
            quantosPgtosRecebidosEmCheque++;

        }
        if (pagamento.isCartaoDebito()) {

            totalRecebidoEmCartaoDebito += pagamento.getValor();
            quantosPgtosRecebidosEmCartaoDebito++;

        }
        if (pagamento.isCartaoCredito()) {

            totalRecebidoEmCartaoCredito += pagamento.getValor();
            quantosPgtosRecebidosEmCartaoCredito++;

        }
        if (pagamento.isOutros()) {
            totalRecebidoEmOutros += pagamento.getValor();
            quantosPgtosRecebidosEmOutros++;
        }

        totalRecebido += pagamento.getValor();

        pagamentos.add(pagamento);

        Abastecimento abastecimento = pagamento.getAbastecimento();

        if (abastecimento.isGNV()) {
            quantoAbasteceuDeGNV += abastecimento.getQuantidade();
            quantosAbatecimentosGNV++;
        }
        if (abastecimento.isEtanol()) {
            quantoAbasteceuDeEtanol += abastecimento.getQuantidade();
            quantosAbatecimentosEtanol++;
        }
        if (abastecimento.isGasolina()) {
            quantoAbasteceuDeGasolina += abastecimento.getQuantidade();
            quantosAbatecimentosGasolina++;
        }
        if (abastecimento.isDiesel()) {
            quantoAbasteceuDeDiesel += abastecimento.getQuantidade();
            quantosAbatecimentosDiesel++;
        }

        totalQuantoAbasteceu += abastecimento.getQuantidade();

    }

    public int getId() {
        return id;
    }

    public Collection<Pagamento> getPagamentos() {
        return pagamentos;
    }

    public void setVerbose(boolean verbose) {
        this.verbose = verbose;
    }

    private boolean bombaFoiDesligadaEnquantoCaixaProcessavaAbastecimento(Abastecimento abastecimento) {
        return !abastecimento.getBombaCombustivel().isLigada();
    }

    public float getTotalRecebidoEmDinheiro() {
        return totalRecebidoEmDinheiro;
    }

    public float getTotalRecebidoEmCheque() {
        return totalRecebidoEmCheque;
    }

    public float getTotalRecebidoEmCartaoCredito() {
        return totalRecebidoEmCartaoCredito;
    }

    public float getTotalRecebidoEmCartaoDebito() {
        return totalRecebidoEmCartaoDebito;
    }

    public float getTotalRecebidoEmOutros() {
        return totalRecebidoEmOutros;
    }

    public float getTotalRecebido() {
        return totalRecebido;
    }

    public int getQuantosPgtosRecebidosEmDinheiro() {
        return quantosPgtosRecebidosEmDinheiro;
    }

    public int getQuantosPgtosRecebidosEmCheque() {
        return quantosPgtosRecebidosEmCheque;
    }

    public int getQuantosPgtosRecebidosEmCartaoDebito() {
        return quantosPgtosRecebidosEmCartaoDebito;
    }

    public int getQuantosPgtosRecebidosEmCartaoCredito() {
        return quantosPgtosRecebidosEmCartaoCredito;
    }

    public int getQuantosPgtosRecebidosEmOutros() {
        return quantosPgtosRecebidosEmOutros;
    }

    public float getQuantoAbasteceuDeGNV() {
        return quantoAbasteceuDeGNV;
    }

    public int getQuantosAbatecimentosGNV() {
        return quantosAbatecimentosGNV;
    }

    public int getQuantosAbatecimentosEtanol() {
        return quantosAbatecimentosEtanol;
    }

    public int getQuantosAbatecimentosGasolina() {
        return quantosAbatecimentosGasolina;
    }

    public int getQuantosAbatecimentosDiesel() {
        return quantosAbatecimentosDiesel;
    }

    public float getQuantoAbasteceuDeEtanol() {
        return quantoAbasteceuDeEtanol;
    }

    public float getQuantoAbasteceuDeGasolina() {
        return quantoAbasteceuDeGasolina;
    }

    public float getQuantoAbasteceuDeDiesel() {
        return quantoAbasteceuDeDiesel;
    }

    public float getTotalQuantoAbasteceu() {
        return totalQuantoAbasteceu;
    }

    public boolean isLigado() {
        return ligado;
    }

    public boolean isRecebendoPgto() {
        return recebendoPgto;
    }
    
    

    public void setLigado(boolean ligado) {
        this.ligado = ligado;
    }

    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }

    //simula demora no caixa
    private long getSleepTime() {
        return (int) (50 * (int) 100 * (1.0 / velocidade));
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 19 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Caixa other = (Caixa) obj;
        return this.id == other.id;
    }

    @Override
    public String toString() {
        return "CAIXA " + id;
    }

}
