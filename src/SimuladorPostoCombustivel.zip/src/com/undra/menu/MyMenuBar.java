package com.undra.menu;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.view.caixa.CaixaUI;
import com.undra.view.controleRemoto.bombaCombustivel.ControleRemotoBombaCombustivelUI;
import com.undra.view.mesaControleRemotoDasBombasCombustivelUI.MesaControleRemotoDasBombasUIWindow;
import com.undra.view.pistaDasBombas.PistaDasBombasUIWindow;
import com.undra.view.relatorios.RelatoriosFrentistasAbastecimentosUIWindow;
import com.undra.view.reservatorio.ReservatorioCombustiveisUIWindow;
import com.undra.view.turno.TurnoFrentistasUIWindow;
import java.awt.Color;
import java.awt.Font;
import static java.awt.Frame.NORMAL;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.Timer;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;


/**
 * Uma especializaçao do JMenuBar
 *
 * @author alexandre
 */
public class MyMenuBar extends JMenuBar {

    public final JMenu iniciarMenu = new JMenu("iniciar");
    private final JMenu sairMenu = new JMenu("sair");
    public final JMenu bombasMenu = new JMenu("bombas");
    private final JMenu caixaMenu = new JMenu("caixa");
    private final JMenu turnoMenu = new JMenu("turnos");
    private final JMenu reservatorioMenu = new JMenu("reservatório");
    private final JMenu recursosHumanosMenu = new JMenu("recursos humanos");
    private final JMenu relatoriosMenu = new JMenu("relatórios");
    private final JMenu relatoriosBombasMenu = new JMenu("bombas");
    private final JMenu relatoriosCaixasMenu = new JMenu("caixas");
    private final JMenu relatoriosFrentistasMenu = new JMenu("frentistas");

    private final JMenu configuracoesMenu = new JMenu("configurações");

    public final JMenuItem ligarDesligarBombasMenuItem = new JMenuItem("ligar bombas");
    private final JMenuItem sairMenuItem = new JMenuItem("sair");

    public final JMenuItem pistaDasBombasMenuItem = new JMenuItem("pista");
    private final JMenuItem controleRemotoDasBombasMenuItem = new JMenuItem("controle remoto");
    public final JMenuItem abrirFecharCaixaMenuItem = new JMenuItem("abrir");
    public final JMenuItem velocidadeCaixaMenuItem = new JMenuItem("velocidade");
    public final JMenuItem turnoFrentistasMenuItem = new JMenuItem("frentistas");
    public final JMenuItem turnoCaixasMenuItem = new JMenuItem("caixas");
    
    private final JMenuItem abrirRelatoriosFrentistasAbastecimentosMenuItem = new JMenuItem("abastecimentos");
    private final JMenuItem recursosHumanosAdmitirFrentistaMenuItem = new JMenuItem("admitir frentistas");
    private final JMenuItem recursosHumanosDemitirFrentistaMenuItem = new JMenuItem("demitir frentistas");
    public final JMenuItem acenderApagarLuzMenuItem = new JMenuItem("acender luz");
    public final JMenuItem reservatorioMenuItem = new JMenuItem("tanques");

    private final ImageIcon luzAcesaIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/luzacesa.png"));
    private final ImageIcon luzApagadaIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/luzapagada.png"));
    private final ImageIcon sairIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/sair.png"));
    private final ImageIcon sairPretoIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/sairPreto.png"));
    private final ImageIcon iniciarIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/play.png"));
    private final ImageIcon bombaCombustivelIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/bombaCombustivelAmarela.png"));
    private final ImageIcon bombaCombustivelPretoIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/bombacombustivelPreto.png"));
    private final ImageIcon controleRemotoBombaCombustivelcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/controleRemoto.png"));
    private final ImageIcon bombasOffIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/off.24x12.png"));
    private final ImageIcon bombasOnIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/on.png"));
    private final ImageIcon caixaRegistradoraIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/caixaRegistradora.png"));
    private final ImageIcon caixaRegistradoraVelocidadeIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/velocimetro.png"));
    private final ImageIcon caixaRegistradoraOffIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/off.24x12.png"));
    private final ImageIcon caixaRegistradoraOnIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/on.png"));
    private final ImageIcon turnoIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/turno.png"));
    private final ImageIcon reservatorioIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/reservatorio.png"));
    private final ImageIcon tanqueCombustivelIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/tanqueCombustivel.png"));
    private final ImageIcon recursosHumanoslAdmitirFuncionarioIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/plus.png"));
    private final ImageIcon recursosHumanoslDemitirFuncionarioIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/minus.png"));
    private final ImageIcon recursosHumanoslIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/recursosHumanos.png"));
    private final ImageIcon relatoriosIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/relatorios.png"));
    private final ImageIcon bombaCombustivelPretoRelatoriosIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/bombacombustivelPreto.png"));
    private final ImageIcon caixaRegistradoraRelatorioIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/caixaRegistradoraPreto.png"));
    private final ImageIcon frentistasRelatorioIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/relatorioFrentistas.jpg"));
    private final ImageIcon frentistasRelatorioAbastecimentosBombaCombustivelPretoIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/bombacombustivelPreto.png"));
    private final ImageIcon configurationIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/configurationOk.png"));

    private final UIDelegator uIDelegator;

    private final ModelDelegator modelDelegator;

    private final MenuListener menuListener;

    private Timer acenderApagarLuzMenuTimer;

    public MyMenuBar(UIDelegator uIDelegator, ModelDelegator modelDelegator) throws HeadlessException {

        this.uIDelegator = uIDelegator;
        this.modelDelegator = modelDelegator;

        sairMenuItem.setName("PostoCombustivelUIWindow");
        pistaDasBombasMenuItem.setName("PistaDasBombasUIWindow");
        controleRemotoDasBombasMenuItem.setName("MesaControleRemotoDasBombasUIWindow");
        reservatorioMenuItem.setName("ReservatorioCombustiveisUIWindow");
        
        turnoMenu.setToolTipText("CLIQUE PARA AJUSTAR TURNOS FUNCIONÁRIOS");
        turnoMenu.setIcon(turnoIcon);
        turnoFrentistasMenuItem.setToolTipText("CLIQUE PARA DEFINIR FRENTISTAS NESTE TURNO");
        turnoFrentistasMenuItem.setIcon(turnoIcon);
        turnoCaixasMenuItem.setIcon(turnoIcon);
        turnoCaixasMenuItem.setEnabled(false);
        
        sairMenuItem.setToolTipText("CLIQUE PARA SAIR");
        sairMenuItem.setIcon(sairPretoIcon);

        iniciarMenu.setToolTipText("CLIQUE PARA INICIAR SIMULAÇÕES");
        iniciarMenu.setIcon(iniciarIcon);
        acenderApagarLuzMenuItem.setVisible(false);
        iniciarMenu.add(acenderApagarLuzMenuItem);

        acenderApagarLuzMenuItem.setToolTipText("CLIQUE PARA ACENDER/APAGAR A LUZ");
        acenderApagarLuzMenuItem.setIcon(luzAcesaIcon);

        bombasMenu.setIcon(bombaCombustivelIcon);
        caixaMenu.setIcon(caixaRegistradoraIcon);
        
        reservatorioMenu.setIcon(reservatorioIcon);
        recursosHumanosMenu.setIcon(recursosHumanoslIcon);
        relatoriosMenu.setIcon(relatoriosIcon);
        relatoriosFrentistasMenu.setIcon(frentistasRelatorioIcon);
        configuracoesMenu.setIcon(configurationIcon);
        abrirFecharCaixaMenuItem.setIcon(caixaRegistradoraOnIcon);

        menuListener = new MenuListener() {

            @Override
            public void menuSelected(MenuEvent e) {

                if (iniciarMenu.getText().equals("iniciar")) {

                    for (MyMenuBar myMenuBar : MenuNavigator.MY_MENu_BAR_LIST) {
                        myMenuBar.iniciarMenu.setText("acender luz");
                        myMenuBar.iniciarMenu.setToolTipText("CLIQUE PARA ACENDER/APAGAR A LUZ");
                        myMenuBar.iniciarMenu.setIcon(luzAcesaIcon);
                    }

                    MenuNavigator.setTo(pistaDasBombasMenuItem.getName());
                    MenuNavigator.navigate();

                    iniciarMenu.setForeground(Color.WHITE);

                    iniciarMenu.transferFocus();

                    setVisibleInvisibleMenus();

                }
            }

            @Override
            public void menuDeselected(MenuEvent e) {
            }

            @Override
            public void menuCanceled(MenuEvent e) {
            }
        };

        iniciarMenu.addMenuListener(menuListener);

        acenderApagarLuzMenuItem.addActionListener((ActionEvent e) -> {
            if (acenderApagarLuzMenuItem.getText().equals("acender luz")) {

                for (MyMenuBar myMenuBar : MenuNavigator.MY_MENu_BAR_LIST) {
                    myMenuBar.acenderApagarLuzMenuItem.setText("apagar luz");
                    myMenuBar.iniciarMenu.setText("apagar luz");
                    myMenuBar.acenderApagarLuzMenuItem.setToolTipText("CLIQUE PARA APAGAR A LUZ");
                    myMenuBar.iniciarMenu.setToolTipText("CLIQUE PARA APAGAR A LUZ");
                    myMenuBar.iniciarMenu.setIcon(luzApagadaIcon);
                    myMenuBar.acenderApagarLuzMenuItem.setIcon(luzApagadaIcon);
                }

                ((PistaDasBombasUIWindow) MenuNavigator.getUI("PistaDasBombasUIWindow")).getPistaDasBombasUI().setAsPostoAberto();
                ((MesaControleRemotoDasBombasUIWindow) MenuNavigator.getUI("MesaControleRemotoDasBombasUIWindow")).getMesaControleRemotoDasBombasUI().acenderLuz();
//                    ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow")).getReservatorioCombustiveisUI().acenderLuz();
//                    try {
//                        Thread.sleep(400);
//                    } catch (InterruptedException ex) {
//                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
//                    }
//                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
//                    window.getReservatorioCombustiveisUI().setNivelTanques();
            } else {

                for (MyMenuBar myMenuBar : MenuNavigator.MY_MENu_BAR_LIST) {
                    myMenuBar.acenderApagarLuzMenuItem.setText("acender luz");
                    myMenuBar.iniciarMenu.setText("acender luz");
                    myMenuBar.acenderApagarLuzMenuItem.setToolTipText("CLIQUE PARA ACENDER A LUZ");
                    myMenuBar.iniciarMenu.setToolTipText("CLIQUE PARA ACENDER A LUZ");
                    myMenuBar.iniciarMenu.setIcon(luzAcesaIcon);
                    myMenuBar.acenderApagarLuzMenuItem.setIcon(luzAcesaIcon);
                }

                ((PistaDasBombasUIWindow) MenuNavigator.getUI("PistaDasBombasUIWindow")).getPistaDasBombasUI().setAsPostoFechado();
                ((MesaControleRemotoDasBombasUIWindow) MenuNavigator.getUI("MesaControleRemotoDasBombasUIWindow")).getMesaControleRemotoDasBombasUI().apagarLuz();
//                    ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow")).getReservatorioCombustiveisUI().apagarLuz();
//                    try {
//                        Thread.sleep(400);
//                    } catch (InterruptedException ex) {
//                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
//                    }
//                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
//                    window.getReservatorioCombustiveisUI().setNivelTanques();
            }
        });

        sairMenu.add(sairMenuItem);
        sairMenu.setBackground(Color.BLACK);
        sairMenu.setIcon(sairIcon);

        Font f = new Font("Arial", 2, 15);
        Color foreground = Color.BLACK;

        sairMenuItem.setFont(f);
        sairMenuItem.setForeground(foreground);
        sairMenuItem.setBackground(Color.BLACK);

        sairMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(NORMAL);
            }
        });

        bombasMenu.addMenuListener(new MenuListener() {
            @Override
            public void menuSelected(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();
                }).start();

            }

            @Override
            public void menuDeselected(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();

                }).start();

            }

            @Override
            public void menuCanceled(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();
                }).start();

            }
        });

        ligarDesligarBombasMenuItem.setName("ligar");
        ligarDesligarBombasMenuItem.setForeground(foreground);
        ligarDesligarBombasMenuItem.addActionListener((ActionEvent e) -> {
            if (ligarDesligarBombasMenuItem.getName().equals("ligar")) {

                MenuNavigator.MY_MENu_BAR_LIST.forEach((myMenuBar) -> {
                    myMenuBar.ligarDesligarBombasMenuItem.setEnabled(false);
                });

                new Thread(() -> {

                    ((PistaDasBombasUIWindow) MenuNavigator.getUI("PistaDasBombasUIWindow")).getPistaDasBombasUI().getBombasCombustivelUI().stream().map((bombaView) -> {
                        if (!bombaView.isLigada()) {
                            bombaView.getOnOff().doClick();
                        }
                        return bombaView;
                    }).forEachOrdered((_item) -> {
                        try {
                            Thread.sleep(0);
                        } catch (Exception ex) {
                            Logger.getLogger(PistaDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    });

                    try {
                        Thread.sleep(14000);
                        for (MyMenuBar myMenuBar : MenuNavigator.MY_MENu_BAR_LIST) {
                            myMenuBar.ligarDesligarBombasMenuItem.setName("desligar");
                            myMenuBar.ligarDesligarBombasMenuItem.setText("desligar bombas");
                            myMenuBar.ligarDesligarBombasMenuItem.setEnabled(true);
                            ligarDesligarBombasMenuItem.setIcon(bombasOffIcon);
                        }
                    } catch (Exception ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }).start();

            } else {

                MenuNavigator.MY_MENu_BAR_LIST.forEach((myMenuBar) -> {
                    myMenuBar.ligarDesligarBombasMenuItem.setEnabled(false);
                });

                new Thread(() -> {

                    ((PistaDasBombasUIWindow) MenuNavigator.getUI("PistaDasBombasUIWindow")).getPistaDasBombasUI().getBombasCombustivelUI().stream().map((bombaView) -> {
                        if (bombaView.isLigada()) {
                            bombaView.getOnOff().doClick();
                        }
                        return bombaView;
                    }).forEachOrdered((_item) -> {
                        try {
                            Thread.sleep(0);
                        } catch (InterruptedException ex) {
                            Logger.getLogger(PistaDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    });

                    try {
                        Thread.sleep(9000);
                        for (MyMenuBar myMenuBar : MenuNavigator.MY_MENu_BAR_LIST) {

                            myMenuBar.ligarDesligarBombasMenuItem.setName("ligar");
                            myMenuBar.ligarDesligarBombasMenuItem.setText("ligar bombas");
                            myMenuBar.ligarDesligarBombasMenuItem.setEnabled(true);
                            ligarDesligarBombasMenuItem.setIcon(bombasOnIcon);
                        }
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }).start();

            }
        });

        pistaDasBombasMenuItem.setFont(f);
        pistaDasBombasMenuItem.setForeground(foreground);

        pistaDasBombasMenuItem.addActionListener((ActionEvent e) -> {
            MenuNavigator.setTo(pistaDasBombasMenuItem.getName());
            MenuNavigator.navigate();
        });

        bombasMenu.add(pistaDasBombasMenuItem);
        pistaDasBombasMenuItem.setToolTipText("IR PARA PISTA DAS BOMBAS COMBUSTÍVEIS");
        pistaDasBombasMenuItem.setIcon(bombaCombustivelPretoIcon);

        controleRemotoDasBombasMenuItem.setFont(f);
        controleRemotoDasBombasMenuItem.setForeground(foreground);

        controleRemotoDasBombasMenuItem.addActionListener((ActionEvent e) -> {
            MenuNavigator.setTo("MesaControleRemotoDasBombasUIWindow");
            MenuNavigator.navigate();
        });

        bombasMenu.add(controleRemotoDasBombasMenuItem);
        controleRemotoDasBombasMenuItem.setToolTipText("IR PARA CONTROLE REMOTO DAS BOMBAS COMBUSTÍVEIS");
        controleRemotoDasBombasMenuItem.setIcon(controleRemotoBombaCombustivelcon);

        bombasMenu.add(ligarDesligarBombasMenuItem);
        ligarDesligarBombasMenuItem.setIcon(bombasOnIcon);

        abrirFecharCaixaMenuItem.setForeground(foreground);
        abrirFecharCaixaMenuItem.addActionListener((ActionEvent e) -> {

            if (abrirFecharCaixaMenuItem.getText().equals("abrir")) {

                MenuNavigator.MY_MENu_BAR_LIST.forEach((myMenuBar) -> {
                    myMenuBar.abrirFecharCaixaMenuItem.setEnabled(false);
                });

                new Thread(() -> {

                    ((PistaDasBombasUIWindow) MenuNavigator.getUI("PistaDasBombasUIWindow")).getPistaDasBombasUI().getCaixaUI().abrir();

                    while (!((PistaDasBombasUIWindow) MenuNavigator.getUI("PistaDasBombasUIWindow")).getPistaDasBombasUI().getCaixaUI().isAberto) {
                    }

                    MenuNavigator.MY_MENu_BAR_LIST.stream().map((myMenuBar) -> {
                        myMenuBar.abrirFecharCaixaMenuItem.setText("fechar");
                        myMenuBar.abrirFecharCaixaMenuItem.setIcon(caixaRegistradoraOffIcon);
                        return myMenuBar;
                    }).forEachOrdered((myMenuBar) -> {
                        myMenuBar.abrirFecharCaixaMenuItem.setEnabled(true);
                    });
                }).start();

            } else {

                MenuNavigator.MY_MENu_BAR_LIST.forEach((myMenuBar) -> {
                    myMenuBar.abrirFecharCaixaMenuItem.setEnabled(false);
                });

                new Thread(() -> {

                    ((PistaDasBombasUIWindow) MenuNavigator.getUI("PistaDasBombasUIWindow")).getPistaDasBombasUI().getCaixaUI().fechar();

                    while (((PistaDasBombasUIWindow) MenuNavigator.getUI("PistaDasBombasUIWindow")).getPistaDasBombasUI().getCaixaUI().isAberto) {
                    }

                    MenuNavigator.MY_MENu_BAR_LIST.stream().map((myMenuBar) -> {
                        myMenuBar.abrirFecharCaixaMenuItem.setText("abrir");
                        myMenuBar.abrirFecharCaixaMenuItem.setIcon(caixaRegistradoraOnIcon);
                        return myMenuBar;
                    }).forEachOrdered((myMenuBar) -> {
                        myMenuBar.abrirFecharCaixaMenuItem.setEnabled(true);
                    });

                }).start();

            }
        });

        
        
        caixaMenu.add(abrirFecharCaixaMenuItem);
        abrirFecharCaixaMenuItem.setToolTipText("CLIQUE PARA ABRIR/FECHAR O CAIXA");
        caixaMenu.addSeparator();
        
        

        velocidadeCaixaMenuItem.setForeground(foreground);
        velocidadeCaixaMenuItem.setIcon(caixaRegistradoraVelocidadeIcon);
        velocidadeCaixaMenuItem.addActionListener((ActionEvent e) -> {

            ((PistaDasBombasUIWindow) MenuNavigator.getUI("PistaDasBombasUIWindow")).getPistaDasBombasUI().getVelocidadeDoCaixaSliderWindow().raise();

        });
        caixaMenu.add(velocidadeCaixaMenuItem);
        velocidadeCaixaMenuItem.setToolTipText("CLIQUE PARA AUMETENTAR/DIMINUIR A VELOCIDADE DO CAIXA");
        caixaMenu.addMenuListener(new MenuListener() {
            
            @Override
            public void menuSelected(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();
                }).start();

            }

            @Override
            public void menuDeselected(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();

                }).start();

            }

            @Override
            public void menuCanceled(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();
                }).start();

            }
        });
        
        turnoMenu.addMenuListener(new MenuListener() {
            @Override
            public void menuSelected(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();
                }).start();

            }

            @Override
            public void menuDeselected(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();

                }).start();

            }

            @Override
            public void menuCanceled(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();
                }).start();

            }
        });
        
        turnoFrentistasMenuItem.addActionListener((ActionEvent e) -> {

            ((TurnoFrentistasUIWindow) uIDelegator.getUI(TurnoFrentistasUIWindow.class)).raise();

        });
        
        turnoMenu.add(turnoFrentistasMenuItem);
        turnoMenu.add(turnoCaixasMenuItem);
        
        
        reservatorioMenuItem.addActionListener((ActionEvent e) -> {
            new Thread(() -> {
                MenuNavigator.setTo(reservatorioMenuItem.getName());
                MenuNavigator.navigate();
                try {
                    Thread.sleep(100);
                } catch (InterruptedException ex) {
                    Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                }
                ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                window.getReservatorioCombustiveisUI().setNivelTanques();
            }).start();
        });
        
        reservatorioMenu.add(reservatorioMenuItem);
        reservatorioMenu.setToolTipText("IR PARA TANQUES DE COMBUSTÍVEIS");
        reservatorioMenuItem.setToolTipText("CLIQUE PARA IR PARA TANQUES DE COMBUSTÍVEIS");
        reservatorioMenuItem.setIcon(tanqueCombustivelIcon);
        reservatorioMenu.addMenuListener(new MenuListener() {
            @Override
            public void menuSelected(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();
                }).start();

            }

            @Override
            public void menuDeselected(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();

                }).start();

            }

            @Override
            public void menuCanceled(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();
                }).start();

            }
        });
        
        

//        Frentista f1 = new Frentista(1, "JOLIE", "91273490", "329074", "/imagens/jolie+.jpg");
//        Frentista f2 = new Frentista(2, "FACEBOOK", "908345", "92374095", "/imagens/facebook+.jpg");
//        Frentista f3 = new Frentista(3, "JOINHA", "298374980", "245297", "/imagens/joinha+.jpg");
//        Frentista f4 = new Frentista(4, "BONITO", "2349702198347", "7095732495", "/imagens/bonito+.jpg");
//        Frentista f5 = new Frentista(5, "VAMPIRO", "398274987", "9073495", "/imagens/vampiro+.jpg");
//        Frentista f6 = new Frentista(6, "PINTADA", "298374", "2908345", "/imagens/PINTADA+.jpg");
        recursosHumanosAdmitirFrentistaMenuItem.setForeground(foreground);
        recursosHumanosAdmitirFrentistaMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

//                new Thread(new Runnable() {
//                    @Override
//                    public void run() {
//                        int sleep = 2000;
//                        try {
//                            ((PostoCombustivel) modelDelegator.getModelo(PostoCombustivel.class)).admitirFuncionario(f1);
//                            Thread.sleep(sleep);
//                            ((PostoCombustivel) modelDelegator.getModelo(PostoCombustivel.class)).admitirFuncionario(f2);
//                            Thread.sleep(sleep);
//                            ((PostoCombustivel) modelDelegator.getModelo(PostoCombustivel.class)).admitirFuncionario(f3);
//                            Thread.sleep(sleep);
//                            ((PostoCombustivel) modelDelegator.getModelo(PostoCombustivel.class)).admitirFuncionario(f4);
//                            Thread.sleep(sleep);
//                            ((PostoCombustivel) modelDelegator.getModelo(PostoCombustivel.class)).admitirFuncionario(f5);
//                            Thread.sleep(sleep);
//                            ((PostoCombustivel) modelDelegator.getModelo(PostoCombustivel.class)).admitirFuncionario(f6);
//                        } catch (PostoGasolinaException ex) {
//                            Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
//                        } catch (RecursosHumanosException ex) {
//                            Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
//                        } catch (InterruptedException ex) {
//                            Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
//                        }
//
//                    }
//                }).start();
            }
        });

        recursosHumanosDemitirFrentistaMenuItem.setForeground(foreground);
        recursosHumanosDemitirFrentistaMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

//                new Thread(new Runnable() {
//                    @Override
//                    public void run() {
//                        int sleep = 2000;
//                        try {
//                            ((PostoCombustivel) modelDelegator.getModelo(PostoCombustivel.class)).demitirFuncionario(f1);
//                            Thread.sleep(sleep);
//                            ((PostoCombustivel) modelDelegator.getModelo(PostoCombustivel.class)).demitirFuncionario(f2);
//                            Thread.sleep(sleep);
//                            ((PostoCombustivel) modelDelegator.getModelo(PostoCombustivel.class)).demitirFuncionario(f3);
//                            Thread.sleep(sleep);
//                            ((PostoCombustivel) modelDelegator.getModelo(PostoCombustivel.class)).demitirFuncionario(f4);
//                            Thread.sleep(sleep);
//                            ((PostoCombustivel) modelDelegator.getModelo(PostoCombustivel.class)).demitirFuncionario(f5);
//                            Thread.sleep(sleep);
//                            ((PostoCombustivel) modelDelegator.getModelo(PostoCombustivel.class)).demitirFuncionario(f6);
//                        } catch (PostoGasolinaException ex) {
//                            Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
//                        } catch (RecursosHumanosException ex) {
//                            Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
//                        } catch (InterruptedException ex) {
//                            Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
//                        }
//
//                    }
//                }).start();
            }
        });

        recursosHumanosAdmitirFrentistaMenuItem.setEnabled(false);
        recursosHumanosAdmitirFrentistaMenuItem.setIcon(recursosHumanoslAdmitirFuncionarioIcon);
        recursosHumanosDemitirFrentistaMenuItem.setEnabled(false);
        recursosHumanosDemitirFrentistaMenuItem.setIcon(recursosHumanoslDemitirFuncionarioIcon);
        recursosHumanosMenu.add(recursosHumanosAdmitirFrentistaMenuItem);
        recursosHumanosMenu.add(recursosHumanosDemitirFrentistaMenuItem);
        recursosHumanosMenu.addMenuListener(new MenuListener() {
            @Override
            public void menuSelected(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();
                }).start();

            }

            @Override
            public void menuDeselected(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();

                }).start();

            }

            @Override
            public void menuCanceled(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();
                }).start();

            }
        });

        //MENU RELATÓRIOS
        //constroi o menu de relatorios das bombas
        for (Object obj : this.uIDelegator.getUIs(ControleRemotoBombaCombustivelUI.class)) {

            ControleRemotoBombaCombustivelUI controleRemotoBombaUI = ((ControleRemotoBombaCombustivelUI) obj);

            JMenuItem bombaRelatorio = new JMenuItem(controleRemotoBombaUI.getModelo().toStringShorter());
            bombaRelatorio.setName(Integer.toString(controleRemotoBombaUI.getModelo().getId()));

            bombaRelatorio.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    int id = Integer.parseInt(((JMenuItem) (e.getSource())).getName());

                    uIDelegator.getControleRemotoBombaCombustivelUIById(id).getVerAbastecimentos().doClick();

                }
            });

            bombaRelatorio.setForeground(foreground);
            bombaRelatorio.setToolTipText("VER RELATÓRIO DA " + controleRemotoBombaUI.getModelo().toStringShorter());
            bombaRelatorio.setIcon(bombaCombustivelPretoRelatoriosIcon);

            relatoriosBombasMenu.add(bombaRelatorio);

        }
        relatoriosMenu.add(relatoriosBombasMenu);
        relatoriosBombasMenu.setIcon(bombaCombustivelPretoRelatoriosIcon);
        relatoriosMenu.addSeparator();

        //constroi o menu de relatorios dos caixas
        for (Object obj : this.uIDelegator.getUIs(CaixaUI.class)) {

            CaixaUI caixaUI = ((CaixaUI) obj);

            JMenuItem caixaRelatorio = new JMenuItem("CAIXA " + caixaUI.getModelo().getId());
            caixaRelatorio.setName(Integer.toString(caixaUI.getModelo().getId()));
            caixaRelatorio.setIcon(caixaRegistradoraRelatorioIcon);

            caixaRelatorio.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    MenuNavigator.setTo("PostoCombustivelUIWindow");
                    MenuNavigator.navigate();

                    int id = Integer.parseInt(((JMenuItem) (e.getSource())).getName());

                    uIDelegator.getCaixaUIById(id).getCaixaRelatorioWindow().setVisible(true);

                    uIDelegator.getCaixaUIById(id).getCaixaRelatorioWindow().setAlwaysOnTop(true);

                    uIDelegator.getCaixaUIById(id).getCaixaRelatorioWindow().wasOpenedFromMenu = true;

                    uIDelegator.getCaixaUIById(id).getCaixaRelatorioWindow().atualizar();

                }
            });

            caixaRelatorio.setForeground(foreground);
            relatoriosCaixasMenu.add(caixaRelatorio);

        }
        relatoriosMenu.add(relatoriosCaixasMenu);
        relatoriosCaixasMenu.setIcon(caixaRegistradoraRelatorioIcon);
        relatoriosMenu.addSeparator();

        //relatorios abastecimentos frentistas
        abrirRelatoriosFrentistasAbastecimentosMenuItem.setForeground(foreground);
        abrirRelatoriosFrentistasAbastecimentosMenuItem.setIcon(frentistasRelatorioAbastecimentosBombaCombustivelPretoIcon);
        abrirRelatoriosFrentistasAbastecimentosMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ((RelatoriosFrentistasAbastecimentosUIWindow) uIDelegator.getUI(RelatoriosFrentistasAbastecimentosUIWindow.class)).raise();
            }
        });

        relatoriosFrentistasMenu.add(abrirRelatoriosFrentistasAbastecimentosMenuItem);
        abrirRelatoriosFrentistasAbastecimentosMenuItem.setToolTipText("VER RELATÓRIOS ABASTECIMENTOS DOS FRENTISTAS ");

        relatoriosMenu.add(relatoriosFrentistasMenu);
        relatoriosMenu.addMenuListener(new MenuListener() {
            @Override
            public void menuSelected(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();
                }).start();

            }

            @Override
            public void menuDeselected(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();

                }).start();

            }

            @Override
            public void menuCanceled(MenuEvent e) {

                new Thread(() -> {

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) MenuNavigator.getUI("ReservatorioCombustiveisUIWindow"));
                    window.getReservatorioCombustiveisUI().setNivelTanques();
                }).start();

            }
        });
        

        //FIM MENU RELATÓRIOS
        add(sairMenu);

        add(iniciarMenu);

        bombasMenu.setVisible(false);
        add(bombasMenu);

        caixaMenu.setVisible(false);
        add(caixaMenu);
        
        turnoMenu.setVisible(false);
        add(turnoMenu);

        reservatorioMenu.setVisible(false);
        add(reservatorioMenu);

        recursosHumanosMenu.setVisible(false);
        add(recursosHumanosMenu);

        relatoriosMenu.setVisible(false);
        add(relatoriosMenu);

        configuracoesMenu.setVisible(false);
        add(configuracoesMenu);

        setFont(new Font("Arial", 1, 18));

    }

    public void setVisibleInvisibleMenus() {
        bombasMenu.setVisible(true);
        caixaMenu.setVisible(true);
        turnoMenu.setVisible(true);
        reservatorioMenu.setVisible(true);
        recursosHumanosMenu.setVisible(true);
        relatoriosMenu.setVisible(true);
        configuracoesMenu.setVisible(true);
        acenderApagarLuzMenuItem.setVisible(true);
    }

    public void reconfigureMenuIniciarParaAbrirPosto() {
//        iniciarMenu.doClick();
//        iniciarMenu.transferFocus();
    }

    private void acenderApagarLuzMenuTimerActionPerformed(ActionEvent e) {

        System.err.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  TIMIMG ");

//        if (iniciarMenu.getForeground().equals(Color.WHITE)) {
//           
//            iniciarMenu.setForeground(Color.BLACK);
//            iniciarMenu.doClick();
//
//        } else {
//            
//            iniciarMenu.setForeground(Color.WHITE);
//            iniciarMenu.doClick();
//            
//        }
    }

}
