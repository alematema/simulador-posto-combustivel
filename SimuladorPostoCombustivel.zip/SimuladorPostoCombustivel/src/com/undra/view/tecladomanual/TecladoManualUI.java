/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.tecladomanual;

import com.undra.app.util.OutPut;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 * UI do teclado manual
 *
 * @author alexandre
 */
public class TecladoManualUI extends JPanel {

    //os botoes do teclado
    private JButton zero;
    private JButton um;
    private JButton dois;
    private JButton tres;
    private JButton quatro;
    private JButton cinco;
    private JButton seis;
    private JButton sete;
    private JButton oito;
    private JButton nove;
    private JButton virgula;
    private JButton clear;
    //dimensao do botao
    private final Dimension dimensaoBotao = new Dimension(50, 50);

    //a fonte do teclado
    private final Font font = new Font("Ubuntu", Font.BOLD, 16);

    //a dimensao do teclado
    private final Dimension dimension = new Dimension(150, 200);

    //a cor do fundo
    private final Color background = Color.WHITE;

    //a cor de fundo dos botoes
    private final Color botaoBackground = Color.WHITE;

    //o valor do teclado;
    private float valor;

    //o valor do teclado as String;
    private String valorAsString;

    //o output pra onde se escrevera o valor
    private final OutPut out;

    public TecladoManualUI(OutPut out) {
        this.out = out;
        configure();
    }

    private void configure() {

        valor = 0f;
        valorAsString = "";

        setLayout(new GridBagLayout());
        setBackground(background);
        setPreferredSize(dimension);

        ActionListener algarismoClicado = (ActionEvent e) -> {

            try {

                valorAsString += ((JButton) e.getSource()).getName();
                parseFloat();
                out.setValue(valor);

            } catch (Exception ex) {
                 System.err.println("Algo excepcional ocorreu em TecladoManualUI.actionListener " + ex.getLocalizedMessage());
            }

        };

        GridBagConstraints gridConstraints = new GridBagConstraints();

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        um = new JButton("1");
        um.setFont(font);
        um.setPreferredSize(dimensaoBotao);
        um.setName("1");
        um.setBackground(botaoBackground);
        um.addActionListener(algarismoClicado);
        add(um, gridConstraints);

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        dois = new JButton("2");
        dois.setFont(font);
        dois.setPreferredSize(dimensaoBotao);
        dois.setName("2");
        dois.setBackground(botaoBackground);
        dois.addActionListener(algarismoClicado);
        add(dois, gridConstraints);

        gridConstraints.gridx = 2;
        gridConstraints.gridy = 0;
        tres = new JButton("3");
        tres.setFont(font);
        tres.setPreferredSize(dimensaoBotao);
        tres.setName("3");
        tres.setBackground(botaoBackground);
        tres.addActionListener(algarismoClicado);
        add(tres, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        quatro = new JButton("4");
        quatro.setFont(font);
        quatro.setPreferredSize(dimensaoBotao);
        quatro.setName("4");
        quatro.setBackground(botaoBackground);
        quatro.addActionListener(algarismoClicado);
        add(quatro, gridConstraints);

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        cinco = new JButton("5");
        cinco.setFont(font);
        cinco.setPreferredSize(dimensaoBotao);
        cinco.setName("5");
        cinco.setBackground(botaoBackground);
        cinco.addActionListener(algarismoClicado);
        add(cinco, gridConstraints);

        gridConstraints.gridx = 2;
        gridConstraints.gridy = 1;
        seis = new JButton("6");
        seis.setFont(font);
        seis.setPreferredSize(dimensaoBotao);
        seis.setName("6");
        seis.setBackground(botaoBackground);
        seis.addActionListener(algarismoClicado);
        add(seis, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        sete = new JButton("7");
        sete.setFont(font);
        sete.setPreferredSize(dimensaoBotao);
        sete.setName("7");
        sete.setBackground(botaoBackground);
        sete.addActionListener(algarismoClicado);
        add(sete, gridConstraints);

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 2;
        oito = new JButton("8");
        oito.setFont(font);
        oito.setPreferredSize(dimensaoBotao);
        oito.setName("8");
        oito.setBackground(botaoBackground);
        oito.addActionListener(algarismoClicado);
        add(oito, gridConstraints);

        gridConstraints.gridx = 2;
        gridConstraints.gridy = 2;
        nove = new JButton("9");
        nove.setFont(font);
        nove.setPreferredSize(dimensaoBotao);
        nove.setName("9");
        nove.setBackground(botaoBackground);
        nove.addActionListener(algarismoClicado);
        add(nove, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 3;
        zero = new JButton("0");
        zero.setFont(font);
        zero.setPreferredSize(dimensaoBotao);
        zero.setName("0");
        zero.setBackground(botaoBackground);
        zero.addActionListener(algarismoClicado);
        add(zero, gridConstraints);

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 3;
        virgula = new JButton(",");
        virgula.setFont(font);
        virgula.setPreferredSize(dimensaoBotao);
        virgula.setName(",");
        virgula.addActionListener((ActionEvent e) -> {
            virgula.setEnabled(false);
            virgula.setText(",");

            if (valorAsString.equals("")) {
                valorAsString += "0,";
            } else {
                valorAsString += ",";
            }
        });
        add(virgula, gridConstraints);

        gridConstraints.gridx = 2;
        gridConstraints.gridy = 3;
        clear = new JButton("C");
        clear.setFont(font);
        clear.setPreferredSize(dimensaoBotao);
        clear.setName("C");
        clear.addActionListener((ActionEvent e) -> {
            virgula.setEnabled(true);
            valorAsString = "";
            parseFloat();
            out.setValue(valor);
        });
        add(clear, gridConstraints);

    }

    private void parseFloat() {

        try {

            if (valorAsString.equals("")) {

                valor = 0f;

            } else {

                valor = Float.parseFloat(valorAsString.replaceAll(",", "."));

            }

        } catch (NumberFormatException e) {

            System.err.println("Algo excepcional ocorreu em TecladoManualUI.parseFloat " + e.getLocalizedMessage());

        }

    }

    public JButton getVirgula() {
        return virgula;
    }
    
    public JButton getClearButton(){
        return clear;
    }

}
