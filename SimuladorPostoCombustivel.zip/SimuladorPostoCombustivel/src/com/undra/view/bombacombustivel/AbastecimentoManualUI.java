package com.undra.view.bombacombustivel;

import com.undra.delegator.excpetion.DelegatorException;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.combustivel.bomba.excetion.BombaCombustivelException;
import com.undra.modelo.combustivel.reservatorio.exception.ReservatorioExeption;
import com.undra.modelo.contabilidade.exception.AbastecimentoException;
import com.undra.modelo.contabilidade.exception.CaixaException;
import com.undra.modelo.postocombustivel.PostoCombustivel;
import com.undra.modelo.postocombustivel.PostoGasolinaException;
import com.undra.modelo.recursoshumanos.Frentista;
import com.undra.modelo.recursoshumanos.Funcionario;
import com.undra.view.frentistasnesteturno.BancoDeFrentistasNesteTurnoUI;
import com.undra.view.interfaces.UI;
import com.undra.app.util.OutPut;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.view.tecladomanual.TecladoManualUI;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * UI do assitente abastecimento manual.
 *
 * @author alexandre
 */
public class AbastecimentoManualUI extends JPanel implements UI, OutPut {

    private AbastecimentoManualWindow abastecimentoManualWindow;
    private JLabel nomeFrentistaJLabel;
    private JLabel placeHolderFrentistaFoto;
    public final ImageIcon semFotoIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/semFotoDisabled.png"));
    private TecladoManualUI tecladoManual;

    JPanel fotoENomeFrentista;

    Frentista frentista;

    private JPanel okCancelarPanel;
    private JButton OKButton;
    private JButton cancelarButton;

    private final Font font = new Font("Ubuntu", Font.BOLD, 14);

    public volatile boolean isRaised = false; // volatile forces memory barrier crossing
    public volatile boolean isSetandoValorCombustivel = false; // volatile forces memory barrier crossing

    private ActionListener cancelarButtonActionListener;
    private ActionListener okButtonActionListener;
    private ActionListener cancelarButtonSetandoPrecoCombustivelActionListener;
    private ActionListener okButtonSetandoPrecoCombustivelActionListener;
    private float valorCombustivel;

    public AbastecimentoManualUI(AbastecimentoManualWindow abastecimentoManualWindow) {

        if (abastecimentoManualWindow == null) {
            throw new NullPointerException("O window do abastecimento manual não pode ser null");
        }

        this.abastecimentoManualWindow = abastecimentoManualWindow;

        configure();

    }

    private void configure() {

        setLayout(new GridBagLayout());

        setBackground(abastecimentoManualWindow.getContentPane().getBackground());

        abastecimentoManualWindow.getModeloUI().getuIDelegator().registrarUI(this);
        setPreferredSize(new Dimension(abastecimentoManualWindow.getPreferredSize().width - 40, 350));

        Dimension placeHolderDimension = new Dimension(60, 60);

        tecladoManual = new TecladoManualUI(this);
        tecladoManual.setPreferredSize(new Dimension(150, 200));

        GridBagConstraints gridConstraints = new GridBagConstraints();

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(0, 0, 0, getPreferredSize().width - tecladoManual.getPreferredSize().width);

        add(tecladoManual, gridConstraints);

        nomeFrentistaJLabel = new JLabel();

        nomeFrentistaJLabel.setPreferredSize(new Dimension(2 * placeHolderDimension.width, placeHolderDimension.height));

        fotoENomeFrentista = new JPanel(new GridBagLayout());
        fotoENomeFrentista.setPreferredSize(new Dimension(placeHolderDimension.width + nomeFrentistaJLabel.getPreferredSize().width + 30, placeHolderDimension.height));
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(10, 0, 0, getPreferredSize().width - fotoENomeFrentista.getPreferredSize().width);

        add(fotoENomeFrentista, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;

        placeHolderFrentistaFoto = new JLabel(semFotoIcon);
        placeHolderFrentistaFoto.setPreferredSize(placeHolderDimension);

        gridConstraints.insets = new Insets(0, 0, 0, fotoENomeFrentista.getPreferredSize().width - placeHolderFrentistaFoto.getPreferredSize().width);

        fotoENomeFrentista.add(placeHolderFrentistaFoto, gridConstraints);

        nomeFrentistaJLabel.setText("FRENTISTA ?");

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.EAST;
        gridConstraints.insets = new Insets(0, 10, 0, 0);

        fotoENomeFrentista.setBackground(abastecimentoManualWindow.getContentPane().getBackground());
        fotoENomeFrentista.add(nomeFrentistaJLabel, gridConstraints);

        okCancelarPanel = new JPanel(new GridBagLayout());

        okCancelarPanel.setPreferredSize(new Dimension(fotoENomeFrentista.getPreferredSize().width, fotoENomeFrentista.getPreferredSize().height / 2));
        okCancelarPanel.setBackground(abastecimentoManualWindow.getContentPane().getBackground());

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(10, 0, 0, 0);

        add(okCancelarPanel, gridConstraints);

        OKButton = new JButton("OK");
        OKButton.setFont(font);
        OKButton.setEnabled(false);

        okButtonActionListener = (ActionEvent e) -> {

            try {

                float quantidadeCombustivel;

                if (abastecimentoManualWindow.getOutPut().getNome().equals(BombaCombustivelUI.INFORMADO_DINHEIRO)) {

                    quantidadeCombustivel = abastecimentoManualWindow.getOutPut().getValor() / abastecimentoManualWindow.getModeloUI().getDisplayValorUnidadeCombustivel().getValor();

                } else {

                    quantidadeCombustivel = abastecimentoManualWindow.getOutPut().getValor();

                }

                if (frentista != null) {

                    PostoCombustivel postoCombustivel = (PostoCombustivel) abastecimentoManualWindow.getModeloUI().getModelo().getModelDelegator().getModelo(PostoCombustivel.class);

                    BombaCombustivel bombaCombustivel = abastecimentoManualWindow.getModeloUI().getModelo();

                    bombaCombustivel.alocar();

                    postoCombustivel.abastecer(frentista, bombaCombustivel, quantidadeCombustivel);

                }

            } catch (DelegatorException | BombaCombustivelException | ReservatorioExeption | AbastecimentoException | CaixaException | PostoGasolinaException ex) {

                System.err.println("Algo excepcional ocorreu em AbastecimentoManualUI.OKButton.actionPerformed " + ex.getLocalizedMessage());

                abastecimentoManualWindow.getModeloUI().getModelo().getModelDelegator().desbloquearBomba(abastecimentoManualWindow.getModeloUI().getModelo());
                devolverFrentistaAoBanco();
                abastecimentoManualWindow.getOutPut().setValor(0f);

                abastecimentoManualWindow.fade();
                OKButton.setEnabled(false);

            } finally {
                OKButton.setEnabled(false);
                abastecimentoManualWindow.fade();
            }
        };

        OKButton.addActionListener(okButtonActionListener);

        cancelarButton = new JButton("CANCELAR");
        cancelarButton.setFont(font);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(0, 0, 0, 40);

        okCancelarPanel.add(OKButton, gridConstraints);
        okCancelarPanel.add(cancelarButton);

        cancelarButtonActionListener = (ActionEvent e) -> {

            try {

                abastecimentoManualWindow.getModeloUI().getModelo().getModelDelegator().desbloquearBomba(abastecimentoManualWindow.getModeloUI().getModelo());
                devolverFrentistaAoBanco();
                abastecimentoManualWindow.getOutPut().setValor(0f);

            } catch (Exception ex) {

                System.err.println("Algo excepcional ocorreu em AbastecimentoManualUI.CancelarButton.actionPerformed " + ex.getLocalizedMessage());

            } finally {
                abastecimentoManualWindow.fade();
                OKButton.setEnabled(false);
            }
        };

        cancelarButton.addActionListener(cancelarButtonActionListener);

        okButtonSetandoPrecoCombustivelActionListener = (ActionEvent e) -> {

            try {

                Combustivel combustivel = abastecimentoManualWindow.getModeloUI().getModelo().getCombustivel();

                float novoPreco = abastecimentoManualWindow.getOutPut().getValor();

                abastecimentoManualWindow.getModeloUI().getModelDelegator().atualizarPrecoCombustivelEmTodasBombasDesteCombustivel(combustivel, novoPreco);

            } catch (Exception ex) {

                System.err.println("Algo excepcional ocorreu em AbastecimentoManualUI.OKButtonSetandoValorCombustivel.actionPerformed " + ex.getLocalizedMessage());

            } finally {

                OKButton.removeActionListener(okButtonSetandoPrecoCombustivelActionListener);
                OKButton.addActionListener(okButtonActionListener);

                isSetandoValorCombustivel = false;

                OKButton.setEnabled(false);
                fotoENomeFrentista.setVisible(true);

                abastecimentoManualWindow.fade();
                abastecimentoManualWindow.getModeloUI().getModelo().getModelDelegator().desbloquearBomba(abastecimentoManualWindow.getModeloUI().getModelo());

                abastecimentoManualWindow.setTituloDaJanela("ASSISTENTE DE ABASTECIMENTO MANUAL");

            }
        };

        cancelarButtonSetandoPrecoCombustivelActionListener = (ActionEvent e) -> {

            try {

                abastecimentoManualWindow.getOutPut().setValor(getValorCombustivel());
                abastecimentoManualWindow.getModeloUI().getModelo().getModelDelegator().desbloquearBomba(abastecimentoManualWindow.getModeloUI().getModelo());

            } catch (Exception ex) {

                System.err.println("Algo excepcional ocorreu em AbastecimentoManualUI.CancelarButtonSetandoPrecoCombustivel.actionPerformed " + ex.getLocalizedMessage());

            } finally {

                cancelarButton.removeActionListener(cancelarButtonSetandoPrecoCombustivelActionListener);
                cancelarButton.addActionListener(cancelarButtonActionListener);

                isSetandoValorCombustivel = false;

                abastecimentoManualWindow.fade();

                abastecimentoManualWindow.setTituloDaJanela("ASSISTENTE DE ABASTECIMENTO MANUAL");

                fotoENomeFrentista.setVisible(true);
                OKButton.setEnabled(false);

            }
        };

    }

    private void devolverFrentistaAoBanco() {

        try {

            frentista.setEstado(Funcionario.PRONTO);

            BancoDeFrentistasNesteTurnoUI bancoDeFrentistaNesteTurnoUI = (BancoDeFrentistasNesteTurnoUI) abastecimentoManualWindow.getModeloUI().getuIDelegator().getUI(BancoDeFrentistasNesteTurnoUI.class);

            bancoDeFrentistaNesteTurnoUI.devolverFrentistaAoBancoDeReserva(frentista);

            frentista = null;

            nomeFrentistaJLabel.setText("FRENTISTA ?");
            placeHolderFrentistaFoto.setIcon(semFotoIcon);

        } catch (Exception ex) {

            System.err.println("Algo excepcional ocorreu em AbastecimentoManualUI.devolverFrentistaAoBanco " + ex.getLocalizedMessage());

        }

    }

    public JLabel getNomeFrentistaJLabel() {
        return nomeFrentistaJLabel;
    }

    public JLabel getPlaceHolderFrentistaFoto() {
        return placeHolderFrentistaFoto;
    }

    public void setFrentista(Frentista frentista) {
        this.frentista = frentista;
    }

    public Frentista getFrentista() {
        return frentista;
    }

    public JButton getCancelarButton() {
        return cancelarButton;
    }

    @Override
    public float getValue() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setValue(float value) {

        try {

            if (!isSetandoValorCombustivel) {// settando quantidade do combustivel ou total em dinheiro dele.

                if (value <= abastecimentoManualWindow.getOutPut().getMAX_VALUE()) {

                    abastecimentoManualWindow.getOutPut().setValor(value);

                    float quantidadeCombustivel;
                    float totalDinheiro;

                    if (abastecimentoManualWindow.getOutPut().getNome().equals(BombaCombustivelUI.INFORMADO_DINHEIRO)) {

                        quantidadeCombustivel = abastecimentoManualWindow.getOutPut().getValor() / abastecimentoManualWindow.getModeloUI().getDisplayValorUnidadeCombustivel().getValor();
                        abastecimentoManualWindow.getModeloUI().getDisplayTotalUnidadeCombustivel().setValor(quantidadeCombustivel);

                    } else {

                        totalDinheiro = abastecimentoManualWindow.getOutPut().getValor() * abastecimentoManualWindow.getModeloUI().getDisplayValorUnidadeCombustivel().getValor();
                        abastecimentoManualWindow.getModeloUI().getDisplayTotalDinheiro().setValor(totalDinheiro);
                    }

                } else {

                    abastecimentoManualWindow.getOutPut().setValor(abastecimentoManualWindow.getOutPut().getMAX_VALUE());

                }

            } else {//setando preço da unidade do combustível... e já atualiza o valor em todas as bombas deste combustível 

                abastecimentoManualWindow.getOutPut().setValor(value);

//                Combustivel combustivel = abastecimentoManualWindow.getModeloUI().getModelo().getCombustivel();
//
//                abastecimentoManualWindow.getModeloUI().getModelDelegator().atualizarPrecoCombustivelEmTodasBombasDesteCombustivel(combustivel, value);
            }

        } catch (Exception e) {
            System.err.println("Algo excepcional ocorreu em AbastecimentoManualUI.setValue " + e.getLocalizedMessage());
        }

    }

    public JButton getOKButton() {
        return OKButton;
    }

    public TecladoManualUI getTecladoManual() {
        return tecladoManual;
    }

    public void configureParaSetarPreçoCombustivel() {

        isSetandoValorCombustivel = true;

        abastecimentoManualWindow.setTituloDaJanela("ATUALIZE PREÇO DO " + abastecimentoManualWindow.getModeloUI().getModelo().getCombustivel().getNome());

        fotoENomeFrentista.setVisible(false);

        setValorCombustivel(abastecimentoManualWindow.getOutPut().getValor());

        OKButton.removeActionListener(okButtonActionListener);
        OKButton.addActionListener(okButtonSetandoPrecoCombustivelActionListener);

        cancelarButton.removeActionListener(cancelarButtonActionListener);
        cancelarButton.addActionListener(cancelarButtonSetandoPrecoCombustivelActionListener);

    }

    public float getValorCombustivel() {
        return valorCombustivel;
    }

    public void setValorCombustivel(float valorCombustivel) {
        this.valorCombustivel = valorCombustivel;
    }

    @Override
    public String toString() {
        return "ABASTECIMENTO MANUAL UI " + abastecimentoManualWindow.getModeloUI().getModelo().getId();
    }

}
