package com.undra.view.turno;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.modelo.recursoshumanos.Frentista;
import com.undra.view.interfaces.FadableAndRaisableUI;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * Window do Turno Frentistas UI
 *
 * @author alexandre
 */
public class TurnoFrentistasUIWindow extends JFrame implements TurnoFrentistasUI, FadableAndRaisableUI {

    private TurnoFrentistasUIImpl turnoFrentistasUIImpl;

    private ModelDelegator modelDelegator;
    private UIDelegator uIDelegator;

    private JPanel turnoFrentistasHeader;
    private JCheckBox onOff;
    private JLabel headerLabel;
    private final Font headerFont = new Font("Ubuntu", Font.BOLD, 14);
    private final ImageIcon offIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/off.24x12.png"));
    private String tituloDaJanela;

    private JTabbedPane frentistasTabbedPane;

    public TurnoFrentistasUIWindow(ModelDelegator modelDelegator, UIDelegator uIDelegator) {

        if (uIDelegator == null) {
            throw new NullPointerException("O UIDelegator não pode ser null");
        }
        if (modelDelegator == null) {
            throw new NullPointerException("O ModelDelegator não pode ser null");
        }

        this.modelDelegator = modelDelegator;
        this.uIDelegator = uIDelegator;

        frentistasTabbedPane = new JTabbedPane();

        registrarNoUIDelegator();

        configure();

    }

    private void registrarNoUIDelegator() {
        uIDelegator.registrarUI(this);
    }

    public final void configure() {

        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
            if ("GTK+".equals(info.getName())) {
                try {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                    Logger.getLogger(TurnoFrentistasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
                break;
            }
        }

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }

        });

        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        setTitle("Turno de frentistas - SIMULADOR POSTO COMBUSTÍVEL");

        getContentPane().setBackground(Color.WHITE);

        setResizable(false);

        setUndecorated(true);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        pack();

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

    }

    public void configureAndShow() {

        configure();

        setVisible(true);

    }

    private void placeComponentsAtFrame() {

        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints();

        turnoFrentistasUIImpl = new TurnoFrentistasUIImpl(modelDelegator, uIDelegator, "MANHÃ");

        turnoFrentistasHeader = new JPanel();
        turnoFrentistasHeader.setPreferredSize(new Dimension(turnoFrentistasUIImpl.getPreferredSize().width+30, 25));
        turnoFrentistasHeader.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1, true));
        turnoFrentistasHeader.setBackground(Color.WHITE);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.NORTH;
        gridConstraints.insets = new Insets(0, 0, 5, 0);

        add(turnoFrentistasHeader, gridConstraints);

        turnoFrentistasHeader.setLayout(new GridBagLayout());

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;

        onOff = new JCheckBox();
        onOff.setToolTipText("CLIQUE PARA FECHAR");

        onOff.setSelected(false);
        onOff.setIcon(offIcon);
        onOff.setPreferredSize(new Dimension(26, 20));

        gridConstraints.insets = new Insets(5, 0, 5, ((int) turnoFrentistasHeader.getPreferredSize().width) - onOff.getPreferredSize().width);

        onOff.addActionListener(this::onOffButtonActionPerformed);

        turnoFrentistasHeader.add(onOff, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(0, 25, 0, 0);

        headerLabel = new JLabel("TURNOS FRENTISTAS");
        headerLabel.setForeground(Color.BLACK);
        headerLabel.setFont(headerFont);
        turnoFrentistasHeader.add(headerLabel, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(15, 25, 30, 0);

        frentistasTabbedPane.setBackground(Color.LIGHT_GRAY);
        frentistasTabbedPane.setPreferredSize(new Dimension(turnoFrentistasUIImpl.getPreferredSize().width , turnoFrentistasUIImpl.getPreferredSize().height + 30));
        add(frentistasTabbedPane, gridConstraints);
        
        

        TurnoFrentistasUIImpl turnoFrentistasNoite = new TurnoFrentistasUIImpl(modelDelegator, uIDelegator, "NOITE");
        frentistasTabbedPane.add(turnoFrentistasNoite.getNome(), turnoFrentistasNoite);//noite
        
        TurnoFrentistasUIImpl turnoFrentistasTarde = new TurnoFrentistasUIImpl(modelDelegator, uIDelegator, "TARDE");//tarde
        frentistasTabbedPane.add(turnoFrentistasTarde.getNome(), turnoFrentistasTarde);
        
        frentistasTabbedPane.add(turnoFrentistasUIImpl.getNome(), turnoFrentistasUIImpl);//manha
        
        frentistasTabbedPane.setSelectedIndex(1);

    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }

    @Override
    public void setFrentistas(Frentista frentista) {
        turnoFrentistasUIImpl.setFrentistas(frentista);
    }

    @Override
    public void addFrentista(Frentista frentista) {
        turnoFrentistasUIImpl.addFrentista(frentista);
    }

    @Override
    public void removeFrentista(Frentista frentista) {
        turnoFrentistasUIImpl.removeFrentista(frentista);
    }

    @Override
    public Collection<Frentista> getFrentistasNesteTurno() {
        return turnoFrentistasUIImpl.getFrentistasNesteTurno();
    }

    private void onOffButtonActionPerformed(ActionEvent e) {
        fade();
    }

    @Override
    public void fade() {

        new Thread(() -> {

            for (int i = 100; i > 1; i--) {

                setOpacity(i / 100.0f);

                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(TurnoFrentistasUIImpl.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            setVisible(false);

        }).start();

    }

    @Override
    public void raise() {

        new Thread(() -> {

            setAlwaysOnTop(true);
            try {
                setOpacity(0.11f);
            } catch (Exception e) {
            }

            setVisible(true);
            float opacity1 = 1.0f;

            for (int i = 0; i < 95; i++) {

                setOpacity(i / 100.0f);

                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(TurnoFrentistasUIImpl.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

            requestFocus();

        }).start();

    }

    @Override
    public String getNome() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
