package com.undra.view.turno;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.modelo.postocombustivel.PostoCombustivel;
import com.undra.modelo.recursoshumanos.Frentista;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * UI do turno frentistas
 *
 * @author alexandre
 */
public class TurnoFrentistasUIImpl extends JPanel implements TurnoFrentistasUI {

    private final Collection<Frentista> frentistas = new ArrayList();
    private final Collection<Frentista> frentistasNoTurno = new ArrayList();
    private final Font font = new Font("Ubuntu", Font.ITALIC, 13);

    private final JList<String> frentistaList = new JList();
    private final DefaultListModel frentistasListModel = new DefaultListModel();

    static public final String FRENTISTA_NO_TURNO = ", no turno";

    private final JScrollPane frentistasListScrollPanel = new JScrollPane();

    private ModelDelegator modelDelegator;
    private UIDelegator uIDelegator;

    private JPanel turnoFrentistasHeader;
    private JCheckBox onOff;
    private JLabel headerLabel;
    private final Font headerFont = new Font("Ubuntu", Font.BOLD, 14);
    private final ImageIcon offIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/off.24x12.png"));
    private String tituloDaJanela;

    private String nome;

    public TurnoFrentistasUIImpl(ModelDelegator modelDelegator, UIDelegator uIDelegator, String nome) {

        if (uIDelegator == null) {
            throw new NullPointerException("O UIDelegator não pode ser null");
        }
        if (modelDelegator == null) {
            throw new NullPointerException("O ModelDelegator não pode ser null");
        }

        this.modelDelegator = modelDelegator;
        this.uIDelegator = uIDelegator;
        this.nome = nome;

        registrarNoUIDelegator();

        configure();

    }

    private void registrarNoUIDelegator() {
        uIDelegator.registrarUI(this);
    }

    public void configureAndShow() {

        configure();
        setVisible(true);

    }

    public final void configure() {

        frentistaList.setModel(frentistasListModel);
        frentistaList.setCellRenderer(new MyCellRenderer());

        setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints();

        MouseListener mouseListener = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                Frentista frentista = null;

                int index = frentistaList.locationToIndex(e.getPoint());

                String s = (String) frentistasListModel.getElementAt(index);

                try {

                    int id = Integer.parseInt(s.split(",")[1].split("id")[1].trim());

                    frentista = getFrentistaById(id);

                } catch (NumberFormatException ex) {

                    throw new IllegalArgumentException("Não foi possivel parsear " + s + " para extrair o id do frentista ");

                }

                if (e.getClickCount() == 1) {

                    if (!frentista.isOcupado()) {

                        if (s.contains(FRENTISTA_NO_TURNO)) {//tira do turno

                            s = s.replaceAll(FRENTISTA_NO_TURNO, "");

                            removeFrentistaDoTurno(frentista);

                        } else {//poe no turno

                            s += FRENTISTA_NO_TURNO;

                            addFrentistaNoTurno(frentista);

                        }

                        frentistasListModel.setElementAt(s, index);
                    }

                }

            }

        };

        frentistaList.addMouseListener(mouseListener);

        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
            if ("GTK+".equals(info.getName())) {
                try {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                    Logger.getLogger(TurnoFrentistasUIImpl.class.getName()).log(Level.SEVERE, null, ex);
                }
                break;
            }
        }

        setPreferredSize(new Dimension(Toolkit.getDefaultToolkit().getScreenSize().width / 4, Toolkit.getDefaultToolkit().getScreenSize().height / 3));

        frentistasListScrollPanel.setPreferredSize(new Dimension(getPreferredSize().width - 10, getPreferredSize().height - 20));

        frentistasListScrollPanel.setViewportView(frentistaList);

        frentistaList.setModel(frentistasListModel);

        rebuild();

    }

    private void rebuild() {

        if (frentistas.isEmpty()) {

            removeAll();

            frentistasListModel.clear();

            frentistaList.removeAll();

            repaint();

            //preguiça para centralizar automaticamente
            JLabel semFrentistasNoBancoDeDados = new JLabel("SEM FRENTISTAS NO RH PARA DEFINIR ESTE TURNO");

            semFrentistasNoBancoDeDados.setFont(font);

            add(semFrentistasNoBancoDeDados);

        } else {

            removeAll();

            frentistasListModel.clear();

            repaint();

            frentistas.forEach((Frentista frentista) -> {

                String nome = frentista.getNome();

                try {

                    nome = nome.substring(0, 10);

                } catch (Exception e) {
                }

                frentistasListModel.addElement(nome + ", id " + frentista.getId());
            });

            add(frentistasListScrollPanel);

            repaint();

        }

    }

    private Frentista getFrentistaById(int id) {

        Frentista frentista = null;

        for (Frentista f : frentistas) {

            if (f.getId().equals(id)) {
                frentista = f;
                break;
            }

        }

        return frentista;

    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }

    @Override
    public void setFrentistas(Frentista frentista) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Collection<Frentista> getFrentistasNesteTurno() {
        return frentistasNoTurno;
    }

    private void addFrentistaNoTurno(Frentista frentista) {

        frentistasNoTurno.add(frentista);

        new Thread(() -> {
            //ATUALIZA MODEL
            ((PostoCombustivel) modelDelegator.getModelo(PostoCombustivel.class)).addFrentistaNesteTurno(frentista);
        }).start();

    }

    @Override
    public String getNome() {
        return nome;
    }

    /**
     * Add frentista à lista de frentistas admitidos pelo RH.<br>
     * Desta lista é que fentistas serão escolhidos para formar um turno.
     *
     * @param frentista o frentista
     */
    @Override
    public void addFrentista(Frentista frentista) {

        if (frentista != null) {

            frentistas.add(frentista);

            rebuild();

        }

    }

    private void removeFrentistaDoTurno(Frentista frentista) {

        if (!frentista.isOcupado()) {

            frentista.setEstado(Frentista.EM_ESPERA);

            frentistasNoTurno.remove(frentista);

            new Thread(() -> {
                //ATUALIZA MODEL
                ((PostoCombustivel) modelDelegator.getModelo(PostoCombustivel.class)).removeFrentistaDoTurno(frentista);

                frentista.setEstado(Frentista.PRONTO);

            }).start();

        } else {

            System.err.println("frentita " + frentista.getNome() + " esta abastecendo ");

        }

    }

    @Override
    public void removeFrentista(Frentista frentista) {

        if (frentista != null) {

            if (frentistas.remove(frentista)) {
            }

            rebuild();

        }
    }

}

class MyCellRenderer extends JLabel implements ListCellRenderer<Object> {

    final ImageIcon selectedIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/selectedbox.png"));
    final ImageIcon unselectedIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/unselectedbox.png"));

    // This is the only method defined by ListCellRenderer.
    // We just reconfigure the JLabel each time we're called.
    @Override
    public Component getListCellRendererComponent(
            JList<?> list, // the list
            Object value, // value to display
            int index, // cell index
            boolean isSelected, // is the cell selected
            boolean cellHasFocus) // does the cell have focus
    {
        String s = value.toString();

        setText(s);

        setIcon((s.contains(TurnoFrentistasUIImpl.FRENTISTA_NO_TURNO)) ? selectedIcon : unselectedIcon);

        setToolTipText((s.contains(TurnoFrentistasUIImpl.FRENTISTA_NO_TURNO)) ? "CLIQUE PARA TIRAR O FRENTISTA DESTE TURNO" : "CLIQUE PARA COLOCAR O FRENTISTA NESTE TURNO");

        setEnabled(list.isEnabled());
        setFont(list.getFont());
        setOpaque(true);

        return this;
    }
}
