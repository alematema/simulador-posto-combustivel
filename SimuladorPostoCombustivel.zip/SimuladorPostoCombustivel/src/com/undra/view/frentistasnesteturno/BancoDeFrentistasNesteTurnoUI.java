package com.undra.view.frentistasnesteturno;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.modelo.recursoshumanos.Frentista;
import com.undra.modelo.recursoshumanos.Funcionario;
import com.undra.view.bombacombustivel.AbastecimentoManualUI;
import com.undra.view.interfaces.UI;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 * UI dos frentistas neste turno.
 *
 * @author alexandre
 */
public class BancoDeFrentistasNesteTurnoUI extends JPanel implements UI {

    private final int MAX_FRENTISTAS_POR_TURNO = 8;

    private Collection<Frentista> frentistasNesteTurno;
    private UIDelegator uIDelegator;
    private ModelDelegator modelDelegator;

    //os oito placeholders dos frentistas desse turno
    private JLabel frentistaPlaceHolder0;
    private JLabel frentistaPlaceHolder1;
    private JLabel frentistaPlaceHolder2;
    private JLabel frentistaPlaceHolder3;
    private JLabel frentistaPlaceHolder4;
    private JLabel frentistaPlaceHolder5;
    private JLabel frentistaPlaceHolder6;
    private JLabel frentistaPlaceHolder7;

    private final JLabel[] bancoDeReservaArray;

    private final ImageIcon semFotoIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/semFotoDisabled.png"));
    private final ImageIcon semFotoDisabledIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/semFotoDisabled.png"));

    private final SecureRandom secureRandom = new SecureRandom();

    private final List<Integer> freePlaces = new ArrayList();

    private volatile boolean isShuffling = false;// volatile forces memory barrier crossing
    private volatile boolean mustWait = false;// volatile forces memory barrier crossing

    private final List<JLabel> bancoReservaList = new ArrayList();
    private final Timer shufflerTimer = new Timer(2500, this::shufflerTimerActionPerformed);

    public BancoDeFrentistasNesteTurnoUI(Collection<Frentista> frentistasNesteTurno, UIDelegator uIDelegator) {

        if (frentistasNesteTurno == null) {
            throw new NullPointerException("Os frentistas precisam fazer frente a esse negocio. Passe uma colecao não nula.");
        }
        frentistasNesteTurno.forEach((f) -> {
            if (f == null) {
                throw new NullPointerException("O frentista não pode ser null !!!");
            }
        });

        if (uIDelegator == null) {
            throw new NullPointerException("O UIDelegator não pode ser null !!!");
        }

        this.frentistasNesteTurno = frentistasNesteTurno;
        this.uIDelegator = uIDelegator;

        bancoDeReservaArray = new JLabel[8];

        registrarNoUIDelegator();

        configure();

    }

    private void registrarNoUIDelegator() {
        uIDelegator.registrarUI(this);
    }

    private void configure() {

        setPreferredSize(new Dimension(240, 120));
        setLayout(new GridBagLayout());

        Dimension placeHolderDimension = new Dimension(60, 60);

        GridBagConstraints gridConstraints = new GridBagConstraints();

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;

        frentistaPlaceHolder0 = new JLabel(semFotoIcon);
        frentistaPlaceHolder0.setPreferredSize(placeHolderDimension);
        frentistaPlaceHolder0.setName("freePlace");

        add(frentistaPlaceHolder0, gridConstraints);
        bancoDeReservaArray[0] = frentistaPlaceHolder0;

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        frentistaPlaceHolder1 = new JLabel(semFotoIcon);
        frentistaPlaceHolder1.setPreferredSize(placeHolderDimension);
        frentistaPlaceHolder1.setName("freePlace");

        add(frentistaPlaceHolder1, gridConstraints);
        bancoDeReservaArray[1] = frentistaPlaceHolder1;

        gridConstraints.gridx = 2;
        gridConstraints.gridy = 0;
        frentistaPlaceHolder2 = new JLabel(semFotoIcon);
        frentistaPlaceHolder2.setPreferredSize(placeHolderDimension);
        frentistaPlaceHolder2.setName("freePlace");

        add(frentistaPlaceHolder2, gridConstraints);
        bancoDeReservaArray[2] = frentistaPlaceHolder2;

        gridConstraints.gridx = 3;
        gridConstraints.gridy = 0;
        frentistaPlaceHolder3 = new JLabel(semFotoIcon);
        frentistaPlaceHolder3.setPreferredSize(placeHolderDimension);
        frentistaPlaceHolder3.setName("freePlace");

        add(frentistaPlaceHolder3, gridConstraints);
        bancoDeReservaArray[3] = frentistaPlaceHolder3;

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        frentistaPlaceHolder4 = new JLabel(semFotoIcon);
        frentistaPlaceHolder4.setPreferredSize(placeHolderDimension);
        frentistaPlaceHolder4.setName("freePlace");

        add(frentistaPlaceHolder4, gridConstraints);
        bancoDeReservaArray[4] = frentistaPlaceHolder4;

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        frentistaPlaceHolder5 = new JLabel(semFotoIcon);
        frentistaPlaceHolder5.setPreferredSize(placeHolderDimension);
        frentistaPlaceHolder5.setName("freePlace");

        add(frentistaPlaceHolder5, gridConstraints);
        bancoDeReservaArray[5] = frentistaPlaceHolder5;

        gridConstraints.gridx = 2;
        gridConstraints.gridy = 1;
        frentistaPlaceHolder6 = new JLabel(semFotoIcon);
        frentistaPlaceHolder6.setPreferredSize(placeHolderDimension);
        frentistaPlaceHolder6.setName("freePlace");

        add(frentistaPlaceHolder6, gridConstraints);
        bancoDeReservaArray[6] = frentistaPlaceHolder6;

        gridConstraints.gridx = 3;
        gridConstraints.gridy = 1;
        frentistaPlaceHolder7 = new JLabel(semFotoIcon);
        frentistaPlaceHolder7.setPreferredSize(placeHolderDimension);
        frentistaPlaceHolder7.setName("freePlace");

        add(frentistaPlaceHolder7, gridConstraints);
        bancoDeReservaArray[7] = frentistaPlaceHolder7;

        for (JLabel placeHolder : bancoDeReservaArray) {

            placeHolder.setToolTipText("POSIÇÃO LIVRE");

            placeHolder.addMouseListener(new MouseAdapter() {

                @Override
                public void mouseClicked(MouseEvent e) {

                    if (!uIDelegator.isAnyAbastecimentoManualUIRaised()) {
                        return;
                    }

                    try {

                        Frentista frentista = getFrentistaById(placeHolder.getName());

                        if (frentista != null) {

                            frentista.alocar();

                            List<UI> abastecimentoManualUIList = uIDelegator.getUIs(AbastecimentoManualUI.class);

                            abastecimentoManualUIList.stream().map((abastecimentoManualUI) -> {

                                //retorna pro banco algum frentista que estava alocado para abastecimento manual
                                if (((AbastecimentoManualUI) abastecimentoManualUI).getFrentista() != null) {

                                    ((AbastecimentoManualUI) abastecimentoManualUI).getFrentista().setEstado(Funcionario.PRONTO);

                                    devolverFrentistaAoBancoDeReserva(((AbastecimentoManualUI) abastecimentoManualUI).getFrentista());

                                    ((AbastecimentoManualUI) abastecimentoManualUI).setFrentista(null);

                                }

                                ((AbastecimentoManualUI) abastecimentoManualUI).setFrentista(frentista);

                                ((AbastecimentoManualUI) abastecimentoManualUI).getOKButton().setEnabled(true);

                                return abastecimentoManualUI;

                            }).map((abastecimentoManualUI) -> {
                                ((AbastecimentoManualUI) abastecimentoManualUI).getPlaceHolderFrentistaFoto().setIcon(placeHolder.getIcon());
                                return abastecimentoManualUI;
                            }).forEachOrdered((abastecimentoManualUI) -> {
                                ((AbastecimentoManualUI) abastecimentoManualUI).getNomeFrentistaJLabel().setText(frentista.getNome());
                            });

                            borrowFrentistaDoBancoReserva(frentista);

                        }

                    } catch (Exception e2) {
                        System.err.println("Algo excepcional ocorreu em BancoFrentistasNesteTurnoUI.mouseClicked " + e2.getLocalizedMessage());
                    }

                }

            });

        }

        clean();
        build();

        shufflerTimer.start();

    }

    private void clean() {

        for (JLabel placeHolder : bancoDeReservaArray) {

            placeHolder.setName("freePlace");
            placeHolder.setIcon(semFotoIcon);
            placeHolder.setToolTipText("POSIÇÃO LIVRE");

        }

    }

    private void build() {

        Collections.shuffle((List<Frentista>) frentistasNesteTurno);

        int i = 0;

        for (Frentista frentista : frentistasNesteTurno) {

            ImageIcon icon = getIconForFrentista(frentista);

            bancoDeReservaArray[i].setIcon(icon);
            bancoDeReservaArray[i].setName(Integer.toString(frentista.getId()));
            bancoDeReservaArray[i].setToolTipText(frentista.getNome());

            i++;

            if (i > MAX_FRENTISTAS_POR_TURNO - 1) {
                break;
            }
        }

    }

    
    public synchronized void removeFrentista(Frentista frentista) {
        
        if (frentista == null) {
            throw new NullPointerException("O frentista não pode ser null !!!");
        }

        while (isShuffling) {
        }

        mustWait = true;

        if (frentistaEstaNoBanco(frentista)) {//retira frentista, se estiver no banco

            for (JLabel reserva : bancoDeReservaArray) {

                if (reserva.getName().equals(Integer.toString(frentista.getId()))) {

                    reserva.setName("freePlace");
                    reserva.setIcon(semFotoIcon);
                    reserva.setToolTipText("POSIÇÃO LIVRE");

                    break;

                } else {
                }

            }

        }

        mustWait = false;

    }
    
    public synchronized void borrowFrentistaDoBancoReserva(Frentista frentista) {

        removeFrentista(frentista);

    }

    public synchronized void devolverFrentistaAoBancoDeReserva(Frentista frentista) {

        addFrentista(frentista);

    }

    public synchronized void addFrentista(Frentista frentista) {

        if (frentista == null) {
            throw new NullPointerException("O frentista não pode ser null !!!");
        }

        while (isShuffling) {
        }

        mustWait = true;

        if (!frentistaEstaNoBanco(frentista)) {//se ele nao esta no banco, coloca o

            freePlaces.clear();

            getFreePlaces(freePlaces);

            int randomPosition = secureRandom.nextInt(1 + freePlaces.size());

            if (randomPosition == 0) {//garante index range : 0 <= index <= (size - 1)

            } else {

                if (randomPosition == freePlaces.size()) {
                    randomPosition = freePlaces.size() - 1;
                }

            }

            //coloca frentista numa posicao livre aleatoriamente escolhida
            bancoDeReservaArray[freePlaces.get(randomPosition)].setName(Integer.toString(frentista.getId()));
            bancoDeReservaArray[freePlaces.get(randomPosition)].setIcon(getIconForFrentista(frentista));
            bancoDeReservaArray[freePlaces.get(randomPosition)].setToolTipText(frentista.getNome().toUpperCase());

            frentista.setEstado(Funcionario.PRONTO);

        } else {

        }

        mustWait = false;

    }

    private ImageIcon getIconForFrentista(Frentista frentista) {

        //IMAGE RESIZING SWING JAVA
        ImageIcon icon = new ImageIcon(getClass().getResource(frentista.getCaminhoPraFoto()));
        Image scaleImage = icon.getImage().getScaledInstance(55, 55, Image.SCALE_AREA_AVERAGING);

        return new ImageIcon(scaleImage);

    }

    private void getFreePlaces(List<Integer> freePlaces) {

        JLabel placeHolder;

        for (int j = 0; j < bancoDeReservaArray.length; j++) {

            placeHolder = bancoDeReservaArray[j];

            if (placeHolder.getName().equals("freePlace")) {

                freePlaces.add(j);

            }

        }

    }

    public void setFrentistasNesteTurno(Collection<Frentista> frentistasNesteTurno) {

        if (frentistasNesteTurno == null) {
            throw new NullPointerException("Os frentistas precisam fazer frente a esse negocio. Passe uma colecao não nula.");
        }
        frentistasNesteTurno.forEach((f) -> {
            if (f == null) {
                throw new NullPointerException("O frentista não pode ser null !!!");
            }
        });

        this.frentistasNesteTurno = frentistasNesteTurno;

        clean();
        build();
    }

    private boolean frentistaEstaNoBanco(Frentista frentista) {

        boolean estaNoBanco = false;

        for (JLabel placeHolder : bancoDeReservaArray) {

            if (placeHolder.getName().equals(Integer.toString(frentista.getId()))) {

                estaNoBanco = true;
                break;

            }

        }

        return estaNoBanco;

    }

    private void shufflerTimerActionPerformed(ActionEvent e) {

        new Thread(() -> {

            isShuffling = true;

            if (!mustWait) {

                bancoReservaList.clear();

                bancoReservaList.addAll(Arrays.asList(bancoDeReservaArray));

                Collections.shuffle(bancoReservaList);

                frentistaPlaceHolder0 = bancoReservaList.get(0);
                frentistaPlaceHolder1 = bancoReservaList.get(1);
                frentistaPlaceHolder2 = bancoReservaList.get(2);
                frentistaPlaceHolder3 = bancoReservaList.get(3);
                frentistaPlaceHolder4 = bancoReservaList.get(4);
                frentistaPlaceHolder5 = bancoReservaList.get(5);
                frentistaPlaceHolder6 = bancoReservaList.get(6);
                frentistaPlaceHolder7 = bancoReservaList.get(7);

                bancoDeReservaArray[0] = frentistaPlaceHolder0;
                bancoDeReservaArray[1] = frentistaPlaceHolder1;
                bancoDeReservaArray[2] = frentistaPlaceHolder2;
                bancoDeReservaArray[3] = frentistaPlaceHolder3;
                bancoDeReservaArray[4] = frentistaPlaceHolder4;
                bancoDeReservaArray[5] = frentistaPlaceHolder5;
                bancoDeReservaArray[6] = frentistaPlaceHolder6;
                bancoDeReservaArray[7] = frentistaPlaceHolder7;

                GridBagConstraints gridConstraints = new GridBagConstraints();

                gridConstraints.gridx = 0;
                gridConstraints.gridy = 0;

                removeAll();

                add(frentistaPlaceHolder0, gridConstraints);

                gridConstraints.gridx = 1;
                gridConstraints.gridy = 0;

                add(frentistaPlaceHolder1, gridConstraints);

                gridConstraints.gridx = 2;
                gridConstraints.gridy = 0;

                add(frentistaPlaceHolder2, gridConstraints);

                gridConstraints.gridx = 3;
                gridConstraints.gridy = 0;

                add(frentistaPlaceHolder3, gridConstraints);

                gridConstraints.gridx = 0;
                gridConstraints.gridy = 1;

                add(frentistaPlaceHolder4, gridConstraints);

                gridConstraints.gridx = 1;
                gridConstraints.gridy = 1;

                add(frentistaPlaceHolder5, gridConstraints);

                gridConstraints.gridx = 2;
                gridConstraints.gridy = 1;
                add(frentistaPlaceHolder6, gridConstraints);

                gridConstraints.gridx = 3;
                gridConstraints.gridy = 1;

                add(frentistaPlaceHolder7, gridConstraints);
            } else {

            }

            isShuffling = false;
        }).start();

    }

    private Frentista getFrentistaById(String id) {

        Frentista frentista = null;

        int ID;

        try {
            ID = Integer.parseInt(id);
        } catch (NumberFormatException e) {
            return null;
        }

        for (Frentista f : frentistasNesteTurno) {
            if (f.getId().equals(ID)) {
                f.alocar();
                frentista = f;
                break;
            }
        }

        return frentista;

    }

    @Override
    public String toString() {
        return "Banco de Frentistas Neste Turno UI";
    }


}
