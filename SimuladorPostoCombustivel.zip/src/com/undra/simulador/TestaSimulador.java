

package com.undra.simulador;

/**
 *
 * @author alexandre
 */
public class TestaSimulador {
    
    public static void main(String[] args) {
        
        Simulador simulador=new Simulador();
        
        simulador.configure();
        
        simulador.raise();
        
    }

}
