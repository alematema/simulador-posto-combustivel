
package com.undra.simulador;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.view.interfaces.FadableAndRaisableUI;
import com.undra.menu.MenuNavigator;
import com.undra.menu.MyMenuBar;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.combustivel.bomba.excetion.BombaCombustivelException;
import com.undra.modelo.combustivel.reservatorio.Reservatorio;
import com.undra.modelo.combustivel.reservatorio.exception.NivelCriticoDeCombustivelException;
import com.undra.modelo.combustivel.reservatorio.exception.ReservatorioExeption;
import com.undra.modelo.contabilidade.Caixa;
import com.undra.modelo.recursoshumanos.Frentista;
import com.undra.modelo.recursoshumanos.DepartamentoRecursosHumanos;
import com.undra.view.bombacombustivel.BombaCombustivelUI;
import com.undra.view.controleRemoto.bombaCombustivel.ControleRemotoBombaCombustivelUI;
import com.undra.view.mesaControleRemotoDasBombasCombustivelUI.MesaControleRemotoDasBombasUIWindow;
import com.undra.view.pistaDasBombas.PistaDasBombasUI;
import com.undra.view.pistaDasBombas.PistaDasBombasUIWindow;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.HeadlessException;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JMenuBar;

/**
 *
 * @author alexandre
 */
public class Simulador extends JFrame implements FadableAndRaisableUI {

    
    
    private JMenuBar mainMenuBar;
    
    private UIDelegator uIDelegator;

    private final MesaControleRemotoDasBombasUIWindow mesaControleRemotoDasBombasUIWindow;
    private final PistaDasBombasUIWindow pistaDasBombasUIWindow;

    public Simulador() throws HeadlessException {

        List<BombaCombustivel> modeloPistaBombasCombustivel = new ArrayList();
        List<Caixa> modeloCaixas = new ArrayList();
        PistaDasBombasUI pistaDasBombasUI;

        

        Combustivel gasolina = new Combustivel(Combustivel.GASOLINA, 2.55f, Combustivel.LITRO);
        Combustivel etanol = new Combustivel(Combustivel.ETANOL, 1.99f, Combustivel.LITRO);
        Combustivel diesel = new Combustivel(Combustivel.DIESEL, 3.04f, Combustivel.LITRO);
        Combustivel gnv = new Combustivel(Combustivel.GNV, 1.5f, Combustivel.METRO_CUBICO);

        Reservatorio reservatorio = new Reservatorio(10000f, 100f);

        try {

            reservatorio.abastecer(gasolina, reservatorio.getNIVEL_MAX_TANQUE());
            reservatorio.abastecer(etanol, reservatorio.getNIVEL_MAX_TANQUE());
            reservatorio.abastecer(diesel, reservatorio.getNIVEL_MAX_TANQUE());
            reservatorio.abastecer(gnv, reservatorio.getNIVEL_MAX_TANQUE());

        } catch (NivelCriticoDeCombustivelException ex) {
            Logger.getLogger(Simulador.class.getName()).log(Level.SEVERE, null, ex);
        }
        uIDelegator = new UIDelegator();
        Caixa caixa = new Caixa(uIDelegator, 1);
        ModelDelegator modelDelegator = new ModelDelegator(reservatorio, caixa);
        caixa.setDelegator(modelDelegator);
        modeloCaixas.add(caixa);
        DepartamentoRecursosHumanos recursosHumanos = new DepartamentoRecursosHumanos();
        caixa.setVerbose(false);

        BombaCombustivel bombaGasolina;
        try {
            bombaGasolina = new BombaCombustivel(gasolina, 1, modelDelegator);
            modeloPistaBombasCombustivel.add(bombaGasolina);

            BombaCombustivel bombaEtanol = new BombaCombustivel(etanol, 2, modelDelegator);
            modeloPistaBombasCombustivel.add(bombaEtanol);

            BombaCombustivel bombaDiesel = new BombaCombustivel(diesel, 3, modelDelegator);
            modeloPistaBombasCombustivel.add(bombaDiesel);

            BombaCombustivel bombaGasolina2 = new BombaCombustivel(gasolina, 4, modelDelegator);
            modeloPistaBombasCombustivel.add(bombaGasolina2);

            BombaCombustivel bombaEtanol2 = new BombaCombustivel(etanol, 5, modelDelegator);
            modeloPistaBombasCombustivel.add(bombaEtanol2);

            BombaCombustivel bombaDiesel2 = new BombaCombustivel(diesel, 6, modelDelegator);
            modeloPistaBombasCombustivel.add(bombaDiesel2);

            BombaCombustivel bombaGnv = new BombaCombustivel(gnv, 7, modelDelegator);
            modeloPistaBombasCombustivel.add(bombaGnv);

            BombaCombustivel bombaGnv2 = new BombaCombustivel(gnv, 8, modelDelegator);
            modeloPistaBombasCombustivel.add(bombaGnv2);

        } catch (BombaCombustivelException ex) {
            Logger.getLogger(PistaDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
        }

        

        pistaDasBombasUIWindow = new PistaDasBombasUIWindow(modeloPistaBombasCombustivel, modeloCaixas, uIDelegator);
        pistaDasBombasUIWindow.configure();

        mesaControleRemotoDasBombasUIWindow = new MesaControleRemotoDasBombasUIWindow(modeloPistaBombasCombustivel, uIDelegator);
        mesaControleRemotoDasBombasUIWindow.configure();

    }

    public void configure() {

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }

        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setTitle(getClass().getSimpleName() + " App");

        //getContentPane().setBackground(new Color(255, 255, 192));
        getContentPane().setBackground(Color.BLACK);

        setResizable(false);

        //sets frame's size to 1/4 screen area
        setSize(new Dimension(Toolkit.getDefaultToolkit().getScreenSize().width, Toolkit.getDefaultToolkit().getScreenSize().height));

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

        setUndecorated(true);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        //pack();
        //centralizes the frame
        //setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());
        new Thread(() -> {
            //algumas quantidades de combustivel
            float[] quantidades = {10.63f, 80f, 75f, 70f, 40f, 55f, 75f, 20.78f, 78f, 60f, 20f, 7.89f, 5.21f, 89f, 32.43f, 67f, 10.5f, 21.67f, 45.67f, 11.67f, 12.5f, 13.5f};
            
            //os cumbustiveis deste posto de gasolina
            Combustivel[] combustiveis = {
                new Combustivel(Combustivel.GASOLINA, 2.99f, Combustivel.LITRO),
                new Combustivel(Combustivel.ETANOL, 1.99f, Combustivel.LITRO),
                new Combustivel(Combustivel.DIESEL, 3.69f, Combustivel.LITRO),
                new Combustivel(Combustivel.GNV, 1.69f, Combustivel.METRO_CUBICO)
                    
            };
            
            SecureRandom myRandom = new SecureRandom();
            
            pistaDasBombasUIWindow.getPistaDasBombasUI().getBombasCombustivelUI().stream().map((bombaView) -> {
                bombaView.getOnOff().doClick();
                return bombaView;
            }).forEachOrdered((_item) -> {
                try {
                    Thread.sleep(589);
                } catch (InterruptedException ex) {
                    Logger.getLogger(PistaDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            
            //Simula uma solicitação de abastecimento a cada alguns segundos
            //Tando o combustivel quando o valor quanto o frentista a realizar o abastecimento sao aleatoriamente escolhidos
            int i = 0;
            while (true) {
                
                Combustivel combustivel = combustiveis[myRandom.nextInt(4)];
                float quantidadeCombustivel = quantidades[myRandom.nextInt(quantidades.length)];
                
                Frentista frentista = (Frentista) pistaDasBombasUIWindow.getPistaDasBombasUI().getFrentistaLivre();
                BombaCombustivelUI bomba = pistaDasBombasUIWindow.getPistaDasBombasUI().getBombaCombustivelUILivre(combustivel);
                
                if (frentista != null && bomba != null) {
                    
                    frentista.abasteceComABomba(bomba.getModelo()).aQuantidade(quantidadeCombustivel);
                    
                    while (bomba.getModelo().isLiberada()) {
                    }
                    
                    try {
                        Thread.sleep(myRandom.nextInt(11*1000));
                    } catch (InterruptedException ex) {
                        Logger.getLogger(PistaDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
                
                i++;
                
            }
        }).start();

    }

    public void configureAndShow() {
        configure();
        setVisible(true);
    }

    private void placeComponentsAtFrame() {

        MenuNavigator.registerUI(this);
        MenuNavigator.registerUI(mesaControleRemotoDasBombasUIWindow);
        MenuNavigator.registerUI(pistaDasBombasUIWindow);
        MenuNavigator.setFrom(this.getClass().getSimpleName());

//        mainMenuBar = new MyMenuBar(uIDelegator,);
//
//        setJMenuBar(mainMenuBar);
//
//        pistaDasBombasUIWindow.setJMenuBar(new MyMenuBar(uIDelegator));
//        mesaControleRemotoDasBombasUIWindow.setJMenuBar(new MyMenuBar(uIDelegator));

    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }

    @Override
    public void fade() {

        new Thread(() -> {
            for (int i = 100; i > 1; i--) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ControleRemotoBombaCombustivelUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            setVisible(false);
            transferFocus();
        }).start();

    }

    @Override
    public void raise() {
        setOpacity(0.11f);
        new Thread(() -> {
            float opacity1 = 1.0f;
            setVisible(true);
            for (int i = 0; i < 100; i++) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Simulador.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            requestFocus();
        }).start();

    }

    @Override
    public String toString() {
        return "Simulador UI";
    }

}
