/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.app;

import com.undra.delegator.excpetion.DelegatorException;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.excetion.BombaCombustivelException;
import com.undra.modelo.combustivel.reservatorio.Reservatorio;
import com.undra.modelo.combustivel.reservatorio.exception.ReservatorioExeption;
import com.undra.modelo.contabilidade.exception.AbastecimentoException;
import com.undra.modelo.contabilidade.exception.CaixaException;
import com.undra.modelo.postocombustivel.PostoCombustivel;
import com.undra.modelo.postocombustivel.PostoGasolinaException;
import com.undra.modelo.recursoshumanos.Frentista;
import com.undra.modelo.recursoshumanos.exception.RecursosHumanosException;
import com.undra.view.postocombustivel.PostoCombustivelUIWindowTeste;
import java.util.Random;

/**
 *
 * @author alexandre
 */
public class SimuladorPostoCombustivel {

    public static void main(String[] args) throws PostoGasolinaException, ReservatorioExeption, CaixaException, BombaCombustivelException, RecursosHumanosException, AbastecimentoException, DelegatorException {
            PostoCombustivelUIWindowTeste.main(args);
    }

    public void start() throws PostoGasolinaException, ReservatorioExeption, CaixaException, BombaCombustivelException, RecursosHumanosException, AbastecimentoException, DelegatorException {

        Reservatorio reservatorio = new Reservatorio(10000f, 500f);
        //cria um posto de combustivel com um reservatorio  cujos tanques tem capacidade de 10000 unidades para cada tipo de combustivel vendido no posto
        PostoCombustivel postoCombustivel = new PostoCombustivel(reservatorio);

        //algumas quantidades de combustivel
        float[] quantidades = {1.63f,80f,75f,70f,40f,55f,75f, 2.78f, 78f, 60f, 2f, 7.89f, 5.21f, 89f, 32.43f, 67f,10.5f,21.67f,45.67f,11.67f,2.5f,3.5f};
        
        //os cumbustiveis deste posto de gasolina
        Combustivel[] combustiveis = {
            
            new Combustivel(Combustivel.GASOLINA, 2.99f, Combustivel.LITRO),
            new Combustivel(Combustivel.ETANOL, 1.99f, Combustivel.LITRO),
            new Combustivel(Combustivel.DIESEL, 3.69f, Combustivel.LITRO),
            new Combustivel(Combustivel.GNV, 1.69f, Combustivel.METRO_CUBICO)
                
        };

        //admite alguns frentistas para trampar
        postoCombustivel.admitirFuncionario(new Frentista(1, "BUDA", "91273490", "329074"));
        postoCombustivel.admitirFuncionario(new Frentista(2, "LAO TSE", "908345", "92374095"));
        postoCombustivel.admitirFuncionario(new Frentista(3, "MARLON", "298374980", "245297"));
        postoCombustivel.admitirFuncionario(new Frentista(4, "ELOIM", "2349702198347", "7095732495"));
        postoCombustivel.admitirFuncionario(new Frentista(5, "MARIA MADALENA", "398274987", "9073495"));
        postoCombustivel.admitirFuncionario(new Frentista(6, "ALBERTO ROBERTO", "298374", "2908345"));
        postoCombustivel.admitirFuncionario(new Frentista(7, "JULIANO URCH", "2093403", "0234504238"));
        postoCombustivel.admitirFuncionario(new Frentista(8, "JESUS CRISTO", "2349702198347", "7095732495"));
        
        Random myRandom = new Random();
        
        //Simula uma solicitação de abastecimento a cada alguns segundos
        //Tando o combustivel quando o valor quanto o frentista a realizar o abastecimento sao aleatoriamente escolhidos
        int i = 0;
        while(true){
            
            try{
                
                Thread.sleep(0);
                
                Combustivel combustivel = combustiveis[myRandom.nextInt(4)];
                float quantidadeCombustivel = quantidades[myRandom.nextInt(quantidades.length)];
                
                postoCombustivel.abastecer(combustivel, quantidadeCombustivel);
            
            }catch(DelegatorException | BombaCombustivelException | ReservatorioExeption | AbastecimentoException | CaixaException | PostoGasolinaException | InterruptedException e){
                System.out.println(e.getLocalizedMessage());
            }
            
            i++;
            
        }
    }
}
