package com.undra.app.util;

/**
 * Uma outPut para se escrever nela
 * @author alexandre
 */
public interface OutPut {

    float getValue();
    void setValue(float newValue);
    
}
