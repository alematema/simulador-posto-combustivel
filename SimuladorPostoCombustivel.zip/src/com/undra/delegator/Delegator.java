/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.undra.delegator;

import java.util.ArrayList;
import java.util.List;

/**
 * O pai de todos delegators
 * @author alexandre
 */
abstract public class Delegator {
    
    static private final List<Object> DELEGATORS = new ArrayList();

    static public void registrarDelegator(Object delegator) {

        if (delegator == null) {
            throw new NullPointerException("O Delegator não pode ser null !!!");
        }

        DELEGATORS.add(delegator);
        
        System.out.println("[DELEGATOR] : DELEGATOR registrado -> "+delegator);

    }
    static public void desregistrarDelegator(Object delegator) {

        if (delegator == null) {
            throw new NullPointerException("O Delegator não pode ser null !!!");
        }

        DELEGATORS.remove(delegator);
        
        System.out.println("[DELEGATOR : ] DELEGATOR DESregistrado -> "+delegator);

    }
    static public List<Object> getAll(){
        return DELEGATORS;
    }
    static public void listar() {
        DELEGATORS.forEach(System.out::println);
    }
    static public Object getDelegator(Class clazz) {

        Object DELEGATOR = null;

        for (Object delegator : DELEGATORS) {
            if (delegator.getClass().equals(clazz)) {
                DELEGATOR = delegator;
            }
        }

        return DELEGATOR;

    }
    
    abstract public void registrar(Object delegator);
    abstract public void desregistrar(Object delegator);
    
    
     @Override
    public String toString() {
        return "DELEGATOR : delegator";
    }
}
