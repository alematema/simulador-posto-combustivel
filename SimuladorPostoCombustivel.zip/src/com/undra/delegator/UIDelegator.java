package com.undra.delegator;

import com.undra.dialogo.Dialogo;
import com.undra.menu.MenuNavigator;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import static com.undra.modelo.combustivel.bomba.BombaCombustivel.PRONTA;
import static com.undra.modelo.combustivel.bomba.BombaCombustivel.PRONTA_EM_ESTADO_CRITICO;
import com.undra.modelo.contabilidade.Abastecimento;
import com.undra.modelo.contabilidade.Caixa;
import com.undra.modelo.recursoshumanos.Frentista;
import com.undra.modelo.recursoshumanos.Funcionario;
import com.undra.view.bombacombustivel.AbastecimentoManualUI;
import com.undra.view.bombacombustivel.BombaCombustivelUI;
import com.undra.view.caixa.CaixaUI;
import com.undra.view.controleRemoto.bombaCombustivel.ControleRemotoBombaCombustivelUI;
import com.undra.view.frentistasnesteturno.BancoDeFrentistasNesteTurnoUI;
import com.undra.view.interfaces.UI;
import com.undra.view.relatorios.RelatoriosFrentistasAbastecimentosUIWindow;
import com.undra.view.reservatorio.ReservatorioCombustiveisUI;
import com.undra.view.splash.SplashWindowUI;
import com.undra.view.turno.TurnoFrentistasUI;
import com.undra.view.turno.TurnoFrentistasUIImpl;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * O delegator das UIs
 *
 * @author alexandre
 */
public final class UIDelegator extends Delegator {

    static public int SIM = Dialogo.SIM;
    static public int NAO = Dialogo.NAO;
    static public int OUTRA_ACAO = Dialogo.OUTRA_ACAO;

    public UIDelegator() {
        registrarSeNoDelegator();
    }
    
    private void registrarSeNoDelegator(){
        registrar(this);
    }

    private final Collection<UI> UIS = new ArrayList();
    private final Map<BombaCombustivel, BombaCombustivelUI> bombasCombustivelsUISMap = new HashMap();
    private final Map<String, Collection<ControleRemotoBombaCombustivelUI>> nomesCombustivelControleRemotoBombasCombustivelsMap = new HashMap();
    private final Map<BombaCombustivel, ControleRemotoBombaCombustivelUI> controleRemotoBombaCombustivelUISMap = new HashMap();

    @Override
    public void registrar(Object delegator) {
        Delegator.registrarDelegator(delegator);
    }

    @Override
    public void desregistrar(Object delegator) {
        Delegator.desregistrarDelegator(delegator);
    }

    public void registrarUI(UI ui) {

        if (ui == null) {
            throw new NullPointerException("UI não pode ser null !!!");
        }

        if (!(ui instanceof UI)) {
            throw new IllegalArgumentException("A referência deve ser para um objeto UI e " + ui.getClass().getSimpleName() + " não é UI");
        }

        if (!UIS.contains(ui)) {

            UIS.add(ui);

            //cache altamente especializado para aumentar performance às milhoes de chamadas de getBombaCombustivelUI
            if (ui instanceof BombaCombustivelUI) {

                bombasCombustivelsUISMap.put(((BombaCombustivelUI) ui).getModelo(), ((BombaCombustivelUI) ui));

            }

            //cache altamente especializado para aumentar performance às milhoes de chamadas de ControleRemotoBombaCombustivelUI
            if (ui instanceof ControleRemotoBombaCombustivelUI) {

                controleRemotoBombaCombustivelUISMap.put(((ControleRemotoBombaCombustivelUI) ui).getModelo(), ((ControleRemotoBombaCombustivelUI) ui));

                String nomeCombustivel = ((ControleRemotoBombaCombustivelUI) ui).getModelo().getCombustivel().getNome();

                if (nomesCombustivelControleRemotoBombasCombustivelsMap.containsKey(nomeCombustivel)) {

                    nomesCombustivelControleRemotoBombasCombustivelsMap.get(nomeCombustivel).add(((ControleRemotoBombaCombustivelUI) ui));

                } else {

                    Collection<ControleRemotoBombaCombustivelUI> controles = new ArrayList();
                    
                    controles.add(((ControleRemotoBombaCombustivelUI) ui));

                    nomesCombustivelControleRemotoBombasCombustivelsMap.put(nomeCombustivel, controles);

                }

            }

            String msg = "[UI DELEGATOR] : UI registrada -> " + ui;
            System.out.println(msg);
            atualizarSplash(msg);

        } else {

            String msg = "[UI DELEGATOR] : UI NÂO registrada NOVAMENTE -> " + ui;
            System.out.println(msg);
            atualizarSplash(msg);

        }

    }

    public void desregistrarUI(UI ui) {

        if (ui == null) {
            throw new NullPointerException("UI não pode ser null !!!");
        }

        try {

            UIS.remove(ui);

            if (ui instanceof BombaCombustivelUI) {

                bombasCombustivelsUISMap.remove(((BombaCombustivelUI) ui).getModelo());

            }

            if (ui instanceof ControleRemotoBombaCombustivelUI) {

                controleRemotoBombaCombustivelUISMap.remove(((ControleRemotoBombaCombustivelUI) ui).getModelo());

                nomesCombustivelControleRemotoBombasCombustivelsMap.remove(((ControleRemotoBombaCombustivelUI) ui).getModelo().getCombustivel().getNome());

            }

        } catch (Exception e) {

            System.err.println("Algo deu errado em UIDelegator.desregistrarUI\n" + e.getMessage());

        }

    }

    public void listarUIs() {
        UIS.forEach(System.out::println);
    }

    public ControleRemotoBombaCombustivelUI getControleRemotoBombaCombustivelUIById(int id) {

        ControleRemotoBombaCombustivelUI controleRemotoBombaCombustivelUI = null;

        try {

            for (Object obj : getUIs(ControleRemotoBombaCombustivelUI.class)) {

                if (((ControleRemotoBombaCombustivelUI) obj).getModelo().getId() == (id)) {

                    controleRemotoBombaCombustivelUI = (ControleRemotoBombaCombustivelUI) obj;

                    break;

                }

            }

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.getControleRemotoBombaCombustivelUIById\n" + e.getMessage());
        }

        return controleRemotoBombaCombustivelUI;

    }

    public CaixaUI getCaixaUIById(int id) {

        CaixaUI caixaUI = null;

        try {

            for (Object obj : getUIs(CaixaUI.class)) {

                if (((CaixaUI) obj).getModelo().getId() == (id)) {

                    caixaUI = (CaixaUI) obj;

                    break;

                }

            }

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.getCaixaUIById\n" + e.getMessage());
        }

        return caixaUI;
    }

    private ReservatorioCombustiveisUI reservatorioCombustiveisUI;

    public UI getUI(Class clazz) {

        //cache altamente especializado para chamadas muito frequentes a getUI(ReservatorioCombustiveisUI.class)
        if (clazz.equals(ReservatorioCombustiveisUI.class)) {

            if (reservatorioCombustiveisUI == null) {

                for (UI ui : UIS) {
                    if (ui.getClass().equals(ReservatorioCombustiveisUI.class)) {
                        reservatorioCombustiveisUI = (ReservatorioCombustiveisUI) ui;
                        break;
                    }
                }

            }

            return reservatorioCombustiveisUI;

        }

        UI UI = null;

        for (UI ui : UIS) {
            if (ui.getClass().equals(clazz)) {
                UI = ui;
            }
        }

        return UI;

    }

    public Collection<BombaCombustivelUI> getBombasUIDesteCombustivel(Combustivel combustivel) {

        Collection<BombaCombustivelUI> bomboslUI = new ArrayList();

        try {

            getUIs(BombaCombustivelUI.class).stream().filter((obj) -> (((BombaCombustivelUI) obj).getModelo().getCombustivel().equals(combustivel))).forEachOrdered((obj) -> {
                bomboslUI.add((BombaCombustivelUI) obj);
            });

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.getBombasUIDesteCombustivel\n" + e.getMessage());
        }

        return bomboslUI;
    }

    public Collection<UI> getUIs(Class clazz) {

        Collection<UI> UIs = new ArrayList();

        this.UIS.stream().filter((ui) -> (ui.getClass().equals(clazz))).forEachOrdered((ui) -> {
            UIs.add(ui);
        });

        return UIs;

    }

    private synchronized BombaCombustivelUI getBombaCombustivelUI(BombaCombustivel bombaCombustivel) {

        BombaCombustivelUI bombaCombustivelUI = null;

        try {

            //cache altamente especializado para aumentar performance às milhoes de chamadas de BombaCombustivelUI
            //usa map para recuperar da bombaUI que tem O(1), em contraste com o algoritmo anterior que tinha O(n)
            bombaCombustivelUI = bombasCombustivelsUISMap.get(bombaCombustivel);

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.getBombaCombustivelUI\n" + e.getMessage());
        }

        return bombaCombustivelUI;
    }

    public ControleRemotoBombaCombustivelUI getControleRemotoBombaCombustivelUI(BombaCombustivel bombaCombustivel) {

        ControleRemotoBombaCombustivelUI controleRemotoDaBomba = null;

        try {
            //cache altamente especializado para aumentar performance às milhoes de chamadas de ControleRemotoBombaCombustivelUI
            //usa map para recuperar controleremoto da bomba que tem O(1), em contraste com o algoritmo anterior que tinha O(n)
            controleRemotoDaBomba = controleRemotoBombaCombustivelUISMap.get(bombaCombustivel);

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.getControleRemotoBombaCombustivelUI\n" + e.getMessage());
        }

        return controleRemotoDaBomba;
    }

    private CaixaUI getCaixaUI(Caixa caixa) {

        CaixaUI caixaUI = null;

        try {

            for (Object obj : getUIs(CaixaUI.class)) {

                if (((CaixaUI) obj).getModelo().equals(caixa)) {
                    caixaUI = (CaixaUI) obj;
                    break;
                }

            }

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.getCaixaUI\n" + e.getMessage());
        }

        return caixaUI;
    }

    public synchronized void atualizarSplash(String msg) {

        try {

            Thread.sleep(50);
            try {
                msg = msg.substring(0, 69);
                msg += "...";
            } catch (Exception e) {
            }
            ((SplashWindowUI) getUI(SplashWindowUI.class)).setMensagem(msg);

        } catch (InterruptedException e) {
            System.err.println("Algo deu errado em UIDelegator.atualizarSplash\n" + e.getMessage());
        }

    }

    public void ligarBombaDoControleRemotoParaViewBomba(BombaCombustivel bombaCombustivel) {

        try {

            BombaCombustivelUI bombaCombustivelUI = getBombaCombustivelUI(bombaCombustivel);

            bombaCombustivelUI.getOnOff().doClick();

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.ligarBombaDoControleRemotoParaViewBomba\n" + e.getMessage());
        }

    }

    public void desligarBombaDoControleRemotoParaViewBomba(BombaCombustivel bombaCombustivel) {

        try {

            BombaCombustivelUI bombaCombustivelUI = getBombaCombustivelUI(bombaCombustivel);

            bombaCombustivelUI.getOnOff().doClick();

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.desligarBombaDoControleRemotoParaViewBomba\n" + e.getMessage());
        }
    }

    public void setViewConsole(String msg, BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).getLabelConsole().setText(msg);

    }

    public void setDisplayCombustivel(float f, BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).setQuantidadeAbastecida(f);
    }

    public void setDisplayTotalDinheiro(float f, BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).setTotalAbastecido(f);
    }

    public void setDisplayPrecoUnidadeCombustivel(float f, BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).setPrecoUnidadeCombustivel(f);
    }

    public void setViewConsoleEPiscar(String msg, BombaCombustivel bombaCombustivel) {
        setViewConsole(msg, bombaCombustivel);
        getBombaCombustivelUI(bombaCombustivel).piscar();
    }

    public void pararPulsarBombaOkWaitingState(BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).pararPiscarOkWarningBomba();
    }

    public void setFrentista(Funcionario frentista, BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).setFrentista(frentista);
    }

    public void liberarFrentista(Funcionario frentista, BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).liberarFrentista(frentista);
        devolverFrentistaAoBancoDeReserva(frentista);
    }

    public void notificarDesligamentoDaBombaEnquantoCaixaProcessaAbastecimento(BombaCombustivel bombaCombustivel) {
        pararPulsarBombaOkWaitingState(bombaCombustivel);
    }

    public void desbloquearABomba(BombaCombustivel bombaCombustivel) {

        if (getBombaCombustivelUI(bombaCombustivel).getModelo().getEstado().equals(PRONTA)) {
            pararPulsarBombaOkWaitingState(bombaCombustivel);
            setViewConsole(PRONTA, bombaCombustivel);
        } else if (getBombaCombustivelUI(bombaCombustivel).getModelo().getEstado().equals(PRONTA_EM_ESTADO_CRITICO)) {
            pararPulsarBombaBadWaitingState(bombaCombustivel);
            setViewConsole(PRONTA_EM_ESTADO_CRITICO, bombaCombustivel);
        }

        ajustarConsoleAposPararPiscarConsole(bombaCombustivel);
        setDisplayCombustivel(0f, bombaCombustivel);
        setDisplayTotalDinheiro(0f, bombaCombustivel);

    }

    private void ajustarConsoleAposPararPiscarConsole(BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).ajustarConsoleAposPararPiscarConsole();
    }

    public void ligarDisplayTotalDinheiro(BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).ligarDisplayTotalDinheiro();
    }

    public void desLigarDisplayTotalDinheiro(BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).desLigarDisplayTotalDinheiro();
    }

    public void ligarDisplayTotalCombustivel(BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).ligarDisplayTotalCombustivel();
    }

    public void desLigarDisplayTotalCombustivel(BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).desLigarDisplayTotalCombustivel();
    }

    public void ligarDisplayPrecoUnidadeCombustivel(BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).ligarDisplayPrecoUnidadeCombustivel();
    }

    public void desLigarDisplayPrecoUnidadeCombustivel(BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).desLigarDisplayPrecoUnidadeCombustivel();
    }

    public void ligarDisplays(BombaCombustivel bombaCombustivel) {
        ligarDisplayTotalDinheiro(bombaCombustivel);
        ligarDisplayTotalCombustivel(bombaCombustivel);
        ligarDisplayPrecoUnidadeCombustivel(bombaCombustivel);
    }

    public void desligarDisplays(BombaCombustivel bombaCombustivel) {
        desLigarDisplayTotalDinheiro(bombaCombustivel);
        desLigarDisplayTotalCombustivel(bombaCombustivel);
        desLigarDisplayPrecoUnidadeCombustivel(bombaCombustivel);
    }

    public void setConsoleBackgroundAbastecendo(BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).setConsoleBackgroundBombaAbastecendo();
    }

    public void setConsoleBackgroundAbastecimentoTerminado(BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).setConsoleBackgroundAbastecimentoTerminado();
    }

    public void pulsarBombaOkWaitingState(BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).pulsarBombaOkWaitingState();
    }

    public int confirmarAbastecerEmNivelCritico(String message, BombaCombustivel bombaCombustivel) {
        return getBombaCombustivelUI(bombaCombustivel).confirmarAbastecerEmNivelCritico(message);
    }

    public void setVisibleStateBombaContainer(boolean b, BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).setVisibleStateBombaContainer(b);
    }

    public void pulsarBombaBadWaitingState(BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).pulsarBombaBadWaitingState();
    }

    private void pararPulsarBombaBadWaitingState(BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).pararPulsarBombaBadWaitingState();
    }

    public void notificarDesligamentoDaBombaSemCombustivel(BombaCombustivel bombaCombustivel) {
        getBombaCombustivelUI(bombaCombustivel).notificarDesligamentoDaBombaSemCombustivel();
    }

//    
    public void atualizarMensagemConsoleAbastecendoNoControleRemoto(String combustivel, String msgm, float nivel) {
        try {

            for (Object obj : getUIs(ControleRemotoBombaCombustivelUI.class)) {

                if (((ControleRemotoBombaCombustivelUI) obj).getModelo().getCombustivel().getNome().equals(combustivel)) {

                    if (nivel > 98f) {
                        msgm = "NÃO ABASTECENDO (000,00)";
                    }
                    ((ControleRemotoBombaCombustivelUI) obj).setMensagemDoConsoleAbastecendo(msgm);

                }

            }

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.atualizarMensagemConsoleAbasatecendoNoControleRemoto\n" + e.getMessage());
        }
    }

    public void setMensagemConsoleNoControleRemoto(String msg, BombaCombustivel bombaCombustivel) {
        try {

            ControleRemotoBombaCombustivelUI controleRemotoDaBomba = getControleRemotoBombaCombustivelUI(bombaCombustivel);
            controleRemotoDaBomba.setMensagemDoConsole(msg);

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.setMensagemConsoleNoControleRemoto\n" + e.getMessage());
        }
    }

    public void atualizaControleRemotoAposBombaLigar(BombaCombustivel bombaCombustivel) {
        try {

            ControleRemotoBombaCombustivelUI controleRemotoDaBomba = getControleRemotoBombaCombustivelUI(bombaCombustivel);
            controleRemotoDaBomba.atualizaAposBombaLigar();

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.atualizaControleRemotoAposBombaLigar\n" + e.getMessage());
        }
    }

    public void atualizaControleRemotoAposBombaDesligar(BombaCombustivel bombaCombustivel) {
        try {

            ControleRemotoBombaCombustivelUI controleRemotoDaBomba = getControleRemotoBombaCombustivelUI(bombaCombustivel);
            controleRemotoDaBomba.atualizaAposBombaDesligar();

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.atualizaControleRemotoAposBombaDesligar\n" + e.getMessage());
        }
    }

    public void setAbastecendoEmControleRemoto(float f, BombaCombustivel bombaCombustivel) {
        try {

            ControleRemotoBombaCombustivelUI controleRemotoDaBomba = getControleRemotoBombaCombustivelUI(bombaCombustivel);
            controleRemotoDaBomba.setAbastecendo(f);

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.setMensagemLigadaAsNoControleRemoto\n" + e.getMessage());
        }
    }

    public void setAbastecendoEmControleRemoto(float f, float quantidade, BombaCombustivel bombaCombustivel) {
        try {

            ControleRemotoBombaCombustivelUI controleRemotoDaBomba = getControleRemotoBombaCombustivelUI(bombaCombustivel);
            controleRemotoDaBomba.setAbastecendo(f, quantidade);

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.setMensagemLigadaAsNoControleRemoto\n" + e.getMessage());
        }
    }

    public void setMensagemAguardandoOCaixaNoControleRemoto(String msgm, BombaCombustivel bombaCombustivel) {
        try {

            ControleRemotoBombaCombustivelUI controleRemotoDaBomba = getControleRemotoBombaCombustivelUI(bombaCombustivel);
            controleRemotoDaBomba.setMensagemAguardandoCaixa(msgm);

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.setMensagemLigadaAsNoControleRemoto\n" + e.getMessage());
        }
    }

    public void setAbastecimentosNoControleRemoto(BombaCombustivel bombaCombustivel) {
        try {

            ControleRemotoBombaCombustivelUI controleRemotoDaBomba = getControleRemotoBombaCombustivelUI(bombaCombustivel);
            controleRemotoDaBomba.setAbastecimentos();

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.setMensagemLigadaAsNoControleRemoto\n" + e.getMessage());
        }
    }

    public void setVelocidadeAbastecimentoNoControleRemoto(BombaCombustivel bombaCombustivel) {
        try {

            ControleRemotoBombaCombustivelUI controleRemotoDaBomba = getControleRemotoBombaCombustivelUI(bombaCombustivel);
            controleRemotoDaBomba.setVelocidadeAbastecimento();

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.setMensagemLigadaAsNoControleRemoto\n" + e.getMessage());
        }
    }

    public synchronized void setTotalCombustivelAbastecidoNoControleRemoto(float quantidadeAbastecido, BombaCombustivel bombaCombustivel) {
        try {

            ControleRemotoBombaCombustivelUI controleRemotoDaBomba = getControleRemotoBombaCombustivelUI(bombaCombustivel);
            controleRemotoDaBomba.setTotalCombustivelAbastecido(quantidadeAbastecido);

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.setTotalCombustivelAbastecido\n" + e.getMessage());
        }
    }

    public synchronized void atualizarTotalCombustivelAbastecidoNoControleRemoto(float quantidadeAbastecido, BombaCombustivel bombaCombustivel) {
        try {

            ControleRemotoBombaCombustivelUI controleRemotoDaBomba = getControleRemotoBombaCombustivelUI(bombaCombustivel);
            controleRemotoDaBomba.atualizarTotalCombustivelAbastecido(quantidadeAbastecido);

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.setTotalCombustivelAbastecido\n" + e.getMessage());
        }
    }

    private ModelDelegator modelDelegator;

    public float getNivelReservatorio(Combustivel combustivel) {

        float nivelReservatorio = 0;

        try {

            if (modelDelegator == null) {
                modelDelegator = (ModelDelegator) Delegator.getDelegator(ModelDelegator.class);
            }
            nivelReservatorio = modelDelegator.getNivelReservatorio(combustivel);

        } catch (Exception e) {

            System.err.println("Algo deu errado em UIDelegator.getNivelReservatorio\n" + e.getMessage());

        }

        return nivelReservatorio;

    }

    private Collection<UI> controlesRemotosBombasCombustiveisUI;

    public synchronized void atualizarNivelReservatorioNosControlesRemotos(Combustivel combustivel, float nivel) {

        try {

            if (controlesRemotosBombasCombustiveisUI == null) {
                controlesRemotosBombasCombustiveisUI = getUIs(ControleRemotoBombaCombustivelUI.class);
            }

            controlesRemotosBombasCombustiveisUI.stream().filter((ui) -> (((ControleRemotoBombaCombustivelUI) ui).isDesteCombustivel(combustivel))).forEachOrdered((ui) -> {
                ((ControleRemotoBombaCombustivelUI) ui).setNivelReservatorio(nivel);
            });

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.atualizarNivelReservatorioNosControlesRemotos\n" + e.getMessage());
        }
    }

    public synchronized void atualizarNivelReservatorioNosControlesRemotos(String combustivel, float nivel) {
        
        try {

            
            //cache para aumentar performance às milhoes de chamadas de ao ControleRemotoBombaCombustivelUI
            //usa map para recuperar controles remotos das bombas de um certo combustivel e que tem O(1), em contraste com o algoritmo anterior que tinha O(n)
            nomesCombustivelControleRemotoBombasCombustivelsMap.get(combustivel).forEach((controleRemoto) -> {
                controleRemoto.setNivelReservatorio(nivel);
            });

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.atualizarNivelReservatorioNosControlesRemotos\n" + e.getMessage());
        }
    }

    public void setOnOffNoControleRemoto(BombaCombustivel bombaCombustivel) {
        try {

            ControleRemotoBombaCombustivelUI controleRemotoDaBomba = getControleRemotoBombaCombustivelUI(bombaCombustivel);
            controleRemotoDaBomba.setOnOff();

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.setOnOffNoControleRemoto\n" + e.getMessage());
        }
    }

    public void ligarWifiNaBombaCombustivel(BombaCombustivel bombaCombustivel) {

        BombaCombustivelUI bombaCombustivelUI = getBombaCombustivelUI(bombaCombustivel);
        bombaCombustivelUI.setWifiOn();

    }

    public void setTemperaturaMotorNoControleRemoto(float temperatura, BombaCombustivel bombaCombustivel) {
        try {

            ControleRemotoBombaCombustivelUI controleRemotoDaBomba = getControleRemotoBombaCombustivelUI(bombaCombustivel);
            controleRemotoDaBomba.setTemperaturaMotor(temperatura);

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.setTemperaturaMotorNoControleRemoto\n" + e.getMessage());
        }
    }

    public void setDownArrowNoControleRemoto(BombaCombustivel bombaCombustivel) {
        try {

            ControleRemotoBombaCombustivelUI controleRemotoDaBomba = getControleRemotoBombaCombustivelUI(bombaCombustivel);
            controleRemotoDaBomba.setDownArrow();

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.setDownArrowNoControleRemoto\n" + e.getMessage());
        }
    }

    public void setUpArrowNoControleRemoto(BombaCombustivel bombaCombustivel) {
        try {

            ControleRemotoBombaCombustivelUI controleRemotoDaBomba = getControleRemotoBombaCombustivelUI(bombaCombustivel);
            controleRemotoDaBomba.setUpArrow();

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.setUpArrowNoControleRemoto\n" + e.getMessage());
        }
    }

    public void addNovoAbastecimentoNoControleRemoto(Abastecimento abastecimento, BombaCombustivel bombaCombustivel) {

        try {

            ControleRemotoBombaCombustivelUI controleRemotoDaBomba = getControleRemotoBombaCombustivelUI(bombaCombustivel);
            controleRemotoDaBomba.addAbastecimento(abastecimento);

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.addNovoAbastecimentoNoControleRemoto\n" + e.getMessage());
        }

    }

    public void limparEEscreverNoConsoleDoCaixa(String msgm, Caixa caixa) {
        getCaixaUI(caixa).limparEEscreverNoConsole(msgm);
    }

    public void escreverNoConsoleDoCaixa(String msgm, Caixa caixa) {
        getCaixaUI(caixa).escreverNoConsole(msgm);
    }

    public void addFrentistaNoRelatoriosFrentistasAbastecimentosWindow(Frentista frentista) {
        ((RelatoriosFrentistasAbastecimentosUIWindow) getUI(RelatoriosFrentistasAbastecimentosUIWindow.class)).addFrentista(frentista);
    }

    public void removeFrentistaNoRelatoriosFrentistasAbastecimentosWindow(Frentista frentista) {
        ((RelatoriosFrentistasAbastecimentosUIWindow) getUI(RelatoriosFrentistasAbastecimentosUIWindow.class)).removeFrentista(frentista);
    }

    public void atualizarFrentistaNoRelatoriosFrentistasAbastecimentosWindow(Frentista frentista) {
        ((RelatoriosFrentistasAbastecimentosUIWindow) getUI(RelatoriosFrentistasAbastecimentosUIWindow.class)).atualizarRelatorioDoFrentista(frentista);
    }

    public void atualizarMenuLigarDesligarBombasNoMyMenuBar() {
        MenuNavigator.MY_MENu_BAR_LIST.forEach((myMenuBar) -> {
            myMenuBar.ligarDesligarBombasMenuItem.setText("ligar bombas");
            myMenuBar.ligarDesligarBombasMenuItem.setName("ligar");
        });
    }

    @Override
    public String toString() {
        return "UI DELEGATOR : delegator da UI";
    }

    public void retirarFrentistaDoBancoReserva(Frentista frentista) {
        ((BancoDeFrentistasNesteTurnoUI) getUI(BancoDeFrentistasNesteTurnoUI.class)).borrowFrentistaDoBancoReserva(frentista);
    }

    private void devolverFrentistaAoBancoDeReserva(Funcionario frentista) {
        ((BancoDeFrentistasNesteTurnoUI) getUI(BancoDeFrentistasNesteTurnoUI.class)).devolverFrentistaAoBancoDeReserva((Frentista) frentista);
    }

    public boolean isAnyAbastecimentoManualUIRaised() {

        boolean isAny = false;

        for (UI ui : getUIs(AbastecimentoManualUI.class)) {

            if (((AbastecimentoManualUI) ui).isRaised) {
                isAny = true;
                break;
            }

        }
        return isAny;

    }

    public void atualizarNivelTanqueCombustivel(Combustivel combustivel, float nivel) {
        ((ReservatorioCombustiveisUI) getUI(ReservatorioCombustiveisUI.class)).setNivel(combustivel, nivel);
    }

    public void atualizarNivelTanqueCombustivel(String combustivel, float nivel) {
        try {

            ((ReservatorioCombustiveisUI) getUI(ReservatorioCombustiveisUI.class)).setNivel(combustivel, nivel);

        } catch (Exception e) {
            System.err.println("Algo deu errado em UIDelegator.atualizarNivelTanqueCombustivel\n" + e.getLocalizedMessage());
        }

    }

    public void notificarTanqueCheioBombasDesteCombustivel(String nomeCombustivel) {

        try {

            getUIs(BombaCombustivelUI.class).stream().filter((obj) -> (((BombaCombustivelUI) obj).getModelo().getCombustivel().getNome().equals(nomeCombustivel))).forEachOrdered((obj) -> {
                if (((BombaCombustivelUI) obj).getModelo().isLigada()) {
                    
                    ((BombaCombustivelUI) obj).desligarBomba();
                    
                    if (((BombaCombustivelUI) obj).getOnOff().isSelected()) {
                        
                        ((BombaCombustivelUI) obj).getOnOff().setSelected(false);
                        
                    } else {
                        
                        ((BombaCombustivelUI) obj).getOnOff().setSelected(true);
                        
                    }

                    while (((BombaCombustivelUI) obj).isLigada) {
                    }
                    
                    if (((BombaCombustivelUI) obj).getOnOff().isSelected()) {
                        
                        ((BombaCombustivelUI) obj).getOnOff().setSelected(false);
                        
                    } else {
                        ((BombaCombustivelUI) obj).getOnOff().setSelected(true);
                    }
                    
                    ((BombaCombustivelUI) obj).ligarBomba();
                    
                } else {
                    
                    if (((BombaCombustivelUI) obj).getOnOff().isSelected()) {
                        
                        ((BombaCombustivelUI) obj).getOnOff().setSelected(false);
                        
                    } else {
                        ((BombaCombustivelUI) obj).getOnOff().setSelected(true);
                    }
                    
                    ((BombaCombustivelUI) obj).ligarBomba();
                    
                }
            });

        } catch (Exception e) {

            System.err.println("Algo deu errado em UIDelegator.notificarTanqueCheioBombasDesteCombustivel\n" + e.getLocalizedMessage());

        }

    }

    public void atualizarBombaStateContainer(BombaCombustivel bombaCombustivel) {
        try {

            getBombaCombustivelUI(bombaCombustivel).atualizarBombaStateContainer();

        } catch (Exception e) {

            System.err.println("Algo deu errado em UIDelegator.atualizarBombaStateContainer\n" + e.getLocalizedMessage());

        }
    }

    public synchronized void atualizarPrecoCombustivel(BombaCombustivel bombaCombustivel, float novoPreco) {

        try {

            getBombaCombustivelUI(bombaCombustivel).getDisplayValorUnidadeCombustivel().setValor(novoPreco);

        } catch (Exception e) {

            System.err.println("Algo deu errado em UIDelegator.atualizarPrecoCombustivel\n" + e.getLocalizedMessage());

        }

    }

    public void refreshReservartorioUI() {

        try {

            ((ReservatorioCombustiveisUI) getUI(ReservatorioCombustiveisUI.class)).setNivelTanques();

        } catch (Exception e) {

            System.err.println("Algo deu errado em UIDelegator.refreshReservartorioUI\n" + e.getLocalizedMessage());

        }

    }

    public void addFrentistaNoTurnoUI(Frentista frentista) {

        try {

            ((TurnoFrentistasUI) getUI(TurnoFrentistasUIImpl.class)).addFrentista(frentista);

        } catch (Exception e) {

            System.err.println("Algo deu errado em UIDelegator.addFrentistaNoTurnoUI\n" + e.getLocalizedMessage());

        }

    }

    public void removeFrentistaNoTurnoUI(Frentista frentista) {
        try {

            ((TurnoFrentistasUI) getUI(TurnoFrentistasUIImpl.class)).removeFrentista(frentista);

        } catch (Exception e) {

            System.err.println("Algo deu errado em UIDelegator.removeFrentistaNoTurnoUI\n" + e.getLocalizedMessage());

        }

    }

}
