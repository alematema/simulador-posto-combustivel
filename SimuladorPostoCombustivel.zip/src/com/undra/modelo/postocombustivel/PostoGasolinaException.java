/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.undra.modelo.postocombustivel;

/**
 *
 * @author alexandre
 */
public class PostoGasolinaException extends Exception {

    public PostoGasolinaException(String msg) {
        super(msg);
    }

}
