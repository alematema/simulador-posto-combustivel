package com.undra.modelo.postocombustivel;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.delegator.excpetion.DelegatorException;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.combustivel.bomba.excetion.BombaCombustivelException;
import com.undra.modelo.combustivel.reservatorio.Reservatorio;
import com.undra.modelo.combustivel.reservatorio.exception.NivelCriticoDeCombustivelException;
import com.undra.modelo.combustivel.reservatorio.exception.ReservatorioExeption;
import com.undra.modelo.contabilidade.Caixa;
import com.undra.modelo.contabilidade.exception.AbastecimentoException;
import com.undra.modelo.contabilidade.exception.CaixaException;
import com.undra.modelo.recursoshumanos.Frentista;
import com.undra.modelo.recursoshumanos.Funcionario;
import com.undra.modelo.recursoshumanos.DepartamentoRecursosHumanos;
import com.undra.modelo.recursoshumanos.exception.RecursosHumanosException;
import com.undra.view.pistaDasBombas.PistaDasBombasUI;
import com.undra.view.pistaDasBombas.PistaDasBombasUIWindow;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * Classe que modela um posto de combustível
 *
 * @author alexandre
 */
public class PostoCombustivel {

    private Reservatorio reservatorio;
    private Collection<BombaCombustivel> modeloPistaBombasCombustivel;
    private ModelDelegator modelDelegator;
    private Collection<Caixa> modeloCaixas;
    private DepartamentoRecursosHumanos departamentoRecursosHumanos;

    private Combustivel gasolina = new Combustivel(Combustivel.GASOLINA, 2.55f, Combustivel.LITRO);
    private Combustivel etanol = new Combustivel(Combustivel.ETANOL, 1.99f, Combustivel.LITRO);
    private Combustivel diesel = new Combustivel(Combustivel.DIESEL, 3.04f, Combustivel.LITRO);
    private Combustivel gnv = new Combustivel(Combustivel.GNV, 1.5f, Combustivel.METRO_CUBICO);

    private Collection<Frentista> frentistasNesteTurno;
    private Collection<Frentista> frentistasAbastecendo;
    private Collection<Frentista> frentistasNaoAbastecendo;
    private final Collection<Funcionario> frentistasCheckedList = new ArrayList();

    private UIDelegator uIDelegator;

    public PostoCombustivel(Reservatorio reservatorio) throws PostoGasolinaException, ReservatorioExeption, CaixaException, BombaCombustivelException {

        if (reservatorio == null) {
            throw new NullPointerException("O reservatório não pode ser null !!!");
        }

        if (reservatorio.getuIDelegator() == null) {
            throw new NullPointerException("O UIDelegator não pode ser null !!!");
        }

        if (reservatorio.getModelDelegator() == null) {
            throw new NullPointerException("O ModelDelegator não pode ser null !!!");
        }

        this.reservatorio = reservatorio;
        uIDelegator = reservatorio.getuIDelegator();
        modelDelegator = reservatorio.getModelDelegator();
        registrarNoModelDelegator();

        frentistasNesteTurno = new ArrayList();
        frentistasAbastecendo = new ArrayList();
        frentistasNaoAbastecendo = new ArrayList();
        modeloPistaBombasCombustivel = new ArrayList();
        modeloCaixas = new ArrayList();

        modeloCaixas.add(new Caixa(modelDelegator, uIDelegator, 1));
        departamentoRecursosHumanos = new DepartamentoRecursosHumanos(modelDelegator, uIDelegator);

        criarCombustiveisDestePosto();

        abastecerTanquesDosCombustiveis(reservatorio);

        construirModeloPistaDasBombasCombustivel();

    }

    private void abastecerTanquesDosCombustiveis(Reservatorio reservatorio) throws ReservatorioExeption {

        try {
            
            reservatorio.abastecer(gasolina, reservatorio.getNIVEL_MAX_TANQUE() / 2);
            reservatorio.abastecer(etanol, reservatorio.getNIVEL_MAX_TANQUE() / 3);
            reservatorio.abastecer(diesel, reservatorio.getNIVEL_MAX_TANQUE() / 4);
            reservatorio.abastecer(gnv, reservatorio.getNIVEL_MAX_TANQUE());
//            reservatorio1.abastecer(gasolina, reservatorio1.getNIVEL_MAX_TANQUE());
//            reservatorio1.abastecer(etanol, reservatorio1.getNIVEL_MAX_TANQUE());
//            reservatorio1.abastecer(diesel, reservatorio1.getNIVEL_MAX_TANQUE());
//            reservatorio1.abastecer(gnv, reservatorio1.getNIVEL_MAX_TANQUE());
        } catch (NivelCriticoDeCombustivelException ex) {
            System.err.println("Algo excepcional ocorreu em PostoCombustivel.abastecerTanquesDosCombustiveis " + ex.getLocalizedMessage());
        }
    }

    private void criarCombustiveisDestePosto() {
        gasolina = new Combustivel(Combustivel.GASOLINA, 2.55f, Combustivel.LITRO);
        etanol = new Combustivel(Combustivel.ETANOL, 1.99f, Combustivel.LITRO);
        diesel = new Combustivel(Combustivel.DIESEL, 3.04f, Combustivel.LITRO);
        gnv = new Combustivel(Combustivel.GNV, 1.5f, Combustivel.METRO_CUBICO);
    }

    private void construirModeloPistaDasBombasCombustivel() {

        BombaCombustivel bombaGasolina;
        try {
            bombaGasolina = new BombaCombustivel(gasolina, 1, modelDelegator, uIDelegator);
            modeloPistaBombasCombustivel.add(bombaGasolina);

            BombaCombustivel bombaEtanol = new BombaCombustivel(etanol, 2, modelDelegator, uIDelegator);
            modeloPistaBombasCombustivel.add(bombaEtanol);

            BombaCombustivel bombaDiesel = new BombaCombustivel(diesel, 3, modelDelegator, uIDelegator);
            modeloPistaBombasCombustivel.add(bombaDiesel);

            BombaCombustivel bombaGasolina2 = new BombaCombustivel(gasolina, 4, modelDelegator, uIDelegator);
            modeloPistaBombasCombustivel.add(bombaGasolina2);

            BombaCombustivel bombaEtanol2 = new BombaCombustivel(etanol, 5, modelDelegator, uIDelegator);
            modeloPistaBombasCombustivel.add(bombaEtanol2);

            BombaCombustivel bombaDiesel2 = new BombaCombustivel(diesel, 6, modelDelegator, uIDelegator);
            modeloPistaBombasCombustivel.add(bombaDiesel2);

            BombaCombustivel bombaGnv = new BombaCombustivel(gnv, 7, modelDelegator, uIDelegator);
            modeloPistaBombasCombustivel.add(bombaGnv);

            BombaCombustivel bombaGnv2 = new BombaCombustivel(gnv, 8, modelDelegator, uIDelegator);
            modeloPistaBombasCombustivel.add(bombaGnv2);

        } catch (BombaCombustivelException ex) {
//            Logger.getLogger(PostoCombustivel.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("Algo excepcional ocorreu em PostoCombustivel.construirModeloPistaDasBombasCombustivel " + ex.getLocalizedMessage());
        }
    }

    private void registrarNoModelDelegator() {
        modelDelegator.registrarModelo(this);
    }

    public void admitirFuncionario(Funcionario funcionario) throws PostoGasolinaException, RecursosHumanosException {

        if (funcionario == null) {
            throw new NullPointerException("O funcionário não pode ser null !!!");
        }

        try {

            departamentoRecursosHumanos.admitirFuncionario(funcionario);

            if (funcionario.isFrentista()) {

                uIDelegator.addFrentistaNoRelatoriosFrentistasAbastecimentosWindow((Frentista) funcionario);
                uIDelegator.addFrentistaNoTurnoUI((Frentista) funcionario);

            }

        } catch (RecursosHumanosException e) {
            System.err.println("Algo excepcional ocorreu em PostoCombustivel.admitirFuncionario " + e.getLocalizedMessage());
        }

    }

    public void demitirFuncionario(Funcionario funcionario) throws PostoGasolinaException, RecursosHumanosException {

        if (funcionario == null) {
            throw new NullPointerException("O funcionário não pode ser null !!!");
        }

        try {

            departamentoRecursosHumanos.demitirFuncionario(funcionario);

            if (funcionario.isFrentista()) {

                getFrentistasNesteTurno().remove((Frentista) funcionario);
                setFrentistasNesteTurno(frentistasNesteTurno);
                uIDelegator.removeFrentistaNoRelatoriosFrentistasAbastecimentosWindow((Frentista) funcionario);
                uIDelegator.removeFrentistaNoTurnoUI((Frentista) funcionario);

            }

        } catch (RecursosHumanosException e) {
            System.err.println("Algo excepcional ocorreu em PostoCombustivel.demitirFuncionario " + e.getLocalizedMessage());
        }

    }

    public Collection<Funcionario> getFuncionarios() {
        return departamentoRecursosHumanos.getFuncionariosAdmitidos();
    }

    public void abasteceReservatorio(Combustivel combustivel, float quantidade) throws ReservatorioExeption, NivelCriticoDeCombustivelException {
        reservatorio.abastecer(combustivel, quantidade);
    }

    public void adicionarBomba(BombaCombustivel bombaCombustivel) throws PostoGasolinaException {
        if (bombaCombustivel == null) {
            throw new NullPointerException("A bomba de combustível não pode ser null !!!");
        }
        modeloPistaBombasCombustivel.add(bombaCombustivel);
    }

    public Collection<BombaCombustivel> getModeloPistaBombasCombustivel() {
        return modeloPistaBombasCombustivel;
    }

    public Collection<Caixa> getModeloCaixas() {
        return modeloCaixas;
    }

    public ModelDelegator getModelDelegator() {
        return modelDelegator;
    }

    public UIDelegator getuIDelegator() {
        return uIDelegator;
    }

    public synchronized void abastecer(Combustivel combustivel, float quantidade) throws PostoGasolinaException, BombaCombustivelException, ReservatorioExeption, AbastecimentoException, DelegatorException, CaixaException {

        frentistasCheckedList.clear();

        departamentoRecursosHumanos.getFuncionariosAdmitidos().stream().filter((f) -> (f.isFrentista())).forEachOrdered((f) -> {
            frentistasCheckedList.add(f);
        });
        if (frentistasCheckedList.isEmpty()) {
            throw new PostoGasolinaException("Não há frentistas empregados no posto !!!");
        }
        if (combustivel == null) {
            throw new NullPointerException("O combustível não pode ser null !!!");
        }

        try {

            //System.err.print("Tentando alocar frentista e bomba combustivel " + combustivel.getNome() + " para abastecer "+ quantidade + " ");
            Frentista frentista = (Frentista) getFrentistaLivre();
            BombaCombustivel bombaCombustivel = getBombaCombustivelLivre(combustivel);

            if (frentista == null || bombaCombustivel == null) {

                //  System.err.println(" NÃO ALOCADOS. TENTANDO OUTRA COMBINACAO DE VALOR E COMBUSTÍVEL :(");
                return;

            }

            modelDelegator.alocarFrentista(frentista);
            modelDelegator.alocarBomba(bombaCombustivel);

            uIDelegator.retirarFrentistaDoBancoReserva(frentista);

            frentista.abasteceComABomba(bombaCombustivel).aQuantidade(quantidade);

            //System.err.println(" ,ok , alocado " + frentista.getNome() + " e " + bombaCombustivel.toStringShorter());
        } catch (Exception e) {

            System.err.println("Algo excepcional ocorreu em PostoCombustivel.abastecer " + e.getLocalizedMessage());

        }

    }

    public synchronized void abastecer(Frentista frentista, BombaCombustivel bombaCombustivel, float quantidade) throws PostoGasolinaException, BombaCombustivelException, ReservatorioExeption, AbastecimentoException, DelegatorException, CaixaException {

        frentistasCheckedList.clear();

        departamentoRecursosHumanos.getFuncionariosAdmitidos().stream().filter((f) -> (f.isFrentista())).forEachOrdered((f) -> {
            frentistasCheckedList.add(f);
        });
        if (frentistasCheckedList.isEmpty()) {
            throw new PostoGasolinaException("Não há frentistas empregados no posto !!!");
        }

        if (frentista == null) {
            throw new NullPointerException("O frentista não pode ser null !!!");
        }

        if (bombaCombustivel == null) {
            throw new NullPointerException("A bomba combustível não pode ser null !!!");
        }

        try {

            frentista.abasteceComABomba(bombaCombustivel).aQuantidade(quantidade);

        } catch (Exception e) {

            System.err.println("Algo excepcional ocorreu em PostoCombustivel.abastecer(Frentista, BombaCombustivel, float) " + e.getLocalizedMessage());

        }

    }

    public Frentista getFrentistaLivre() {

        Frentista frentista = null;

        try {

            Collections.shuffle((List<Frentista>) getFrentistasNesteTurno());

            for (Frentista f : getFrentistasNesteTurno()) {

                if (f.estaLiberado()) {
                    frentista = f;
                    break;
                } else {
                }
            }

        } catch (Exception e) {
            System.err.println("Algo excepcional ocorreu em PostoCombustivel.getFrentistaLivre " + e.getLocalizedMessage());
        }

        return frentista;

    }

    public BombaCombustivel getBombaCombustivelLivre(Combustivel combustivel) {

        BombaCombustivel bombaCombustivel = null;

        try {

            Collections.shuffle((List<BombaCombustivel>) getModeloPistaBombasCombustivel());

            for (BombaCombustivel bomba : getModeloPistaBombasCombustivel()) {

                if (bomba.getCombustivel().equals(combustivel)) {

                    if (bomba.isLiberada()) {
                        bombaCombustivel = bomba;
                        break;
                    }
                }
            }

        } catch (Exception e) {

            System.err.println("Algo excepcional ocorreu em PostoCombustivel.getBombaCombustivelLivre " + e.getLocalizedMessage());

        }

        return bombaCombustivel;
    }

    public synchronized void addFrentistaNesteTurno(Frentista frentista) {

        getFrentistasNesteTurno().add(frentista);

        //ATUALIZA VIEW 
        PistaDasBombasUIWindow pistaDasBombasUIWindow = (PistaDasBombasUIWindow) uIDelegator.getUI(PistaDasBombasUIWindow.class);
        pistaDasBombasUIWindow.getPistaDasBombasUI().addFrentistaNoModeloBancoFrentistasNesteTurno(frentista);

    }

    public synchronized void removeFrentistaDoTurno(Frentista frentista) {

        getFrentistasNesteTurno().remove(frentista);

        //ATUALIZA VIEW 
        PistaDasBombasUIWindow pistaDasBombasUIWindow = (PistaDasBombasUIWindow) uIDelegator.getUI(PistaDasBombasUIWindow.class);
        pistaDasBombasUIWindow.getPistaDasBombasUI().removeFrentistaNoModeloBancoFrentistasNesteTurno(frentista);

    }

    public Collection<Frentista> getFrentistasNesteTurno() {
        return frentistasNesteTurno;
    }

    public void setFrentistasNesteTurno(Collection<Frentista> frentistas) {

        if (frentistas == null) {
            throw new NullPointerException("Os frentistas não podem ser null !!!");
        }

        try {

            Collection<Frentista> frentistasAdmitidos = departamentoRecursosHumanos.getFrentistasAdmitidos();

            frentistasNesteTurno.clear();

            frentistas.forEach((frentista) -> {

                if (frentistasAdmitidos.contains(frentista)) {

                    if (frentista == null) {
                        throw new NullPointerException("O frentista a ser alocado neste turno não pode ser null !!!");
                    }

                    //MUDOU ESTADO
                    frentistasNesteTurno.add(frentista);

                } else {
                    System.err.println("Algo excepcional ocorreu em PostoCombustivel.setFrentistasNesteTurno : frentista " + frentista.getNome() + " não está admitido no dpto recursos humanos.");
                }

            });

            //ATUALIZA VIEW 
            PistaDasBombasUIWindow pistaDasBombasUIWindow = (PistaDasBombasUIWindow) uIDelegator.getUI(PistaDasBombasUIWindow.class);
            pistaDasBombasUIWindow.getPistaDasBombasUI().setModeloBancoFrentistasNesteTurno((List<Frentista>) frentistasNesteTurno);

        } catch (NullPointerException e) {
            throw e;
        } catch (Exception e) {
            System.err.println("Algo excepcional ocorreu em PostoCombustivel.setFrentistasNesteTurno " + e.getLocalizedMessage());
        }

    }

    public Reservatorio getReservatorio() {
        return reservatorio;
    }

    @Override
    public String toString() {
        return "Posto De Combustivel".toUpperCase();
    }

}
