package com.undra.modelo.combustivel.reservatorio;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.modelo.combustivel.reservatorio.exception.SemCombustivelException;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.combustivel.reservatorio.exception.NivelCriticoDeCombustivelException;
import java.util.HashMap;
import java.util.Map;

/**
 * Classe que modela o reservatório de combustíveis.<br>
 * Suporta todos os tipos de combustíveis.<br>
 * Gerencia o nível de cada um dos tanques de combustíveis.<br>
 * Lança exception caso seja solicitado a fornecer uma quantidade<br> de
 * combustível maior do que a que está em um de seus tanques.<br>
 * Lança exception quando se tentar abastecer algum dos tanques e isso levaria o
 * tanque a transbordar.
 * <br>
 * Lança exception quando solicita-se combustível a um tanque sem combustível.
 *
 * @author alexandre
 */
public class Reservatorio {

    static public float NIVEL_MAX_TANQUE;
    static public float NIVEL_MINIMO_TANQUE;

    private final Map<String, Float> tanques;//os tanques de combustíveis do reservatório
    private ModelDelegator modelDelegator;
    private UIDelegator uIDelegator;

    public Reservatorio(float NIVEL_MAX_TANQUE, float NIVEL_MINIMO_TANQUE) {

        Reservatorio.NIVEL_MAX_TANQUE = NIVEL_MAX_TANQUE;
        Reservatorio.NIVEL_MINIMO_TANQUE = NIVEL_MINIMO_TANQUE;

        tanques = new HashMap();
        tanques.put(Combustivel.GASOLINA, 0f);
        tanques.put(Combustivel.ETANOL, 0f);
        tanques.put(Combustivel.DIESEL, 0f);
        tanques.put(Combustivel.GNV, 0f);

    }

    public Reservatorio(float NIVEL_MAX_TANQUE, float NIVEL_MINIMO_TANQUE, ModelDelegator modelDelegator, UIDelegator uIDelegator) {

        this(NIVEL_MAX_TANQUE, NIVEL_MINIMO_TANQUE);

        if (modelDelegator == null) {
            throw new NullPointerException("O ModelDelegator não pode ser null !!!");
        }

        if (uIDelegator == null) {
            throw new NullPointerException("O UIDelegator não pode ser null !!!");
        }

        this.modelDelegator = modelDelegator;
        this.uIDelegator = uIDelegator;

        registrarNoModelDelegator();

    }

    private void registrarNoModelDelegator() {
        modelDelegator.registrarModelo(this);
    }

    /**
     * Abastece com a quantidade o tanque desse combustivel caso não transborde
     * o tanque;
     *
     * @param combustivel o combustivel que o posto vende: gnv, etanol, diesel,
     * gasolina etc
     * @param quantidade a quantidade de combustivel
     * @throws IllegalArgumentException caso argumentos inválidos
     * @throws NivelCriticoDeCombustivelException caso reservatório
     * transbordasse se fosse abastecido com essa quantidade;
     */
    public synchronized void abastecer(Combustivel combustivel, float quantidade) throws NivelCriticoDeCombustivelException {

        if (combustivel == null) {
            throw new NullPointerException("O combustível não pode ser null!!!");
        }
        if (quantidade < 0.0f) {
            throw new IllegalArgumentException("A quantidade a se adicionar ao tanque de " + combustivel.getNome() + " dever ser maior do que zero!!!");
        }

        //assegura que tanque não derramara essa quantidade unidades de combustivel se for abastecido
        if (tanqueTransborda(quantidade, combustivel)) {

            NivelCriticoDeCombustivelException ex = new NivelCriticoDeCombustivelException(quantidade + " " + combustivel.getNomeDaUnidade(quantidade) + " de " + combustivel.getNome() + " ultrapassa(m) a capacidade máxima = (" + Reservatorio.NIVEL_MAX_TANQUE + " " + combustivel.getNomeDaUnidade(quantidade) + ") do tanque deste combustível.\nFavor reduza e tente novamente");
            ex.quantidadeAbastecimento = quantidade;
            ex.nivelAtual = getNivel(combustivel);
            throw ex;

        }

        //abastece o tanque deste combustível
        float nivelAtual = getNivel(combustivel);
        atualizarNivel(combustivel.getNome(), nivelAtual + quantidade);

    }

    /**
     * Abastece com a quantidade o tanque desse combustivel caso não transborde
     * o tanque;
     *
     * @param nomeCombustivel o combustivel que o posto vende: gnv, etanol,
     * diesel, gasolina etc
     * @param quantidade a quantidade de combustivel
     * @throws IllegalArgumentException caso argumentos inválidos
     * @throws NivelCriticoDeCombustivelException caso reservatório
     * transbordasse se fosse abastecido com essa quantidade;
     */
    public synchronized void abastecer(String nomeCombustivel, float quantidade) throws NivelCriticoDeCombustivelException {

        if (nomeCombustivel == null) {
            throw new NullPointerException("O combustível não pode ser null!!!");
        }
        if (quantidade < 0.0f) {
            throw new IllegalArgumentException("A quantidade a se adicionar ao tanque de " + nomeCombustivel + " dever ser maior do que zero!!!");
        }

        //assegura que tanque não derramara essa quantidade unidades de combustivel se for abastecido
        if (tanqueTransborda(quantidade, nomeCombustivel)) {

            NivelCriticoDeCombustivelException ex = new NivelCriticoDeCombustivelException(quantidade + " " + " de " + nomeCombustivel + " ultrapassa(m) a capacidade máxima = (" + Reservatorio.NIVEL_MAX_TANQUE + " " + ") do tanque deste combustível.\nFavor reduza e tente novamente");
            ex.quantidadeAbastecimento = quantidade;
            ex.nivelAtual = getNivel(nomeCombustivel);
            throw ex;

        }

        //abastece o tanque deste combustível
        float nivelAtual = getNivel(nomeCombustivel);
        atualizarNivel(nomeCombustivel, nivelAtual + quantidade);
        uIDelegator.atualizarMensagemConsoleAbastecendoNoControleRemoto(nomeCombustivel, BombaCombustivel.ENCHENDO_O_RESERVATORIO, getNivelAsPorcentagem(nomeCombustivel));

    }

    /**
     * Verifica a quantidade de combustível no tanque e o impacto neste
     * tanque,<br> caso fosse retirada a quantidade solicitada dquele
     * combustível.
     * <br>
     *
     * @param combustivel o combustivel que o posto vende: gnv, etanol, diesel,
     * gasolina etc
     * @param quantidade a quantidade solicitada do combustível
     * @throws NullPointerException caso combustível seja null
     * @throws IllegalArgumentException caso quantidade menor do que zero
     * @throws SemCombustivelException caso o tanque esteja vazio
     * @throws NivelCriticoDeCombustivelException caso reservatório já esteja em
     * NÍVEL CRÍTICO ou fosse pra esse nível, se fornecesse a quantidade.
     */
    public void verificar(Combustivel combustivel, float quantidade) throws SemCombustivelException, NivelCriticoDeCombustivelException {

        if (combustivel == null) {
            throw new NullPointerException("O combustível não pode ser null!!!");
        }

        if (quantidade < 0.0f) {
            throw new IllegalArgumentException("A quantidade a ser verificada de " + combustivel.getNome() + " dever ser maior do que zero. Quantidade solicidata " + quantidade);
        }

        if (tanqueVazio(combustivel)) {

            SemCombustivelException ex = new SemCombustivelException("O tanque de " + combustivel.getNome() + " está sem combustível.");
            throw ex;

        }

        if (isEmNivelCritico(combustivel)) {

            NivelCriticoDeCombustivelException ex = new NivelCriticoDeCombustivelException("O tanque de " + combustivel.getNome() + " está em nível crítico.\nContinuar abastecimento mesmo assim ?\nQuantidade solicitada " + String.format("%.2f",quantidade) + " " + combustivel.getNomeDaUnidadeSI(quantidade) + " \nNível do tanque antes abastecimento " + String.format("%.2f",getNivel(combustivel)));
            ex.quantidadeSolicitada = quantidade;
            ex.quantidadeNoTanque = getNivel(combustivel);
            throw ex;

        } else {

            if (tanqueEsvaziaAbaixoMinimo(quantidade, combustivel)) {

                NivelCriticoDeCombustivelException ex = new NivelCriticoDeCombustivelException("Retirar " + String.format("%.2f",quantidade) + " " + combustivel.getNomeDaUnidade(quantidade) + " de " + combustivel.getNome() + " \nleva(m) o tanque até seu mínimo\n(" + String.format("%.2f",Reservatorio.NIVEL_MINIMO_TANQUE) + " " + combustivel.getNomeDaUnidade(quantidade) + ") ,ou abaixo dele.\nContinuar abastecer mesmo assim ?\nQuantidade solicitada " + String.format("%.2f",quantidade) + " " + combustivel.getNomeDaUnidadeSI(quantidade) + " \nNível do tanque antes abastecimento " + String.format("%.2f",getNivel(combustivel)));
                ex.quantidadeSolicitada = quantidade;
                ex.quantidadeNoTanque = getNivel(combustivel);
                throw ex;

            }
        }

    }

    /**
     * Fornece a quantidade de combustível, se o reservatório NÂO for pra nível
     * critico.<br>
     * Se fosse pra nível critico, lança exceção. Atualiza o nível deste
     * combustível.
     *
     * @param combustivel o combustivel que o posto vende: gnv, etanol, diesel,
     * gasolina etc
     * @param quantidade a quantidade soliciitada
     * @return a quantidade solicitada de combustivel
     * @throws NullPointerException caso combustível seja null
     * @throws IllegalArgumentException caso quantidade menor do que zero
     * @throws SemCombustivelException caso o tanque esteja vazio
     * @throws NivelCriticoDeCombustivelException caso reservatório fosse pra
     * nível crítico se fornecesse a quantidade;
     */
    public synchronized float fornecer(Combustivel combustivel, float quantidade) throws NivelCriticoDeCombustivelException, SemCombustivelException {

        if (combustivel == null) {
            throw new NullPointerException("O combustível não pode ser null!!!");
        }

        if (quantidade < 0.0f) {
            throw new IllegalArgumentException("A quantidade a ser fornecida de " + combustivel.getNome() + " dever ser maior do que zero. Quantidade solicidata " + quantidade);
        }

        if (tanqueVazio(combustivel)) {

            SemCombustivelException ex = new SemCombustivelException("Retirar " + quantidade + " " + combustivel.getNomeDaUnidade(quantidade) + " de " + combustivel.getNome() + " ESVAZIA o tanque.\nFavor abasteça o tanque e tente novamente");

            ex.quantidadeSolicitada = quantidade;
            ex.quantidadeNoTanque = getNivel(combustivel);

            throw ex;

        }

        if (tanqueEsvaziaAbaixoMinimo(quantidade, combustivel)) {

            NivelCriticoDeCombustivelException ex = new NivelCriticoDeCombustivelException("Retirar " + quantidade + " " + combustivel.getNomeDaUnidade(quantidade) + " de " + combustivel.getNome() + " leva(m) o tanque até seu mínimo(" + Reservatorio.NIVEL_MINIMO_TANQUE + " " + combustivel.getNomeDaUnidade(quantidade) + ") ,ou abaixo dele.\nConfirma continuar abastecimento mesmo assim ?\nQuantidade solicitada " + quantidade + " " + combustivel.getNomeDaUnidade(quantidade) + " \nNível do tanque antes de realizar esse abastecimento " + getNivel(combustivel));
            ex.quantidadeSolicitada = quantidade;
            ex.quantidadeNoTanque = getNivel(combustivel);
            throw ex;

        }

        //fornece a quantidade solicitada
        float nivelAtual = getNivel(combustivel);

        //MUDOU ESTADO -> ATUALIZA VIEW
        atualizarNivel(combustivel.getNome(), nivelAtual - quantidade);

        // -> ATUALIZA VIEW
        uIDelegator.atualizarNivelReservatorioNosControlesRemotos(combustivel , getNivel(combustivel));

        return quantidade;

    }

    private synchronized void atualizarNivel(String combustivel, float quantidade) {

        //MUDOU ESTADO -> ATUALIZA VIEW
        tanques.put(combustivel, quantidade);

        //-> ATUALIZA VIEW
        uIDelegator.atualizarNivelTanqueCombustivel(combustivel, getNivel(combustivel));
        uIDelegator.refreshReservartorioUI();
        uIDelegator.atualizarNivelReservatorioNosControlesRemotos(combustivel, getNivel(combustivel));
        
        
    }

    public float getNIVEL_MAX_TANQUE() {
        return NIVEL_MAX_TANQUE;
    }

    public float getNIVEL_MINIMO_TANQUE() {
        return NIVEL_MINIMO_TANQUE;
    }

    public ModelDelegator getModelDelegator() {
        return modelDelegator;
    }

    public UIDelegator getuIDelegator() {
        return uIDelegator;
    }

    public synchronized float retirar(Combustivel combustivel, float quantidade) {

        float nivelAtual = getNivel(combustivel);

        float novoNivel = (nivelAtual - quantidade <= 0) ? 0 : nivelAtual - quantidade;

        //MUDOU ESTADO -> ATUALIZA VIEW
        atualizarNivel(combustivel.getNome(), novoNivel);
        
        return Math.min(nivelAtual, quantidade);
        
    }
    
    public float getNivelAsPorcentagem(String combustivel) {
        return (getNivel(combustivel) / NIVEL_MAX_TANQUE) * 100;
    }

    public synchronized float getNivel(Combustivel combustivel) {
        return tanques.get(combustivel.getNome());
    }

    public synchronized float getNivel(String combustivelNome) {
        return tanques.get(combustivelNome);
    }

    private boolean tanqueTransborda(float quantidade, Combustivel combustivel) {
        return getNivel(combustivel) + quantidade > NIVEL_MAX_TANQUE;
    }

    private boolean tanqueTransborda(float quantidade, String combustivel) {
        return getNivel(combustivel) + quantidade > NIVEL_MAX_TANQUE;
    }

    private synchronized boolean tanqueEsvaziaAbaixoMinimo(float quantidade, Combustivel combustivel) {
        return getNivel(combustivel) - quantidade <= NIVEL_MINIMO_TANQUE;
    }

    private boolean tanqueVazio(Combustivel combustivel) {
        return getNivel(combustivel) <= 0;
    }

    public synchronized boolean isVazio(Combustivel combustivel) {
        return getNivel(combustivel) <= 0;
    }

    public boolean isEmNivelCritico(Combustivel combustivel) {
        return getNivel(combustivel) > 0 && getNivel(combustivel) <= NIVEL_MINIMO_TANQUE;
    }

    public Map<String, Float> getTanques() {
        return tanques;
    }

    @Override
    public String toString() {
        return "RESERVATÓRIO {" + "NIVEL_MAX_TANQUE=" + NIVEL_MAX_TANQUE + ", NIVEL_MINIMO_TANQUE=" + NIVEL_MINIMO_TANQUE + ", tanques=" + tanques + '}';
    }

}
