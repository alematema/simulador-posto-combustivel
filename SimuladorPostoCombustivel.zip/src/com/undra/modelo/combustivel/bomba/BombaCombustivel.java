package com.undra.modelo.combustivel.bomba;

import com.undra.modelo.contabilidade.Abastecimento;
import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.modelo.combustivel.bomba.excetion.BombaCombustivelException;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.reservatorio.exception.SemCombustivelException;
import com.undra.modelo.combustivel.reservatorio.exception.NivelCriticoDeCombustivelException;
import com.undra.modelo.recursoshumanos.Frentista;
import com.undra.modelo.recursoshumanos.Funcionario;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Classe modela uma bomba de combustível.<br>
 *
 * @author alexandre
 */
public final class BombaCombustivel {

    private int id;
    private Combustivel combustivel;

    volatile private Boolean ligada;// volatile forces memory barrier crossing
    volatile private String estado;// volatile forces memory barrier crossing
    volatile public boolean notificarAbastecerEmNivelCritico = true;// volatile forces memory barrier crossing

    private ModelDelegator modelDelegator;
    private UIDelegator uIDelegator;

    private float quantidade;
    private float quantidadeAbastecida = 0;
    private float quantidadeASolicitarAoReservatorio = 0;
    private float quantidadeUltimaAbastecida = 0;

    volatile private int velocidadeAbastecimento;// volatile forces memory barrier crossings

    private Collection<Abastecimento> abastecimentos;
    private Date ligadaAs;

    private Date desligadaAs;

    private Date inicioAbastecimento;
    private Date terminoAbastecimento;

    static public final String PRONTA = "PRONTA";
    static public final String PRONTA_EM_ESTADO_CRITICO = "PRONTA : Em nível CRÍTICO";
    static public final String ALOCADA = "ALOCADA";
    static public final String EM_ESPERA = "EM_ESPERA";
    static public final String ABASTECENDO = "ABASTECENDO";
    static public final String DESLIGADA = "DESLIGADA";
    static public final String LIGADA = "LIGADA";
    static public final String SEM_COMBUSTIVEL = "SEM COMBUSTÍVEL";
    static public final String ABASTECENDO_EM_NIVEL_CRITICO = "Nível CRÍTICO combustível";
    static public final String DESLIGADA_ENQUANTO_ABASTECIA = "DESLIGADA ENQUANTO ABASTECIA";
    static public final String AGUARDANDO_O_CAIXA = "AGUARDANDO O CAIXA...";
    static public final String AGUARDANDO_O_CAIXA_EM_NIVEL_CRITICO_COMBUSTIVEL = "AGUARDANDO O CAIXA EM NIVEL CRITICO...";
    static public final String NAO_ABASTECEU_EM_NIVEL_CRITICO = "NÃO ABASTECEU EM NÍVEL CRÍTICO";
    static public final String ENCHENDO_O_RESERVATORIO = "ENCHENDO O RESERVATÓRIO";

    static public final Combustivel GNV = new Combustivel(Combustivel.GNV, 0, Combustivel.METRO_CUBICO);
    static public final Combustivel ETANOL = new Combustivel(Combustivel.ETANOL, 0, Combustivel.LITRO);
    static public final Combustivel GASOLINA = new Combustivel(Combustivel.GASOLINA, 0, Combustivel.LITRO);
    static public final Combustivel DIESEL = new Combustivel(Combustivel.DIESEL, 0, Combustivel.LITRO);

    private float valorAbastecimento;
    private final float NA0_FORNECIDO = -1;

    private Motor motor;

    private SecureRandom secureRandom;

    private String mensagem;

    private float totalCombustivelAbastecido;
    private float totalDinheiroAbastecido;

    private final SecureRandom random = new SecureRandom();

    public BombaCombustivel(Combustivel combustivel, int id, ModelDelegator modelDelegator, UIDelegator uIDelegator) throws BombaCombustivelException {

        this(combustivel, id, modelDelegator);

        if (uIDelegator == null) {
            throw new NullPointerException("O UI delegator não pode ser null!!!");
        }

        this.uIDelegator = uIDelegator;

    }

    public BombaCombustivel(Combustivel combustivel, int id, ModelDelegator modelDelegator) throws BombaCombustivelException {

        if (combustivel == null) {
            throw new NullPointerException("O combustível não pode ser null!!!");
        }
        if (modelDelegator == null) {
            throw new NullPointerException("O ModelDelegator não pode ser null!!!");
        }

        this.combustivel = combustivel;
        this.id = id;
        this.modelDelegator = modelDelegator;

        abastecimentos = new ArrayList();

        ligada = Boolean.FALSE;

        valorAbastecimento = NA0_FORNECIDO;

        estado = DESLIGADA;

        secureRandom = new SecureRandom();

        //inicializa velocidade da bomba com um valor aleatorio entre e 13 e 40; 
        velocidadeAbastecimento = 13 + secureRandom.nextInt(28);

        registrarNoModelDelegator();

    }

    private void registrarNoModelDelegator() {
        modelDelegator.registrarModelo(this);
    }

    public void ligar() {

        int sleep = 800;

        if (!isLigada()) {

            try {

                simularLigarBomba(sleep);

                atualizarEstado();

                ligada = Boolean.TRUE;
                ligadaAs = new Date();

                uIDelegator.atualizaControleRemotoAposBombaLigar(this);
                uIDelegator.setOnOffNoControleRemoto(this);

            } catch (InterruptedException ex) {
                Logger.getLogger(BombaCombustivel.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }
    
    public void desligar() {

        int sleep = 800;

        if (isLigada()) {

            estado = DESLIGADA;
            ligada = Boolean.FALSE;

            try {

                simularDesligarBomba(sleep);

                desligadaAs = new Date();

                uIDelegator.atualizaControleRemotoAposBombaDesligar(this);
                uIDelegator.setOnOffNoControleRemoto(this);

            } catch (InterruptedException ex) {
                Logger.getLogger(BombaCombustivel.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    private void atualizarEstado() {
        estado = PRONTA;
        
        notificarAbastecerEmNivelCritico = true;
        
        if (modelDelegator.isReservatorioVazio(combustivel)) {
            estado = SEM_COMBUSTIVEL;
            
        }
        if (modelDelegator.isReservatorioEmNivelCritico(combustivel)) {
            estado = PRONTA_EM_ESTADO_CRITICO;
        }
    }

    private void simularLigarBomba(int sleep) throws InterruptedException {
        
        if (motor == null) {
            motor = new Motor(1, 100, velocidadeAbastecimento, uIDelegator, this);
        }
        
        setUpBombaConsoleEDisplays();
        
        testarLeds();
        
        setUp(sleep);
    }

    private void setUp(int sleep) throws InterruptedException {
        uIDelegator.setDisplayTotalDinheiro(0f, this);
        uIDelegator.setDisplayCombustivel(0, this);
        uIDelegator.setDisplayPrecoUnidadeCombustivel(0, this);
        
        uIDelegator.desligarDisplays(this);
        
        uIDelegator.ligarWifiNaBombaCombustivel(this);
        
        Thread.sleep(sleep);
        uIDelegator.setViewConsole("CONECTANDO SERVIDOR ", this);
        uIDelegator.setMensagemConsoleNoControleRemoto("CONECTANDO SERVIDOR ", this);
        Thread.sleep(sleep);
        uIDelegator.setViewConsole("CONECTADO (OK)", this);
        uIDelegator.setMensagemConsoleNoControleRemoto("CONECTADO (OK) ", this);
        Thread.sleep(sleep);
        uIDelegator.setViewConsole("SOLICITANDO FRENTISTAS", this);
        uIDelegator.setMensagemConsoleNoControleRemoto("SOLICITANDO FRENTISTAS", this);
        Thread.sleep(sleep);
        uIDelegator.setViewConsole("PREÇO ATUAL RECEBIDO", this);
        Thread.sleep(sleep);
        
        uIDelegator.setViewConsole("VERIFICANDO RESERVATÓRIO", this);
        uIDelegator.setMensagemConsoleNoControleRemoto("VERIFICANDO RESERVATÓRIO", this);
        Thread.sleep(sleep + 800);
        uIDelegator.ligarDisplays(this);
    }

    private void testarLeds() throws InterruptedException {
        
        String testandoLeds="TESTANDO LEDS ";
        
        uIDelegator.setViewConsole(testandoLeds, this);
        uIDelegator.setMensagemConsoleNoControleRemoto(testandoLeds, this);
        Thread.sleep(900);
        
        double[] displaysLedsTest = {0f, 111.11, 222.22, 333.33, 444.44, 555.55, 666.66, 777.77, 888.88, 999.99};
        
        for (int i = 0; i < 10; i++) {
            
            uIDelegator.setViewConsole(testandoLeds + Double.toString(displaysLedsTest[i]), this);
            uIDelegator.setMensagemConsoleNoControleRemoto(testandoLeds + Double.toString(displaysLedsTest[i]), this);
            uIDelegator.setDisplayTotalDinheiro((float) displaysLedsTest[i], this);
            uIDelegator.setDisplayCombustivel((float) displaysLedsTest[i], this);
            uIDelegator.setDisplayPrecoUnidadeCombustivel((float) displaysLedsTest[i], this);
            Thread.sleep(300);
            
        }
    }

    private void setUpBombaConsoleEDisplays() throws InterruptedException {
        uIDelegator.setViewConsole("LIGANDO", this);
        uIDelegator.setMensagemConsoleNoControleRemoto("LIGANDO", this);
        int sleep = 800;
        Thread.sleep((int)1.7*sleep);
        uIDelegator.setDisplayTotalDinheiro(0, this);
        uIDelegator.setDisplayCombustivel(0, this);
        uIDelegator.setDisplayPrecoUnidadeCombustivel(0, this);
        uIDelegator.setViewConsole("LIGANDO.", this);
        uIDelegator.setMensagemConsoleNoControleRemoto("LIGANDO.", this);
        Thread.sleep((int)1.7*sleep);
        uIDelegator.setViewConsole("LIGANDO..", this);
        uIDelegator.setMensagemConsoleNoControleRemoto("LIGANDO..", this);
        Thread.sleep((int)1.7*sleep);
        
        uIDelegator.setViewConsole("LIGANDO...", this);
        uIDelegator.setMensagemConsoleNoControleRemoto("LIGANDO...", this);
        Thread.sleep((int)sleep);
        
        uIDelegator.ligarDisplays(this);
    }

    

    private void simularDesligarBomba(int sleep) throws InterruptedException {

        desligarMotor(sleep);
        
        setDown(sleep);
    }

    private void setDown(int sleep) throws InterruptedException {
        uIDelegator.setViewConsole("ENVIADO RELATÓRIOS", this);
        uIDelegator.setMensagemConsoleNoControleRemoto("ENVIANDO RELATÓRIOS", this);
        Thread.sleep(sleep);
        uIDelegator.setViewConsole("REL. ABASTECIMENTOS (ok)", this);
        uIDelegator.setMensagemConsoleNoControleRemoto("REL. ABASTECIMENTOS (ok)", this);
        Thread.sleep(sleep);
        uIDelegator.desLigarDisplayTotalCombustivel(this);
        uIDelegator.setViewConsole("REL. DE FALHAS (ok)", this);
        uIDelegator.setMensagemConsoleNoControleRemoto("REL. DE FALHAS(ok) ", this);
        Thread.sleep(sleep);
        uIDelegator.setViewConsole("DESCONECTANDO SERVIDOR", this);
        uIDelegator.setMensagemConsoleNoControleRemoto("DESCONECTANDO SERVIDOR", this);
        Thread.sleep(sleep);
        uIDelegator.desLigarDisplayPrecoUnidadeCombustivel(this);
        uIDelegator.setViewConsole("BYE", this);
        Thread.sleep(sleep);
    }

    private void desligarMotor(int sleep) throws InterruptedException {
        uIDelegator.desLigarDisplayTotalDinheiro(this);
        //ligar motor
        String s = "DESLIGANDO MOTOR";
        motor.desligar();
        uIDelegator.setViewConsole(s, this);
        uIDelegator.setMensagemConsoleNoControleRemoto(s, this);
        for (int i = 0; i < 3; i++) {
            
            Thread.sleep((int)1.9*sleep);
            s += ".";
            uIDelegator.setViewConsole(s, this);
            uIDelegator.setMensagemConsoleNoControleRemoto(s, this);
            
        }
        
        uIDelegator.setViewConsole("MOTOR DESLIGADO", this);
        uIDelegator.setMensagemConsoleNoControleRemoto("MOTOR DESLIGADO", this);
        Thread.sleep(sleep);
    }

    public synchronized void abastecer(Funcionario frentista, float quantidade) throws BombaCombustivelException {

        if (!validar(quantidade, frentista)) {
            return;
        }

        if (!reservatorioTemParaOferecerEstaQuantidadeCombustivel(quantidade, frentista)) {
            return;
        }

        if (estado.equals(ABASTECENDO_EM_NIVEL_CRITICO)) {

            //TODO aguardar possivel reabastecimento do tanque deste combustivel caso frentista escolha abastecer o reservatório antes de 
            // continuar ABASTECENDO_EM_NIVEL_CRITICO
            //confirma se deseja continuar abastecimento mesmo em niviel critico
            if (notificarAbastecerEmNivelCritico) {

                int resposta = uIDelegator.confirmarAbastecerEmNivelCritico(getMensagem(), this);

                if (resposta == UIDelegator.SIM) {

                } else if (resposta == UIDelegator.NAO) {

                    System.err.println(toStringShorter() + " NÃO CONFIRMOU ABASTECER EM NIVEL CRITICO ");

                    setTotalCombustivelAbastecido(0f);
                    setTotalDinheiroAbastecido(0f);
                    estado = NAO_ABASTECEU_EM_NIVEL_CRITICO;
                    setMensagem(estado);

                    liberarFrentista(frentista);

                    modelDelegator.desbloquearBomba(this);

                    return;

                } else if (resposta == UIDelegator.OUTRA_ACAO) {

                    System.err.println(toStringShorter() + " OUTRA ACAO : NÃO CONFIRMOU ABASTECER EM NIVEL CRITICO ");

                    estado = ENCHENDO_O_RESERVATORIO;

                    setMensagem(estado);

                    liberarFrentista(frentista);

                    return;

                }

            }

        }

        uIDelegator.setVisibleStateBombaContainer(false, this);//atualiza UI : apaga luz da bomba pra por frentistas
        uIDelegator.setFrentista(frentista, this);//atualiza UI : poe frentista na bomba

        motor.ligar();

        inicioAbastecimento = new Date();

        /**
         * Durante simular abastecer podem ocorrer 3 cenários:
         *
         * 1. normal               : abastece a quantidade solicitada e retorna; 
         * 2. acabar o combustivel : abastece quantidade que tinha no reservatorio e
         * retorna(abastece menos dq a qtde solicitada) 
         * 3. desligar a bomba     : abastece quantidade <= dq a solicitada
         *
         */
        if (!simularAbastecer((Frentista) frentista, quantidade)) {
            motor.desligar();
            return;
        }

        motor.desligar();

        valorAbastecimento = combustivel.getPrecoDaUnidade() * quantidade;

        terminoAbastecimento = new Date();

        Abastecimento abastecimento = modelDelegator.delegarAoCaixaAbastecimento(frentista, combustivel, quantidadeAbastecida, valorAbastecimento, inicioAbastecimento, terminoAbastecimento, this, estado);

        addAbastecimento(abastecimento);

        setTotalCombustivelAbastecido(quantidade);
        setTotalDinheiroAbastecido(valorAbastecimento);

        if (estado.equals(ABASTECENDO_EM_NIVEL_CRITICO)) {

            estado = AGUARDANDO_O_CAIXA_EM_NIVEL_CRITICO_COMBUSTIVEL;

            setMensagem(AGUARDANDO_O_CAIXA_EM_NIVEL_CRITICO_COMBUSTIVEL);

        } else if (estado.equals(ABASTECENDO)) {

            estado = AGUARDANDO_O_CAIXA;

            setMensagem(AGUARDANDO_O_CAIXA);

        }

        liberarFrentista(frentista);

    }

    private boolean simularAbastecer(Frentista frentista, float quantidade) {

        estado = ABASTECENDO;

        setMensagem(estado);

        setMensagem(String.format("%s %.2f %s", "Abastecendo", quantidade, combustivel.getNomeDaUnidade(quantidade).toLowerCase()));

        uIDelegator.setVelocidadeAbastecimentoNoControleRemoto(this);

        quantidadeUltimaAbastecida = 0f;
        setQuantidadeAbastecidaEQuantidadeAAbastecer(0f, quantidade);
        float totalRetiradoDoReservatorio = 0f;

        //simula estar abastecendo
        for (int qtde = 0; totalRetiradoDoReservatorio < quantidade;) {

            if (ligada) {

                float qtdAbastecidaRandom = getQuantidadeAbastecida() + random.nextFloat();

                quantidadeASolicitarAoReservatorio = qtdAbastecidaRandom - quantidadeUltimaAbastecida;

                try {

                    try {

                        modelDelegator.solicitarVerificacaoAoReservatorio(combustivel, quantidadeASolicitarAoReservatorio);

                    } catch (NivelCriticoDeCombustivelException ex) {

                        estado = ABASTECENDO_EM_NIVEL_CRITICO;

                    }

                    //ok : o reservatorio tem pra oferecer normalmente a qntidade
                    if (totalRetiradoDoReservatorio + quantidadeASolicitarAoReservatorio <= quantidade) {//assegura não tirar do reservatorio mais do que foi solicitado no abastecimento

                        modelDelegator.retirarDoReservatorio(combustivel, quantidadeASolicitarAoReservatorio);

                        totalRetiradoDoReservatorio += quantidadeASolicitarAoReservatorio;

                        setQuantidadeAbastecidaEQuantidadeAAbastecer(totalRetiradoDoReservatorio, quantidade);

                        try {
                            Thread.sleep((int) (50 * (int) 100 * (1.0 / motor.getVelocidade())));
                        } catch (InterruptedException ex) {
                            Logger.getLogger(BombaCombustivel.class.getName()).log(Level.SEVERE, null, ex);
                        }

                        quantidadeUltimaAbastecida = (float) Math.nextDown(totalRetiradoDoReservatorio);

                    } else {//terminou normalmente o abastecimento

                        quantidadeASolicitarAoReservatorio = quantidade - totalRetiradoDoReservatorio;

                        modelDelegator.retirarDoReservatorio(combustivel, quantidadeASolicitarAoReservatorio);

                        totalRetiradoDoReservatorio += quantidadeASolicitarAoReservatorio;

                        setQuantidadeAbastecidaEQuantidadeAAbastecer(totalRetiradoDoReservatorio, quantidade);

                        quantidadeUltimaAbastecida = (float) Math.nextDown(totalRetiradoDoReservatorio);

                        this.quantidade = quantidadeUltimaAbastecida;

                        break;

                    }

                } catch (SemCombustivelException ex) {//reservatório ficou sem combustivel enquanto abastecia

                    System.err.println("\t" + this.toStringShorter() + " ficou sem combustível enquanto abastecia :(");

                    valorAbastecimento = totalRetiradoDoReservatorio * combustivel.getPrecoDaUnidade();

                    terminoAbastecimento = new Date();

                    liberarFrentista(frentista);
                    setTotalDinheiroAbastecido(0f);
                    setTotalCombustivelAbastecido(0f);

                    estado = SEM_COMBUSTIVEL;

                    addAbastecimento(modelDelegator.delegarAoCaixaAbastecimento(frentista, combustivel, totalRetiradoDoReservatorio, valorAbastecimento, inicioAbastecimento, terminoAbastecimento, this, estado));

                    setMensagem(SEM_COMBUSTIVEL);

                    return false;

                }

            } else {//bomba foi desligada enquanto abastecia

                System.err.println(this.toStringShorter() + " foi desligada enquanto abastecia");

                valorAbastecimento = totalRetiradoDoReservatorio * combustivel.getPrecoDaUnidade();

                liberarFrentista(frentista);

                setTotalDinheiroAbastecido(0f);
                setTotalCombustivelAbastecido(0f);

                setMensagem(DESLIGADA_ENQUANTO_ABASTECIA);

                terminoAbastecimento = new Date();

                Abastecimento abastecimento = modelDelegator.delegarAoCaixaAbastecimento(frentista, combustivel, totalRetiradoDoReservatorio, valorAbastecimento, inicioAbastecimento, terminoAbastecimento, this, DESLIGADA_ENQUANTO_ABASTECIA);
                addAbastecimento(abastecimento);

                return false;
            }

        }

        //abasteceu a quantidade solicitada
        quantidadeAbastecida = totalRetiradoDoReservatorio;

        return true;

    }

    private boolean validar(float quantidade, Funcionario frentista) throws IllegalArgumentException, BombaCombustivelException, NullPointerException {

        if (quantidade <= 0) {
            liberarFrentista(frentista);
            desbloquear();
            throw new IllegalArgumentException("A quantidade de " + combustivel.getNome() + " deve ser maior do que zero.");
        }

        if (frentista == null) {
            desbloquear();
            throw new NullPointerException("O frentista não pode ser null!!!");
        }

        if (!isLigada()) {
            liberarFrentista(frentista);
            desbloquear();
            throw new BombaCombustivelException("A " + this.toStringShorter() + " está desligada. Impossível abastecer. Ligue-a.");
        }
        if (isSemCombustivel()) {//TODO OQ FAZER ? DESBLOQUEAR ? O RESERVATORIO A IRIAR DESBLOQUEAR?
            liberarFrentista(frentista);
            System.err.println("A bomba " + toStringShorter() + " está sem combustível");
            return false;
        }
        if (isAbastecendo()) {
            throw new BombaCombustivelException("A bomba " + this.toStringShorter() + " está abastecendo. Aguarde estar PRONTA.");
        }

        return true;
    }

    private void liberarFrentista(Funcionario frentista) {
        modelDelegator.liberarFrentista(frentista);//frentista abasteceu. liberado pra abastecer outra vez
        uIDelegator.liberarFrentista(frentista, this);
    }

    public void setUiDelegator(UIDelegator uIDelegator) {
        this.uIDelegator = uIDelegator;
    }

    public boolean isSemCombustivel() {
        return getEstado().equals(SEM_COMBUSTIVEL);
    }

    public boolean isEmEstadoCritico() {
        return getEstado().equals(PRONTA_EM_ESTADO_CRITICO);
    }

    public Boolean isLigada() {
        return ligada;
    }

    public boolean isLiberada() {
        return estado.equals(PRONTA) || getEstado().equals(PRONTA_EM_ESTADO_CRITICO);
    }

    public boolean isAbastecendo() {
        return getEstado().equals(ABASTECENDO) || getEstado().equals(ABASTECENDO_EM_NIVEL_CRITICO);
    }

    public boolean naoAbasteceuEmNivelCritico() {
        return estado.equals(NAO_ABASTECEU_EM_NIVEL_CRITICO);
    }
    
    
    public boolean isAguardandoEncherReservatorio() {
        return estado.equals(ENCHENDO_O_RESERVATORIO);
    }

    public String getEstado() {
        return estado;
    }

    public void desbloquear() {

        estado = PRONTA;

        if (modelDelegator.isReservatorioEmNivelCritico(combustivel)) {

            estado = PRONTA_EM_ESTADO_CRITICO;

        }

    }

    public UIDelegator getUIDelegator() {
        return uIDelegator;
    }

    public boolean alocar() {
        if (!isLiberada()) {
            return false;
        }
        estado = ALOCADA;
        return true;
    }

    public boolean isAlocada() {
        return estado.equals(ALOCADA);
    }

    public int getVelocidadeAbastecimento() {
        return velocidadeAbastecimento;
    }

    public int getId() {
        return id;
    }

    public Combustivel getCombustivel() {
        return this.combustivel;
    }

    public Collection<Abastecimento> getAbastecimentos() {
        return abastecimentos;
    }

    public ModelDelegator getModelDelegator() {
        return modelDelegator;
    }

    public Motor getMotor() {
        return motor;
    }

    public Date getLigadaAs() {
        return ligadaAs;
    }

    public Date getDesligadaAs() {
        return desligadaAs;
    }

    public void setTotalCombustivelAbastecido(float totalCombustivelAbastecido) {

        //MUDOU ESTADO -> ATUALIZA VIEW
        this.totalCombustivelAbastecido = totalCombustivelAbastecido;

        //-> ATUALIZA VIEW
        uIDelegator.setDisplayCombustivel(totalCombustivelAbastecido, this);
    }

    public void setTotalDinheiroAbastecido(float totalDinheiroAbastecido) {

        //MUDOU ESTADO -> ATUALIZA VIEW
        this.totalDinheiroAbastecido = totalDinheiroAbastecido;

        //-> ATUALIZA VIEW
        uIDelegator.setDisplayTotalDinheiro(totalDinheiroAbastecido, this);
    }

    public void setVelocidadeAbastecimento(int novoValor) {
        velocidadeAbastecimento = novoValor;
        motor.setVelocidade(velocidadeAbastecimento);
    }

    private boolean reservatorioTemParaOferecerEstaQuantidadeCombustivel(float quantidade, Funcionario frentista) {

        try {

            modelDelegator.solicitarVerificacaoAoReservatorio(combustivel, quantidade);

        } catch (NullPointerException ex) {

            System.err.println("Algo deu errado em " + toStringShorter() + ".reservatorioTemParaOferecerEstaQuantidadeCombustivel:combustivel null \n" + ex.getLocalizedMessage());

            liberarFrentista(frentista);

            modelDelegator.desbloquearBomba(this);

            return false;

        } catch (IllegalArgumentException ex) {

            System.err.println("Algo deu errado em " + toStringShorter() + ".reservatorioTemParaOferecerEstaQuantidadeCombustive:quantidade < 0.0\n" + ex.getLocalizedMessage());

            setMensagem("Argumentos inválidos");

            liberarFrentista(frentista);

            modelDelegator.desbloquearBomba(this);

            return false;

        } catch (SemCombustivelException ex) {

            System.err.println("Algo deu errado em " + toStringShorter() + ".reservatorioTemParaOferecerEstaQuantidadeCombustivel: SEM COMBUSTÍVEL\n" + ex.getLocalizedMessage());

            liberarFrentista(frentista);

            estado = SEM_COMBUSTIVEL;

            setMensagem(estado);

            return false;

        } catch (NivelCriticoDeCombustivelException ex) {

            estado = ABASTECENDO_EM_NIVEL_CRITICO;

            setMensagem(ex.getMessage());

            return true;
        }

        return true;

    }

    public void addAbastecimento(Abastecimento abastecimento) {

        //MUDOU ESTADO -> ATUALIZA VIEW
        abastecimentos.add(abastecimento);

        //-> ATUALIZA VIEW
        uIDelegator.setAbastecimentosNoControleRemoto(this);
        uIDelegator.setTotalCombustivelAbastecidoNoControleRemoto(abastecimento.getQuantidade(), this);
        uIDelegator.addNovoAbastecimentoNoControleRemoto(abastecimento, this);

        ((Frentista) abastecimento.getFrentista()).addAbastecimento(abastecimento);

    }

    public void setPrecoDaUnidade(float novoPreco) {

        //MUDOU ESTADO -> ATUALIZA VIEW
        getCombustivel().setPrecoDaUnidade(novoPreco);

        //-> ATUALIZA VIEW
        uIDelegator.atualizarPrecoCombustivel(this, novoPreco);
    }

    private void setQuantidadeAbastecidaEQuantidadeAAbastecer(float quantidadeAbastecida, float quantidade) {

        //MUDOU ESTADO -> ATUALIZA VIEW
        this.quantidadeAbastecida = quantidadeAbastecida;
        this.quantidade = quantidade;

        //-> ATUALIZA VIEW
        uIDelegator.setDisplayCombustivel(quantidadeAbastecida, this);
        uIDelegator.setDisplayTotalDinheiro(quantidadeAbastecida * combustivel.getPrecoDaUnidade(), this);
        uIDelegator.setAbastecendoEmControleRemoto(quantidadeAbastecida, quantidade, this);
        uIDelegator.atualizarTotalCombustivelAbastecidoNoControleRemoto(quantidadeAbastecida, this);

    }

    public float getQuantidadeAbastecida() {
        return quantidadeAbastecida;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {

        System.err.println(toStringShorter() + " ******************************** " + mensagem);

        //MUDOU ESTADO -> ATUALIZA VIEW
        this.mensagem = mensagem;

        //-> ATUALIZA VIEW
        try {
            mensagem = mensagem.substring(0, 21);
        } catch (Exception e) {
        }
        uIDelegator.setViewConsole(mensagem, this);
        uIDelegator.setMensagemAguardandoOCaixaNoControleRemoto(mensagem, this);

        //-> ATUALIZA VIEW
        if (mensagem.equals(AGUARDANDO_O_CAIXA)) {

            uIDelegator.setVisibleStateBombaContainer(true, this);
            uIDelegator.pulsarBombaOkWaitingState(this);

        } else if (mensagem.equals(AGUARDANDO_O_CAIXA_EM_NIVEL_CRITICO_COMBUSTIVEL)) {

            uIDelegator.setVisibleStateBombaContainer(true, this);
            uIDelegator.pulsarBombaBadWaitingState(this);

        }

        //-> ATUALIZA VIEW
        if (mensagem.equals(ABASTECENDO_EM_NIVEL_CRITICO)) {
            uIDelegator.setVisibleStateBombaContainer(true, this);
            uIDelegator.pulsarBombaBadWaitingState(this);
        }

        //-> ATUALIZA VIEW
        if (mensagem.equals(SEM_COMBUSTIVEL)) {
            uIDelegator.setConsoleBackgroundAbastecimentoTerminado(this);
            uIDelegator.setVisibleStateBombaContainer(false, this);
            uIDelegator.notificarDesligamentoDaBombaSemCombustivel(this);
            uIDelegator.atualizarMenuLigarDesligarBombasNoMyMenuBar();
        }
        //-> ATUALIZA VIEW
        if (mensagem.equals(DESLIGADA_ENQUANTO_ABASTECIA)) {
            uIDelegator.setConsoleBackgroundAbastecimentoTerminado(this);
            uIDelegator.setVisibleStateBombaContainer(false, this);
        }

        //-> ATUALIZA VIEW
        if (mensagem.equals(NAO_ABASTECEU_EM_NIVEL_CRITICO)) {
            uIDelegator.setConsoleBackgroundAbastecimentoTerminado(this);
            uIDelegator.atualizarBombaStateContainer(this);
        }

        //-> ATUALIZA VIEW
        if (mensagem.equals(ENCHENDO_O_RESERVATORIO)) {
            uIDelegator.setConsoleBackgroundAbastecimentoTerminado(this);
            uIDelegator.atualizarBombaStateContainer(this);
        }

    }

    public boolean isGNV() {
        return this.getCombustivel().equals(GNV);
    }

    public boolean isEtanol() {
        return getCombustivel().equals(ETANOL);
    }

    public boolean isGasolina() {
        return getCombustivel().equals(GASOLINA);
    }

    public boolean isDiesel() {
        return getCombustivel().equals(DIESEL);
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final BombaCombustivel other = (BombaCombustivel) obj;
        return this.id == other.id;
    }

    @Override
    public String toString() {
        return "BOMBA COMBUSTÍVEL " + id + ", " + combustivel.getNome().toUpperCase();
    }

    public String toStringShorter() {
        return "BOMBA " + getId() + ", " + getCombustivel().getNome();
    }


}
