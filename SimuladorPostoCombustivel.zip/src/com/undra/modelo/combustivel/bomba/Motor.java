/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.modelo.combustivel.bomba;

import com.undra.delegator.UIDelegator;
import java.awt.event.ActionEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Timer;

/**
 * O motor da bomba de combustível
 *
 * @author alexandre
 */
public class Motor {

    private final int MIN_VELOCIDADE;
    private final int MAX_VELOCIDADE;

    public static final float TEMPERATURA_AMBIENTE = 27.05f;
    private static final float TEMPERATURA_NORMAL_LIMITE = 50f;
    private static final float TEMPERATURA_QUENTE_LIMITE = 75f;
    private static final float TEMPERATURA_CRITICA_LIMITE = 95f;
    volatile private boolean isRefrigerando = false;// volatile forces memory barrier crossing

    private final Timer aumentarTemperaturaTimer;
    private final Timer diminuirTemperaturaTimer;
    private final Timer refrigeradorMotorTimer;
    private final int tempoDeRefrigeracao = 5000;

    private int velocidade;
    private float temperatura = TEMPERATURA_AMBIENTE;

    private final float inc = 0.9498765f;
    private final float dec = 0.6934912789f;
    private final float dec_refr = 3.95f;

    private final int incDelay = 350;
    private final int decDelay = 350;
    private final int inc_refrDelay = 250;

    private boolean isLigado = false;

    private UIDelegator uIDelegator;
    private BombaCombustivel bombaCombustivel;

    public Motor(int MIN_VELOCIDADE, int MAX_VELOCIDADE) {

        this.refrigeradorMotorTimer = new Timer(inc_refrDelay, this::refrigerarMotorActionPerformed);

        this.MIN_VELOCIDADE = MIN_VELOCIDADE;
        this.MAX_VELOCIDADE = MAX_VELOCIDADE;

        this.aumentarTemperaturaTimer = new Timer(incDelay, (e) -> {
            aumentarTemperaturaActionPerformed(e);
        });
        this.diminuirTemperaturaTimer = new Timer(decDelay, (e) -> {
            diminuirTemperaturaActionPerformed(e);
        });

    }

    public Motor(int MIN_VELOCIDADE, int MAX_VELOCIDADE, int velocidade, UIDelegator uIDelegator, BombaCombustivel bombaCombustivel) {

        if (uIDelegator == null) {
            throw new NullPointerException("O UI Delegator não pode ser null");
        }
        if (bombaCombustivel == null) {
            throw new NullPointerException("A bomba combustível não pode ser null");
        }

        this.MIN_VELOCIDADE = MIN_VELOCIDADE;
        this.MAX_VELOCIDADE = MAX_VELOCIDADE;
        setVelocidade(velocidade);
        this.uIDelegator = uIDelegator;
        this.bombaCombustivel = bombaCombustivel;

        this.refrigeradorMotorTimer = new Timer(inc_refrDelay, (e) -> {
            refrigerarMotorActionPerformed(e);
        });

        this.aumentarTemperaturaTimer = new Timer(incDelay, (e) -> {
            aumentarTemperaturaActionPerformed(e);
        });
        this.diminuirTemperaturaTimer = new Timer(decDelay, (e) -> {
            diminuirTemperaturaActionPerformed(e);
        });

    }

    static public boolean isTemperaturaNormal(float temperatura) {
        return TEMPERATURA_AMBIENTE <= temperatura && temperatura <= TEMPERATURA_NORMAL_LIMITE;
    }

    static public boolean isQuente(float temperatura) {
        return TEMPERATURA_NORMAL_LIMITE < temperatura && temperatura <= TEMPERATURA_QUENTE_LIMITE;
    }

    static public boolean isTemperaturaCritica(float temperatura) {
        return TEMPERATURA_QUENTE_LIMITE < temperatura && temperatura <= TEMPERATURA_CRITICA_LIMITE;
    }

    public void setIsRefrigerando(boolean isRefrigerando) {
        this.isRefrigerando = isRefrigerando;
    }

    public boolean isTemperaturaNormal() {
        return TEMPERATURA_AMBIENTE <= temperatura && temperatura <= TEMPERATURA_NORMAL_LIMITE;
    }

    public boolean isQuente() {
        return TEMPERATURA_NORMAL_LIMITE < temperatura && temperatura <= TEMPERATURA_QUENTE_LIMITE;
    }

    public boolean isTemperaturaCritica() {
        return TEMPERATURA_QUENTE_LIMITE < temperatura && temperatura <= TEMPERATURA_CRITICA_LIMITE;
    }

    public float getTemperatura() {
        return temperatura;
    }

    public int getVelocidade() {
        return velocidade;
    }

    public final void setVelocidade(int velocidade) {

        if (velocidade < MIN_VELOCIDADE) {
            throw new IllegalArgumentException("A velocidade do motor não pode ser < do que " + MIN_VELOCIDADE + ". Valor passado=" + velocidade);
        }
        if (velocidade > MAX_VELOCIDADE) {
            throw new IllegalArgumentException("A velocidadedo do motor não pode ser > do que " + MAX_VELOCIDADE + ". Valor passado=" + velocidade);
        }

        this.velocidade = velocidade;
    }

    private void aumentarTemperaturaActionPerformed(ActionEvent e) {

        if (!isRefrigerando) {

            temperatura += inc;

//            System.err.println("+aumentando temperatura em " + String.format("%.2f", inc) + " " + String.format("%.2f", temperatura));
            uIDelegator.setTemperaturaMotorNoControleRemoto(temperatura, bombaCombustivel);
            uIDelegator.setUpArrowNoControleRemoto(bombaCombustivel);

            if (temperatura >= TEMPERATURA_CRITICA_LIMITE) {
                refrigerar();
            }

        } else {
        }

    }

    private void diminuirTemperaturaActionPerformed(ActionEvent e) {

        if (!isRefrigerando) {

            temperatura -= dec;

//            System.err.println("-diminuindo temperatura em " + String.format("%.2f", dec) + " " + String.format("%.2f", temperatura));
            if (temperatura < TEMPERATURA_AMBIENTE) {

                temperatura = TEMPERATURA_AMBIENTE;

                if (!isLigado) {
                    diminuirTemperaturaTimer.stop();
                    while (diminuirTemperaturaTimer.isRunning()) {
                    }
                }

            }

            uIDelegator.setTemperaturaMotorNoControleRemoto(temperatura, bombaCombustivel);
            uIDelegator.setDownArrowNoControleRemoto(bombaCombustivel);

        } else {
        }

    }

    private void refrigerarMotorActionPerformed(ActionEvent e) {

        temperatura -= dec_refr;

//        System.err.println("-(REFRIGERANDO)diminuindo temperatura em " + String.format("%.2f", dec_refr) + " " + String.format("%.2f", temperatura));
        uIDelegator.setTemperaturaMotorNoControleRemoto(temperatura, bombaCombustivel);
        uIDelegator.setDownArrowNoControleRemoto(bombaCombustivel);
        if (temperatura <= TEMPERATURA_AMBIENTE) {
            temperatura = TEMPERATURA_AMBIENTE;
        }
    }

    public void ligar() {

        diminuirTemperaturaTimer.stop();
        while (diminuirTemperaturaTimer.isRunning()) {
        }

        aumentarTemperaturaTimer.start();

        isLigado = true;

    }

    public void desligar() {

        aumentarTemperaturaTimer.stop();
        while (aumentarTemperaturaTimer.isRunning()) {
        }

        diminuirTemperaturaTimer.start();

        isLigado = false;
    }

    public void refrigerar() {

        new Thread(() -> {

            setIsRefrigerando(true);

            refrigeradorMotorTimer.start();

            try {
                Thread.sleep(tempoDeRefrigeracao);
            } catch (InterruptedException ex) {
                Logger.getLogger(Motor.class.getName()).log(Level.SEVERE, null, ex);
            }

            refrigeradorMotorTimer.stop();
            while (refrigeradorMotorTimer.isRunning()) {
            }

            setIsRefrigerando(false);

        }).start();

    }

    public static void main(String[] args) throws InterruptedException {

        Motor motor = new Motor(0, 100);

        motor.setVelocidade(40);

        motor.ligar();

        Thread.sleep(5000);

        motor.refrigerar();

        Thread.sleep(6000);

        motor.desligar();

//        motor.refrigerar();
//        motor.desligar();
//
//        Thread.sleep(5000);
//
//        Thread.sleep(5000);
//
//        motor.ligar();
//
//        Thread.sleep(5000);
    }

}
