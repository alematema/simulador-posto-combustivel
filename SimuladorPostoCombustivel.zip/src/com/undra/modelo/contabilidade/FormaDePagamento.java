package com.undra.modelo.contabilidade;

/**
 *
 * @author alexandre
 */
public enum FormaDePagamento {
    
    EM_DINHEIRO, EM_CHEQUE, CARTAO_DEBITO, CARTAO_CREDITO, OUTROS
    
}
