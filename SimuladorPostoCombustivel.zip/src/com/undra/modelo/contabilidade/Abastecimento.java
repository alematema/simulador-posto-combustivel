package com.undra.modelo.contabilidade;

import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.recursoshumanos.Funcionario;
import java.util.Date;

/**
 * O modelo de um abastecimento.
 * @author alexandre
 */
public class Abastecimento {
    
    private Combustivel combustivel;
    private float quantidade;
    private float valorAbastecimento;
    private Date date;
    private Date quandoFinalizado;
    private BombaCombustivel bombaCombustivel;
    private Funcionario frentista;
    private String estadoDaBomba;

    public Abastecimento(Funcionario frentista,Combustivel combustivel, float quantidade, float valorAbastecimento, Date date, Date quandoFinalizado,BombaCombustivel bombaCombustivel, String estadoDaBomba) {
        this(combustivel,quantidade, valorAbastecimento, date, quandoFinalizado, bombaCombustivel, estadoDaBomba);
        if(frentista==null) throw new NullPointerException("O frentista do abastecimento não pode ser null");
        this.frentista=frentista;
    }
    
    public Abastecimento(Combustivel combustivel, float quantidade, float valorAbastecimento, Date date, Date quandoFinalizado, BombaCombustivel bombaCombustivel, String estadoDaBomba) {
        if(combustivel==null) throw new IllegalArgumentException("O combustivel do abastecimento não pode ser null");
        if(quantidade<=0)throw new IllegalArgumentException("A quantidade de "+ combustivel.getNome()+" no abastecimento deve ser maior do que zero!!!");
        if(valorAbastecimento<combustivel.getPrecoDaUnidade()*quantidade)throw new IllegalArgumentException("O valor do abastecimento deve ser maior ou igual do que "+ combustivel.getPrecoDaUnidade()*quantidade);
        if(bombaCombustivel==null)throw new NullPointerException("A bomba de combustivel do abastecimento não pode ser null");
        if(date==null)throw new IllegalArgumentException("A data do abastecimento não pode ser null");
        if(quandoFinalizado==null)throw new IllegalArgumentException("A data de quando terminou o abastecimento não pode ser null");
        this.combustivel = combustivel;
        this.quantidade = quantidade;
        this.valorAbastecimento = valorAbastecimento;
        this.date = date;
        this.quandoFinalizado = quandoFinalizado;
        this.bombaCombustivel = bombaCombustivel;
        this.estadoDaBomba = estadoDaBomba;
    }

    
    public Combustivel getCombustivel() {
        return combustivel;
    }

    public float getQuantidade() {
        return quantidade;
    }

    public float getValorAbastecimento() {
        return valorAbastecimento;
    }

    public Date getHorarioInicio() {
        return date;
    }

    public BombaCombustivel getBombaCombustivel() {
        return bombaCombustivel;
    }

    public Funcionario getFrentista() {
        return frentista;
    }

    public Date getQuandoFinalizado() {
        return quandoFinalizado;
    }

    public void setQuandoFinalizado(Date quandoFinalizado) {
        this.quandoFinalizado = quandoFinalizado;
    }

    public String getEstadoDaBomba() {
        return estadoDaBomba;
    }

    public void setEstadoDaBomba(String estadoDaBomba) {
        this.estadoDaBomba = estadoDaBomba;
    }
    
    public boolean isGNV(){
        return bombaCombustivel.isGNV();
    }
    
    public boolean isEtanol() {
        return bombaCombustivel.isEtanol();
    }
    
        public boolean isGasolina() {
       return bombaCombustivel.isGasolina();
    }
    
    public boolean isDiesel() {
        return bombaCombustivel.isDiesel();
    }
    
    public boolean ficouSemCombustivelEnquantoAbastecia(){
        return estadoDaBomba.equals(BombaCombustivel.SEM_COMBUSTIVEL);
    }
    public boolean bombaDesligadaEnquantoAbastecia(){
        return estadoDaBomba.equals(BombaCombustivel.DESLIGADA_ENQUANTO_ABASTECIA);
    }
    public boolean bombaAbasteceuEmNivelCritico(){
        return estadoDaBomba.equals(BombaCombustivel.ABASTECENDO_EM_NIVEL_CRITICO);
    }
    
    
    @Override
    public String toString() {
        return "Abastecimento{" + "combustivel=" + combustivel.getNome() + ", quantidade=" + quantidade +""+combustivel.getNomeDaUnidadeSI(quantidade)+ ", valorAbastecimento= "+Combustivel.UNIDADE_MONETÁRIA + valorAbastecimento + ", date=" + date + ", " + bombaCombustivel.toStringShorter()+ '}';
    }
    
    public String toStringShort(){
        return "[ABASTECIMENTO" + ", " + getCombustivel().toStringShort() +", "+getValorAbastecimento()+", "+getQuantidade()+","+ frentista.toStringShort() +"]";
    }



}
