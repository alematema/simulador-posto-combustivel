/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.undra.modelo.contabilidade;

import com.undra.modelo.contabilidade.exception.PagamentoException;
import com.undra.modelo.recursoshumanos.Funcionario;
import java.util.Date;

/**
 *Classe que modela um pagamento de um abastecimento.
 * @author alexandre
 */
public class Pagamento {
    
    
    private Integer id;
    private FormaDePagamento formaPagamento;
    private Date hora;
    private float valor;
    private Abastecimento abastecimento;
    private Funcionario funcionario;

    public Pagamento(FormaDePagamento formaPagamento, Abastecimento abastecimento) {
        
        if(abastecimento==null)throw new NullPointerException("O abastecimento não pode ser null !!!");
        if(abastecimento.getFrentista()==null)throw new NullPointerException("O frentista do abastecimento "+ " não pode ser null !!!");
        if(abastecimento.getValorAbastecimento()<=0f)throw new IllegalArgumentException("O valor do pagamento deve ser maior do que zero !!!");
        this.formaPagamento = formaPagamento;
        this.hora = new Date();
        this.valor = abastecimento.getValorAbastecimento();
        this.abastecimento = abastecimento;
        this.funcionario = abastecimento.getFrentista();
    }
    
    
    public Pagamento(FormaDePagamento formaPagamento, float valor, Abastecimento abastecimento, Funcionario funcionario) throws PagamentoException {
        
        if(abastecimento==null)throw new PagamentoException("O abastecimento não pode ser null !!!");
        if(funcionario==null)throw new PagamentoException("O funcionário não pode ser null !!!");
        if(valor<=0f)throw new PagamentoException("O valor do pagamento deve ser maior do que zero !!!");
        this.formaPagamento = formaPagamento;
        this.hora = new Date();
        this.valor = valor;
        this.abastecimento = abastecimento;
        this.funcionario = funcionario;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public FormaDePagamento getFormaPagamento() {
        return formaPagamento;
    }

    public Date getHora() {
        return hora;
    }

    public float getValor() {
        return valor;
    }

    public Abastecimento getAbastecimento() {
        return abastecimento;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    @Override
    public String toString() {
        return "Pagamento{" + "id=" + id + ", formaPagamento=" + formaPagamento + ", hora=" + hora + ", valor=" + valor + ", abastecimento=" + abastecimento.toStringShort() + ", funcionario=" + funcionario.toStringShort() + '}';
    }

    boolean isDinheiro() {
        return this.formaPagamento.equals(FormaDePagamento.EM_DINHEIRO);
    }

    boolean isCheque() {
         return this.formaPagamento.equals(FormaDePagamento.EM_CHEQUE);
    }

    boolean isCartaoDebito() {
       return this.formaPagamento.equals(FormaDePagamento.CARTAO_DEBITO);
    }

    boolean isCartaoCredito() {
        return this.formaPagamento.equals(FormaDePagamento.CARTAO_CREDITO);
    }

    boolean isOutros() {
        return this.formaPagamento.equals(FormaDePagamento.OUTROS);
    }
    
    
    
    
}
