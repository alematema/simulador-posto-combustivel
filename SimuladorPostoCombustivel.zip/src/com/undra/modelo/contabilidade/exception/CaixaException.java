/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.undra.modelo.contabilidade.exception;

/**
 *
 * @author alexandre
 */
public class CaixaException extends Exception {

    public CaixaException(String msg) {
        super(msg);
    }

}
