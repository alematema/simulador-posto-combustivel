package com.undra.modelo.recursoshumanos;

/**
 *
 * @author alexandre
 */
public enum TipoFuncioinario {
    
    FRENTISTA,CAIXA,ZELADOR
    
}
