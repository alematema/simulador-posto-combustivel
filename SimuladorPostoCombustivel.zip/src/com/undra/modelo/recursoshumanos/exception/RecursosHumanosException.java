/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.undra.modelo.recursoshumanos.exception;

/**
 *
 * @author alexandre
 */
public class RecursosHumanosException extends Exception {

    public RecursosHumanosException(String msg) {
        super(msg);
    }

}
