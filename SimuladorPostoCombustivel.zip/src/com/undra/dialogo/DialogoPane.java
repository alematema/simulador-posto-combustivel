package com.undra.dialogo;

import com.undra.delegator.UIDelegator;
import java.awt.Point;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JCheckBox;

/**
 *
 * @author alexandre
 */
public class DialogoPane {

    static {
        //informacaoWindow = new DialogoWindowUI()
    }

    static private DialogoWindowUI informacaoWindow;
    static private DialogoWindowUI informacaoAdvertenciaWindow;
    static private DialogoWindowUI informacaoErroWindow;
    static private DialogoWindowUI confirmacaoWindow;
    static private DialogoWindowUI confirmacaoOutraWindow;

    static volatile public List<DialogoWindowUI> dialogosAbertos = new ArrayList();

    static public void showDialogoInformacao(String tituloDialogo, String mensagem) {

        informacaoWindow = new DialogoWindowUI(tituloDialogo, mensagem, Dialogo.INFORMACAO);
        informacaoWindow.raise();
        while (informacaoWindow.isRaised()) {
        }

    }

    static public void showDialogoAdvertencia(String tituloDialogo, String mensagem) {

        informacaoAdvertenciaWindow = new DialogoWindowUI(tituloDialogo, mensagem, Dialogo.INFORMACAO_ADVERTENCIA);
        informacaoAdvertenciaWindow.raise();
        while (informacaoAdvertenciaWindow.isRaised()) {
        }

    }

    static public void showDialogoErro(String tituloDialogo, String mensagem) {

        informacaoErroWindow = new DialogoWindowUI(tituloDialogo, mensagem, Dialogo.INFORMACAO_ERRO);
        informacaoErroWindow.raise();
        while (informacaoErroWindow.isRaised()) {
        }

    }

    static public int showDialogoConfirmacao(String tituloDialogo, String mensagem) {

        confirmacaoWindow = new DialogoWindowUI(tituloDialogo, mensagem, Dialogo.CONFIRMACAO);
        confirmacaoWindow.raise();
        while (!confirmacaoWindow.getDialogo().respondido) {
        }

        return confirmacaoWindow.getDialogo().resposta;

    }

    static public int showDialogoConfirmacao(String tituloDialogo, String mensagem, UIDelegator uIDelegator) {

        confirmacaoWindow = new DialogoWindowUI(tituloDialogo, mensagem, Dialogo.CONFIRMACAO, uIDelegator);
        confirmacaoWindow.raise();
        while (!confirmacaoWindow.getDialogo().respondido) {
        }

        return confirmacaoWindow.getDialogo().resposta;

    }

    static public int showDialogoConfirmacao(String tituloDialogo, String mensagem, UIDelegator uIDelegator, ActionListener okButtonListener, ActionListener cancelarButtonListener) {

        confirmacaoWindow = new DialogoWindowUI(tituloDialogo, mensagem, Dialogo.CONFIRMACAO, uIDelegator);
        confirmacaoWindow.getDialogo().setActionListenerOk(okButtonListener);
        confirmacaoWindow.getDialogo().setActionListenerCancelar(cancelarButtonListener);
        confirmacaoWindow.raise();
        while (!confirmacaoWindow.getDialogo().respondido) {
        }

        return confirmacaoWindow.getDialogo().resposta;

    }

    static public int showDialogoConfirmarOutras(String tituloDialogo, String mensagem) {

        confirmacaoOutraWindow = new DialogoWindowUI(tituloDialogo, mensagem, Dialogo.CONFIRMACAO_OUTRA);
        confirmacaoOutraWindow.raise();
        while (!confirmacaoOutraWindow.getDialogo().respondido) {
        }

        return confirmacaoOutraWindow.getDialogo().resposta;

    }

    static public int showDialogoConfirmarOutras(String tituloDialogo, String mensagem, String nomeOutraAcao, Runnable runnable) {

        confirmacaoOutraWindow = new DialogoWindowUI(tituloDialogo, mensagem, Dialogo.CONFIRMACAO_OUTRA, nomeOutraAcao, null);
        confirmacaoOutraWindow.raise();
        while (!confirmacaoOutraWindow.getDialogo().respondido) {
        }

        return confirmacaoOutraWindow.getDialogo().resposta;

    }

    static public int showDialogoConfirmarOutras(String tituloDialogo, String mensagem, String nomeOutraAcao, Runnable runnable, JCheckBox naoMostrarEsseDialogoDeNovoCheckBox , Point location) {

        confirmacaoOutraWindow = new DialogoWindowUI(tituloDialogo, mensagem, Dialogo.CONFIRMACAO_OUTRA, nomeOutraAcao, runnable, naoMostrarEsseDialogoDeNovoCheckBox, location);

        dialogosAbertos.add(confirmacaoOutraWindow);

//        listarDialogosAbertos();

        confirmacaoOutraWindow.raise();

        while (!confirmacaoOutraWindow.getDialogo().respondido) {
        }

        dialogosAbertos.remove(confirmacaoOutraWindow);
        
//        listarDialogosAbertos();

        return confirmacaoOutraWindow.getDialogo().resposta;

    }

    static public int showDialogoConfirmarOutras(String tituloDialogo, String mensagem, UIDelegator uIDelegator) {

        confirmacaoOutraWindow = new DialogoWindowUI(tituloDialogo, mensagem, Dialogo.CONFIRMACAO_OUTRA, uIDelegator);
        confirmacaoOutraWindow.raise();
        while (!confirmacaoOutraWindow.getDialogo().respondido) {
        }

        return confirmacaoOutraWindow.getDialogo().resposta;

    }

    static public int showDialogoConfirmacaoOutras(String tituloDialogo, String mensagem, UIDelegator uIDelegator, ActionListener okButtonListener, ActionListener cancelarButtonListener) {

        confirmacaoOutraWindow = new DialogoWindowUI(tituloDialogo, mensagem, Dialogo.CONFIRMACAO_OUTRA);
        confirmacaoOutraWindow.getDialogo().setActionListenerOk(okButtonListener);
        confirmacaoOutraWindow.getDialogo().setActionListenerCancelar(cancelarButtonListener);
        confirmacaoOutraWindow.raise();
        while (!confirmacaoOutraWindow.getDialogo().respondido) {
        }

        return confirmacaoOutraWindow.getDialogo().resposta;

    }

    static public int showDialogoConfirmacaoOutras(String tituloDialogo, String mensagem, UIDelegator uIDelegator, ActionListener okButtonListener, ActionListener cancelarButtonListener, ActionListener outrasActionListener) {

        confirmacaoOutraWindow = new DialogoWindowUI(tituloDialogo, mensagem, Dialogo.CONFIRMACAO_OUTRA);
        confirmacaoOutraWindow.getDialogo().setActionListenerOk(okButtonListener);
        confirmacaoOutraWindow.getDialogo().setActionListenerCancelar(cancelarButtonListener);
        confirmacaoOutraWindow.getDialogo().setActionListenerOutraAcao(outrasActionListener);
        confirmacaoOutraWindow.raise();
        while (!confirmacaoOutraWindow.getDialogo().respondido) {
        }

        return confirmacaoOutraWindow.getDialogo().resposta;

    }

    public static List<DialogoWindowUI> getTodosDialogosDesteCombustivel(String nome) {

        List<DialogoWindowUI> dialogos = new ArrayList();

        dialogosAbertos.stream().filter((dialogo) -> (dialogo.getNaoMostrarEsseDialogoDeNovoCheckBox().getName().equals(nome))).forEachOrdered((dialogo) -> {
            dialogos.add(dialogo);
        });

        return dialogos;
    }

    private static void listarDialogosAbertos() {
        
        System.err.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> dialogos abertos ");
        
        
        
        for(DialogoWindowUI dialogo : dialogosAbertos){
            
            System.err.println("\tdialogo aberto " + dialogo.toString());
            
        }
        
        if(dialogosAbertos.isEmpty())System.err.println("\tNENHUM ");
        
         System.err.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< dialogos abertos ");
        
    }

    public static void main(String[] args) {

        new Thread(() -> {

        }).start();
        new Thread(() -> {

        }).start();
        new Thread(() -> {

        }).start();
        new Thread(() -> {

        }).start();
        new Thread(() -> {

        }).start();
        DialogoPane.showDialogoAdvertencia("Advertencia 1,2,3, ...", "Hoje é um dia lindo\nAmanhã um outro dia que lindo");
        DialogoPane.showDialogoInformacao(" Informacao, ...", "Hoje não está muito frio\nMas talves amanha esquente\nlSó Deus sabe rs");
        DialogoPane.showDialogoErro(" Erro, ...", "Hoje não está muito frio\nMas talves amanha esquente\nlSó Deus sabe rs");
//        DialogoPane.showDialogoConfirmacao("Confirmar Sol quente ", "Hoje não está muito frio\nMas talves amanha esquente\nlSó Deus sabe rs");
//        DialogoPane.showDialogoConfirmarOutras("Confirmar Sol quente ", "Hoje não está muito frio\nMas talves amanha esquente\nlSó Deus sabe rs\nMas talves amanha esquente", "outraAcao", () -> {
//            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//        }, new JCheckBox());
    }

}
