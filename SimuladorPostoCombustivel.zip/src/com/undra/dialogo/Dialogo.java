package com.undra.dialogo;

import com.undra.view.interfaces.FadableAndRaisableUI;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 * Diálogo iterfacear com usuario.
 *
 * @author alexandre
 */
public class Dialogo extends JPanel {

    static public String INFORMACAO = "INFORMACAO";
    static public String INFORMACAO_ADVERTENCIA = "INFORMACAO_ADVERTENCIA";
    static public String INFORMACAO_ERRO = "INFORMACAO_ERRO";
    static public String CONFIRMACAO = "CONFIRMACAO";
    static public String CONFIRMACAO_OUTRA = "CONFIRMACAO_OUTRA";
    static public int SIM = 1;
    static public int NAO = 0;
    static public int OUTRA_ACAO = -1;

    volatile public boolean respondido = false;
    volatile public int resposta;

    private final ImageIcon informacaoIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/information.png"));
    private final ImageIcon informacaoAdvertenciaIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/warningForDialog.png"));
    private final ImageIcon informacaoErroIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/error.png"));
    private final ImageIcon confirmacaoIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/question.png"));
    private final ImageIcon outroIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/question.png"));

    private ActionListener actionListenerOk;
    private ActionListener actionListenerCancelar;
    private ActionListener actionListenerOutraAcao;

    private JButton okButton;
    private JButton cancelarButton;
    private JButton outraAcaoButton;
    private String nomeAcao;
    private Runnable runnable;
    private final Font buttonsFont = new Font("Ubuntu", Font.BOLD, 13);

    public JTextArea mensagem;
    private String msg;
    private String opcao;
    private JLabel dialogoIconJLabel;

    private JCheckBox naoMostrarEsseDialogoDeNovoCheckBox;
    private JLabel naoMostrarEsseDialogoNovamenteJLabel;
    private final String naoMostrarDialogoDeNovo = "não mostrar mais este diálogo";

    private Dimension dimension;

    private int SMALLEST_WIDTH;
    private int SMALLEST_HEIGHT;
    private int MEDIUM_WIDTH;
    private int MEDIUM_HEIGHT;
    private int BIG_WIDTH;
    private int BIG_HEIGHT;

    private Color backGroundColor = Color.WHITE;

    private FadableAndRaisableUI window;

    public Dialogo(String mensagem, String opcao, FadableAndRaisableUI window) {

        if (opcao == null) {
            throw new NullPointerException("A opção não pode ser NUll");
        }

        if (!opcao.equals(INFORMACAO) && !opcao.equals(INFORMACAO_ADVERTENCIA) && !opcao.equals(INFORMACAO_ERRO) && !opcao.equals(CONFIRMACAO) && !opcao.equals(CONFIRMACAO_OUTRA)) {
            throw new IllegalArgumentException("Passe uma opcao válida. Opção passada = " + opcao);
        }

        this.opcao = opcao;
        this.msg = mensagem;
        this.window = window;

        configure();

    }

    public Dialogo(String mensagem, String opcao, FadableAndRaisableUI window, JButton okButton, JButton cancelarButton, JButton outraAcaoButton) {

        if (opcao == null) {
            throw new NullPointerException("A opção não pode ser NUll");
        }

        if (!opcao.equals(INFORMACAO) && !opcao.equals(INFORMACAO_ADVERTENCIA) && !opcao.equals(INFORMACAO_ERRO) && !opcao.equals(CONFIRMACAO) && !opcao.equals(CONFIRMACAO_OUTRA)) {
            throw new IllegalArgumentException("Passe uma opcao válida. Opção passada = " + opcao);
        }

        this.opcao = opcao;
        this.msg = mensagem;
        this.window = window;
        this.okButton = okButton;
        this.cancelarButton = cancelarButton;
        this.outraAcaoButton = outraAcaoButton;

        configure();

    }

    public Dialogo(String mensagem, String opcao, FadableAndRaisableUI window, String nomeAcao, Runnable runnable) {

        if (opcao == null) {
            throw new NullPointerException("A opção não pode ser NUll");
        }

        if (!opcao.equals(INFORMACAO) && !opcao.equals(INFORMACAO_ADVERTENCIA) && !opcao.equals(INFORMACAO_ERRO) && !opcao.equals(CONFIRMACAO) && !opcao.equals(CONFIRMACAO_OUTRA)) {
            throw new IllegalArgumentException("Passe uma opcao válida. Opção passada = " + opcao);
        }

        this.opcao = opcao;
        this.msg = mensagem;
        this.window = window;
        this.nomeAcao = nomeAcao;
        this.runnable = runnable;

        configure();

    }

    
    public Dialogo(String mensagem, String opcao, FadableAndRaisableUI window, String nomeAcao, Runnable runnable, JCheckBox naoMostrarEsseDialogoDeNovoCheckBox) {

        if (opcao == null) {
            throw new NullPointerException("A opção não pode ser NUll");
        }

        if (!opcao.equals(INFORMACAO) && !opcao.equals(INFORMACAO_ADVERTENCIA) && !opcao.equals(INFORMACAO_ERRO) && !opcao.equals(CONFIRMACAO) && !opcao.equals(CONFIRMACAO_OUTRA)) {
            throw new IllegalArgumentException("Passe uma opcao válida. Opção passada = " + opcao);
        }

        this.opcao = opcao;
        this.msg = mensagem;
        this.window = window;
        this.nomeAcao = nomeAcao;
        this.runnable = runnable;
        this.naoMostrarEsseDialogoDeNovoCheckBox = naoMostrarEsseDialogoDeNovoCheckBox;

        configure();

    }

    private void configure() {

        setLayout(new GridBagLayout());

        setBackground(backGroundColor);

        //este código auxiliará outro código fazer ajustes na dimensao do dialogo automaticamente
        String[] msgSplit = msg.split("\n");
        int max_length = Integer.MIN_VALUE;
        for (String s : msgSplit) {
            if (s.length() > max_length) {
                max_length = s.length();
            }
        }

        SMALLEST_WIDTH = 200;
        for (int i = 15; i < max_length; i += 5) {// para cada 5 caracteres acima de uma linha com 15 caracteres, aumenta se 30 no WIDTH
            SMALLEST_WIDTH += 30;
        }

        SMALLEST_HEIGHT = 130;
        if (naoMostrarEsseDialogoDeNovoCheckBox != null) {
            SMALLEST_HEIGHT = 170;
        }
        for (int i = 3; i < msgSplit.length; i++) {// para cada linha da mensagem , aumenta se 15 no HEIGHT
            SMALLEST_HEIGHT += 15;
        }

        MEDIUM_WIDTH = 235;
        for (int i = 15; i < max_length; i += 5) {// para cada 5 caracteres acima de uma linha com 15 caracteres, aumenta se 30 no WIDTH
            MEDIUM_WIDTH += 30;
        }

        MEDIUM_HEIGHT = 130;
        if (naoMostrarEsseDialogoDeNovoCheckBox != null) {
            MEDIUM_HEIGHT = 170;
        }
        for (int i = 3; i < msgSplit.length; i++) {// para cada linha da mensagem , aumenta se 15 no HEIGHT
            MEDIUM_HEIGHT += 15;
        }

        BIG_WIDTH = 250;
        for (int i = 15; i < max_length; i += 5) {// para cada 5 caracteres acima de uma linha com 15 caracteres, aumenta se 30 no WIDTH
            BIG_WIDTH += 30;
        }

        BIG_HEIGHT = 140;
        if (naoMostrarEsseDialogoDeNovoCheckBox != null) {
            BIG_HEIGHT = 180;
        }
        for (int i = 3; i < msgSplit.length; i++) {// para cada linha da mensagem , aumenta se 15 no HEIGHT
            BIG_HEIGHT += 15;
        }

        int dialog_icon_label_height_fraction = 2;

        int rows = 3;
        int columns = 0;

        dialogoIconJLabel = new JLabel();
        ImageIcon icon;

        if (okButton == null) {

            okButton = new JButton("OK");

            actionListenerOk = (ActionEvent e) -> {
                System.err.println("OK");
                resposta = Dialogo.SIM;
                respondido = true;
                window.fade();

            };
            okButton.addActionListener(actionListenerOk);
        }
        okButton.setPreferredSize(new Dimension(okButton.getPreferredSize().width + 5, 8 * okButton.getPreferredSize().height / 10));
        okButton.setFont(buttonsFont);

        if (cancelarButton == null) {
            cancelarButton = new JButton("NÃO");
            actionListenerCancelar = (ActionEvent e) -> {
                System.err.println("NAO");
                resposta = Dialogo.NAO;
                respondido = true;
                window.fade();
            };
            cancelarButton.addActionListener(actionListenerCancelar);
        }
        cancelarButton.setPreferredSize(new Dimension(cancelarButton.getPreferredSize().width + 5, 8 * cancelarButton.getPreferredSize().height / 10));
        cancelarButton.setFont(buttonsFont);

        if (outraAcaoButton == null) {
            if (nomeAcao == null) {
                nomeAcao = "placeHolder?";
            }
            outraAcaoButton = new JButton(nomeAcao);
            actionListenerOutraAcao = (ActionEvent e) -> {
                System.err.println("OUTRA ACAO");
                if (runnable != null) {
                    new Thread(runnable).start();
                }
                resposta = OUTRA_ACAO;
                respondido = true;
                window.fade();
            };
            outraAcaoButton.addActionListener(actionListenerOutraAcao);
        }
        outraAcaoButton.setPreferredSize(new Dimension(outraAcaoButton.getPreferredSize().width + 5, 8 * outraAcaoButton.getPreferredSize().height / 10));
        outraAcaoButton.setFont(buttonsFont);

        if (opcao.equals(INFORMACAO)) {

            dimension = new Dimension(SMALLEST_WIDTH, SMALLEST_HEIGHT);

            dialogoIconJLabel.setPreferredSize(new Dimension(dimension.height / dialog_icon_label_height_fraction, dimension.height / dialog_icon_label_height_fraction));

            icon = new ImageIcon(informacaoIcon.getImage().getScaledInstance(dialogoIconJLabel.getPreferredSize().width, dialogoIconJLabel.getPreferredSize().height, Image.SCALE_REPLICATE));

        } else if (opcao.equals(INFORMACAO_ADVERTENCIA)) {

            dimension = new Dimension(SMALLEST_WIDTH, SMALLEST_HEIGHT);

            dialogoIconJLabel.setPreferredSize(new Dimension(dimension.height / dialog_icon_label_height_fraction, dimension.height / dialog_icon_label_height_fraction));

            icon = new ImageIcon(informacaoAdvertenciaIcon.getImage().getScaledInstance(dialogoIconJLabel.getPreferredSize().width, dialogoIconJLabel.getPreferredSize().height, Image.SCALE_REPLICATE));

        } else if (opcao.equals(INFORMACAO_ERRO)) {

            dimension = new Dimension(SMALLEST_WIDTH, SMALLEST_HEIGHT);

            dialogoIconJLabel.setPreferredSize(new Dimension(dimension.height / dialog_icon_label_height_fraction, dimension.height / dialog_icon_label_height_fraction));

            icon = new ImageIcon(informacaoErroIcon.getImage().getScaledInstance(dialogoIconJLabel.getPreferredSize().width, dialogoIconJLabel.getPreferredSize().height, Image.SCALE_REPLICATE));

        } else if (opcao.equals(CONFIRMACAO)) {

            dimension = new Dimension(MEDIUM_WIDTH, MEDIUM_HEIGHT);

            dialogoIconJLabel.setPreferredSize(new Dimension(dimension.height / dialog_icon_label_height_fraction + 1, dimension.height / dialog_icon_label_height_fraction + 1));

            icon = new ImageIcon(confirmacaoIcon.getImage().getScaledInstance(dialogoIconJLabel.getPreferredSize().width, dialogoIconJLabel.getPreferredSize().height, Image.SCALE_REPLICATE));

        } else {

            dimension = new Dimension(BIG_WIDTH, BIG_HEIGHT);

            dialogoIconJLabel.setPreferredSize(new Dimension(dimension.height / dialog_icon_label_height_fraction + 1, dimension.height / dialog_icon_label_height_fraction + 1));

            icon = new ImageIcon(outroIcon.getImage().getScaledInstance(dialogoIconJLabel.getPreferredSize().width, dialogoIconJLabel.getPreferredSize().height, Image.SCALE_REPLICATE));

        }

        setPreferredSize(dimension);
        dialogoIconJLabel.setIcon(icon);

        GridBagConstraints gridConstraints;
        gridConstraints = new GridBagConstraints();

        JPanel dialogoIconEMensagemPanel = new JPanel();
        dialogoIconEMensagemPanel.setBackground(backGroundColor);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;

        dialogoIconEMensagemPanel.add(dialogoIconJLabel, gridConstraints);

        msg = "\n" + msg;

        this.mensagem = new JTextArea(msg, rows, columns);

        mensagem.setEditable(false);

        mensagem.setBackground(backGroundColor);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;

        dialogoIconEMensagemPanel.add(mensagem, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;

        add(dialogoIconEMensagemPanel, gridConstraints);

        JPanel dialogoFooter = new JPanel(new GridBagLayout());
        dialogoFooter.setBackground(backGroundColor);
        dialogoFooter.setPreferredSize(new Dimension(dimension.width, dimension.height / 4));

        if (opcao.equals(INFORMACAO) || opcao.equals(INFORMACAO_ADVERTENCIA) || opcao.equals(INFORMACAO_ERRO)) {

            gridConstraints.gridx = 0;
            gridConstraints.gridy = 0;

            dialogoFooter.add(okButton, gridConstraints);

        }

        if (opcao.equals(CONFIRMACAO)) {

            gridConstraints.gridx = 0;
            gridConstraints.gridy = 0;

            dialogoFooter.add(okButton, gridConstraints);

            gridConstraints.gridx = 1;
            gridConstraints.gridy = 0;

            dialogoFooter.add(cancelarButton, gridConstraints);
            
            gridConstraints.insets = new Insets(10, 50, 0, 0);

        }

        if (opcao.equals(CONFIRMACAO_OUTRA)) {

            gridConstraints.gridx = 0;
            gridConstraints.gridy = 0;

            dialogoFooter.add(okButton, gridConstraints);

            gridConstraints.gridx = 1;
            gridConstraints.gridy = 0;

            dialogoFooter.add(cancelarButton, gridConstraints);

            gridConstraints.gridx = 2;
            gridConstraints.gridy = 0;

            dialogoFooter.add(outraAcaoButton, gridConstraints);
            
            gridConstraints.insets = new Insets(10, 50, 0, 0);

        }
        
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        
        add(dialogoFooter, gridConstraints);

        JPanel naoMostrarEsseDialogoNovamentePanel;

        if ( naoMostrarEsseDialogoDeNovoCheckBox != null ) {

            naoMostrarEsseDialogoNovamenteJLabel = new JLabel(naoMostrarDialogoDeNovo);
            naoMostrarEsseDialogoNovamenteJLabel.setFont(new Font(buttonsFont.getName(), buttonsFont.getStyle(), buttonsFont.getSize() - 1));
            naoMostrarEsseDialogoNovamentePanel = new JPanel(new GridBagLayout());
            naoMostrarEsseDialogoNovamentePanel.setBackground(backGroundColor);

            gridConstraints.gridx = 0;
            gridConstraints.gridy = 0;
            gridConstraints.anchor = GridBagConstraints.WEST;
            gridConstraints.insets = new Insets(10, 0, 0, 10);
            naoMostrarEsseDialogoNovamentePanel.add(naoMostrarEsseDialogoDeNovoCheckBox, gridConstraints);

            gridConstraints.gridx = 0;
            gridConstraints.gridy = 0;
            gridConstraints.insets = new Insets(10, 20, 0, 10);

            naoMostrarEsseDialogoNovamentePanel.add(naoMostrarEsseDialogoNovamenteJLabel, gridConstraints);

            gridConstraints.gridx = 0;
            gridConstraints.gridy = 2;
            gridConstraints.insets = new Insets(5, 0, 5, 0);

            add(naoMostrarEsseDialogoNovamentePanel, gridConstraints);

        }


    }

    public void setMensagem(String mensagem) {
        this.mensagem.setText(mensagem);
    }

    public JButton getOkButton() {
        return okButton;
    }

    public void setOkButton(JButton okButton) {
        this.okButton = okButton;
    }

    public JButton getCancelarButton() {
        return cancelarButton;
    }

    public void setCancelarButton(JButton cancelarButton) {
        this.cancelarButton = cancelarButton;
    }

    public JButton getOutraAcaoButton() {
        return outraAcaoButton;
    }

    public void setOutraAcaoButton(JButton outraAcaoButton) {
        this.outraAcaoButton = outraAcaoButton;
    }

    public void setActionListenerOk(ActionListener actionListenerOk) {

        try {

            okButton.removeActionListener(this.actionListenerOk);
            okButton.addActionListener(actionListenerOk);
            this.actionListenerOk = actionListenerOk;

        } catch (Exception e) {
            System.err.println("Algo exceptional ocorreu em Dialogo.setActionListenerOk " + e.getLocalizedMessage());
        }

    }

    public void setActionListenerCancelar(ActionListener actionListenerCancelar) {

        try {

            cancelarButton.removeActionListener(this.actionListenerCancelar);
            cancelarButton.addActionListener(this.actionListenerCancelar);
            this.actionListenerCancelar = actionListenerCancelar;

        } catch (Exception e) {
            System.err.println("Algo exceptional ocorreu em Dialogo.setActionListenerCancelar " + e.getLocalizedMessage());
        }

    }

    public void setActionListenerOutraAcao(ActionListener actionListenerOutraAcao) {

        try {

            outraAcaoButton.removeActionListener(actionListenerOutraAcao);
            outraAcaoButton.addActionListener(actionListenerOutraAcao);
            this.actionListenerOutraAcao = actionListenerOutraAcao;

        } catch (Exception e) {
            System.err.println("Algo exceptional ocorreu em Dialogo.setActionListenerOutraAcao " + e.getLocalizedMessage());
        }

    }

    public Dimension getDimension() {
        return dimension;
    }

    public void setBackGroundColor(Color backGroundColor) {
        this.backGroundColor = backGroundColor;
        setBackground(backGroundColor);
    }
    
    public String getTipo(){
        return opcao;
    }

}
