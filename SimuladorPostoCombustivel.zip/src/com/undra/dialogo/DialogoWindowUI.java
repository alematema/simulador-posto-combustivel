package com.undra.dialogo;

import com.undra.delegator.UIDelegator;
import static com.undra.dialogo.Dialogo.INFORMACAO;
import static com.undra.dialogo.Dialogo.INFORMACAO_ADVERTENCIA;
import static com.undra.dialogo.Dialogo.INFORMACAO_ERRO;
import com.undra.view.interfaces.FadableAndRaisableUI;
import com.undra.view.interfaces.UI;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * Window do Dialogo UI
 *
 * @author alexandre
 */
public class DialogoWindowUI extends JFrame implements FadableAndRaisableUI, UI {

    public static void main(String[] args) {
        DialogoWindowUI window = new DialogoWindowUI(Dialogo.CONFIRMACAO, "Olá\neu vou partir\nmas será amanha\namanha é dia de graças e é bom mesmo", Dialogo.INFORMACAO_ADVERTENCIA);
        window.raise();
        new Thread(() -> {
            try {

                Thread.sleep(2500);
                window.getDialogo().getOutraAcaoButton().setText("iyiyoiyoiyiuyuiyoi".toUpperCase());

            } catch (InterruptedException ex) {
                Logger.getLogger(DialogoWindowUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }).start();

    }

    static private int id_auto_gen = 0;

    private Dialogo dialogo;
    private final String mensagem;
    private final String opcao;
    private final int id;

    private String nomeAcao;
    private Runnable runnable;
    private JCheckBox naoMostrarEsseDialogoDeNovoCheckBox;

    private JPanel windowHeader;
    private JCheckBox onOff;
    private JLabel headerLabel;
    private final Font headerFont = new Font("Ubuntu", Font.BOLD, 14);
    private final ImageIcon offIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/off.24x12.png"));
    private String tituloDaJanela;
    
    private Point location;

    private UIDelegator uIDelegator;

    volatile public boolean raised = false;

    public DialogoWindowUI(String titulo, String mensagem, String opcao) {

        if (mensagem == null) {
            mensagem = "";
        }

        this.mensagem = mensagem;
        this.opcao = opcao;
        this.tituloDaJanela = titulo;

        id_auto_gen++;
        id = id_auto_gen;

        configure();

    }

    public DialogoWindowUI(String titulo, String mensagem, String opcao, String nomeAcao, Runnable runnable) {

        if (mensagem == null) {
            mensagem = "";
        }

        this.mensagem = mensagem;
        this.opcao = opcao;
        this.tituloDaJanela = titulo;
        this.nomeAcao = nomeAcao;
        this.runnable = runnable;

        id_auto_gen++;
        id = id_auto_gen;

        configure();

    }

    public DialogoWindowUI(String titulo, String mensagem, String opcao, String nomeAcao, Runnable runnable, JCheckBox naoMostrarEsseDialogoDeNovoCheckBox, Point location) {

        if (mensagem == null) {
            mensagem = "";
        }

        this.mensagem = mensagem;
        this.opcao = opcao;
        this.tituloDaJanela = titulo;
        this.nomeAcao = nomeAcao;
        this.runnable = runnable;
        this.naoMostrarEsseDialogoDeNovoCheckBox = naoMostrarEsseDialogoDeNovoCheckBox;
        this.location = location;

        id_auto_gen++;
        id = id_auto_gen;

        configure();

    }

    public DialogoWindowUI(String titulo, String mensagem, String opcao, UIDelegator uIDelegator) {

        this(titulo, mensagem, opcao);

        if (uIDelegator == null) {
            throw new NullPointerException("O UIDelegator não pode ser null.");
        }

        this.uIDelegator = uIDelegator;

        registrarNoUIDelegator();

    }

    private void registrarNoUIDelegator() {
        uIDelegator.registrar(this);
    }

    private void configure() {

        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {

            if ("GTK+".equals(info.getName())) {

                try {

                    javax.swing.UIManager.setLookAndFeel(info.getClassName());

                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                    Logger.getLogger(DialogoWindowUI.class.getName()).log(Level.SEVERE, null, ex);
                }

                break;

            }
        }

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }

        });

        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        setResizable(false);

        try {

            setUndecorated(true);

        } catch (Exception e) {
        }

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        setTitle(tituloDaJanela);

        pack();

        setBounds(location.x+35, location.y+88, getWidth(), getHeight());
    }

    public void configureAndShow() {

        configure();

        setVisible(true);

    }

    private void placeComponentsAtFrame() {

        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints();

        dialogo = new Dialogo(mensagem, opcao, this, nomeAcao, runnable, naoMostrarEsseDialogoDeNovoCheckBox);

        getContentPane().setBackground(dialogo.getBackground());

        dialogo.mensagem.setBackground(getBackground());

        windowHeader = new JPanel();
        windowHeader.setPreferredSize(new Dimension(dialogo.getPreferredSize().width + 35, 25));
        windowHeader.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1, true));
        windowHeader.setBackground(Color.WHITE);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.NORTH;
        gridConstraints.insets = new Insets(0, 0, 5, 0);

        add(windowHeader, gridConstraints);

        windowHeader.setLayout(new GridBagLayout());

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;

        onOff = new JCheckBox();
        onOff.setToolTipText("CLIQUE PARA FECHAR");

        onOff.setSelected(false);
        onOff.setIcon(offIcon);
        onOff.setPreferredSize(new Dimension(26, 20));

        gridConstraints.insets = new Insets(5, 0, 5, ((int) windowHeader.getPreferredSize().width) - onOff.getPreferredSize().width);

        onOff.addActionListener(this::onOffButtonActionPerformed);

        windowHeader.add(onOff, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(0, 25, 0, 0);

        headerLabel = new JLabel();
        headerLabel.setForeground(Color.BLACK);
        headerLabel.setFont(headerFont);
        windowHeader.add(headerLabel, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;

        add(dialogo, gridConstraints);

    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }

    @Override
    public void fade() {

        new Thread(() -> {

            for (int i = 100; i > 1; i--) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(DialogoWindowUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            setVisible(false);

            raised = false;

        }).start();
        
    }

    @Override
    public void raise() {

        new Thread(() -> {

            dialogo.respondido = false;

            setAlwaysOnTop(true);
            setOpacity(0.11f);
            setVisible(true);
            float opacity1 = 1.0f;

            for (int i = 0; i < 95; i++) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(DialogoWindowUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            requestFocus();
            raised = true;

        }).start();
    }

    private void onOffButtonActionPerformed(ActionEvent e) {

        try {

            //esses tipos de dialogo só tem botao OK, entao invoca se o doClick do OKbutton
            if (dialogo.getTipo().equals(INFORMACAO) || dialogo.getTipo().equals(INFORMACAO_ADVERTENCIA) || dialogo.getTipo().equals(INFORMACAO_ERRO)) {

                dialogo.getOkButton().doClick();
                
                return;

            }

        } catch (Exception ex) {
            
            System.err.println("Algo excecptional ocorreu em DialogoWindowUI.onOffButtonActionPerformed " + ex.getLocalizedMessage());
            
        }
        
        
         try {

            dialogo.getCancelarButton().doClick();

        } catch (Exception ex) {
            
             System.err.println("Algo excecptional ocorreu em DialogoWindowUI.onOffButtonActionPerformed " + ex.getLocalizedMessage());
            
            //fade o window em ultimo caso
            fade();
            
        }

    }

    @Override
    public void setTitle(String title) {

        try {

            super.setTitle(title);
            headerLabel.setText(title);
            tituloDaJanela = title;

        } catch (Exception e) {
        }

    }

    public boolean isRaised() {
        return raised;
    }

    public Dialogo getDialogo() {
        return dialogo;
    }
    
    
        public JCheckBox getNaoMostrarEsseDialogoDeNovoCheckBox() {
        return naoMostrarEsseDialogoDeNovoCheckBox;
    }

    @Override
    public String toString() {
        
        try {
            return "Dialogo Window UI " + id +" " + naoMostrarEsseDialogoDeNovoCheckBox.getName() ;
        } catch (Exception e) {
            return "Dialogo Window UI " + id ;
        }
        
    }



}
