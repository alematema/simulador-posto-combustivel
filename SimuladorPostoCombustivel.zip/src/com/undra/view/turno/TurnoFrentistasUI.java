package com.undra.view.turno;

import com.undra.modelo.recursoshumanos.Frentista;
import com.undra.view.interfaces.UI;
import java.util.Collection;

/**
 * Interface do Turno de Frentistas
 * @author alexandre
 */
public interface TurnoFrentistasUI extends UI {

    void setFrentistas(Frentista frentista);
    void addFrentista(Frentista frentista);
    void removeFrentista(Frentista frentista);
    String getNome();
    Collection<Frentista> getFrentistasNesteTurno();    
    
    
}
