/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.undra.view.caixa;

import com.undra.view.relatorios.RelatorioCaixaWindow;
import com.undra.delegator.UIDelegator;
import com.undra.modelo.contabilidade.Caixa;

/**
 *
 * @author alexandre
 */
public class TestaCaixaRelatorioWindow {
    
    public static void main(String[] args) {
        
        UIDelegator uIDelegator = new UIDelegator();
        
        Caixa caixa = new Caixa(uIDelegator, 0);
        
        RelatorioCaixaWindow caixaRelatorioWindow = new RelatorioCaixaWindow(new CaixaUI(uIDelegator, caixa));
        
        caixaRelatorioWindow.configureAndShow();
        
    }

}
