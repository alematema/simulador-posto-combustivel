/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.caixa;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;

/**
 * A imagem de um caixa registradora no background de um panel
 *
 * @author alexandre
 */
public class CaixaImagem extends JPanel {

    private final Image imgCaixaLigado = new javax.swing.ImageIcon(getClass().getResource("/imagens/caixa.png")).getImage();
    private final Image imgCaixaDesligado = new javax.swing.ImageIcon(getClass().getResource("/imagens/caixaDesligado.png")).getImage();
    private Image img = imgCaixaLigado;

    volatile private boolean stopPulsing = false; // volatile forces memory barrier crossing
    
    private Dimension dimension = new Dimension(240, 210);

    public CaixaImagem() {
        configure();
    }
    
    
    public CaixaImagem(Dimension dimension) {
        this.dimension = dimension;
        configure();
    }

    private void configure() {
        setPreferredSize(dimension);
    }

    @Override
    public void paintComponent(Graphics g) {
        g.drawImage(img, 3, -5, null);
    }

    private void setImage(Image img) {
        this.img = img;
        repaint();
    }

    public void setAsDesligado() {
        setImage(imgCaixaDesligado);
    }

    public void setAsLigado() {
        setImage(imgCaixaLigado);
    }

    public void pulse() {
        new Thread(() -> {

            while (!stopPulsing) {

                try {

                    if (img == imgCaixaDesligado) {
                        setImage(imgCaixaLigado);
                    } else {
                        setImage(imgCaixaDesligado);
                    }
                    
                    Thread.sleep(1000);
                    
                } catch (InterruptedException ex) {
                    Logger.getLogger(CaixaImagem.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }).start();
    }

    public void stopPulsing() {
        stopPulsing = true;
    }

   

}
