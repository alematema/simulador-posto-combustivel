package com.undra.view.caixa;

import java.awt.Color;
import java.awt.HeadlessException;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author alexandre
 */
public class CaixaConsoleWindow extends JFrame {
    
    public static void main(String[] args) {
        new CaixaConsoleWindow().configureAndShow();
    }

    public CaixaConsoleWindow() throws HeadlessException {
        
    }
    
    
    public void configureAndShow() {

        
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }

        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setTitle(getClass().getSimpleName() + " App");

        getContentPane().setBackground(new Color(255, 255, 192));

        setResizable(false);

//        //sets frame's size to 1/4 screen area
//        setSize(new Dimension(Toolkit.getDefaultToolkit().getScreenSize().width / 2, Toolkit.getDefaultToolkit().getScreenSize().height / 2));

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

        setUndecorated(false);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

       pack();

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

        setVisible(true);

    }

    private void placeComponentsAtFrame() {
        
        
        CaixaConsole console = new CaixaConsole();
        
        
        getContentPane().add(console);
        
        console.append("--------------------------------------------------------------------\n");
        console.append("          PAGAMENTO DO ABASTECIMENTO\n");
        console.append("--------------------------------------------------------------------\n");

        console.append("combustivel : GNV\n");
        console.append("forma pagamento : CARTAO DÉBITO\n");
        console.append("valor do abastecimento : R$78,87\n");
        console.append("quantidade : 65 m3\n");
        console.append("preço do m3 : R$1.87\n");
        console.append("--------------------------------------------------------------------\n");
        console.append("horário do abastecimento :10:23:21\n");
        console.append("horário do pagamento      :10:25:34\n");
        console.append("--------------------------------------------------------------------\n");
        console.append("frentista : MANUEL\n");
        console.append("bomba : BOMBA 2,GNV\n");
        console.append("--------------------------------------------------------------------\n");
        
         new Thread(new Runnable() {
            @Override
            public void run() {
               try {
            Thread.sleep(3000);
        } catch (InterruptedException ex) {
            Logger.getLogger(CaixaConsoleWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
        console.configureComoPostoFechado();
            }
        }).start();;
         
         
        
        
    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }


}
