package com.undra.view.caixa;

import com.undra.view.relatorios.RelatorioCaixaWindow;
import com.undra.delegator.UIDelegator;
import com.undra.modelo.contabilidade.Caixa;
import com.undra.view.interfaces.UI;
import com.undra.app.util.OutPut;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.border.Border;

/**
 * UI do caixa
 *
 * @author alexandre
 */
public class CaixaUI extends JPanel implements UI, OutPut {

    private final String dateFormat = "dd/MM/yyy,HH:mm:ss";//"yyyy-MM-dd HH:mm:ss"
    private final SimpleDateFormat dateFormatter = new SimpleDateFormat(dateFormat);

    private CaixaConsole console;
    private CaixaImagem caixaImagem;

    private final Border postoFechadoBorder = null;
//    private Border postoFechadoBorder = BorderFactory.createLineBorder(Color.BLACK, 4, true);
    private final Border postoAbertoBorder = BorderFactory.createLineBorder(Color.WHITE, 2, true);
    private final Color postoFechadoconsoleBackGround = Color.LIGHT_GRAY;
    private Color postoAbertoconsoleBackGround = new Color(192, 192, 240);
    ;
//    private Color postoAbertoconsoleBackGround = new Color(192, 192, 240);;

    private final Color postoFechadoconsoleForeground = Color.LIGHT_GRAY;
    private final Color postoAbertoconsoleForegound = Color.GREEN;

    public volatile Boolean isAberto = false; // volatile forces memory barrier crossing

    private final UIDelegator uIDelegator;

    private final Caixa modelo;

    private RelatorioCaixaWindow caixaRelatorioWindow;

    private boolean luzAcesa = false;

    public CaixaUI(UIDelegator uIDelegator, Caixa modelo) {

        if (uIDelegator == null) {
            throw new NullPointerException("O UIDelegator não pode ser null !!!");
        }
        if (modelo == null) {
            throw new NullPointerException("O modelo (caixa) não pode ser null !!!");
        }

        this.uIDelegator = uIDelegator;
        this.modelo = modelo;

        configure();
    }

    public CaixaUI() {
        this.uIDelegator = null;
        this.modelo = null;
        configure();
    }

    private void configure() {

        if (uIDelegator != null) {
            uIDelegator.registrarUI(this);
        }

        setLayout(new GridBagLayout());

        GridBagConstraints gridConstraints = new GridBagConstraints();

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.NORTH;

        if (uIDelegator != null) {
            console = new CaixaConsole();
            gridConstraints.insets = new Insets(0, 0, 200, 0);
        } else {
            console = new CaixaConsole(new Dimension(555, 350), new Font("Ubuntu", Font.BOLD, 15));
            gridConstraints.insets = new Insets(0, 0, 245, 0);

        }

        add(console, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        if (uIDelegator != null) {
            gridConstraints.insets = new Insets(230, 0, 0, 0);
        } else {
            gridConstraints.insets = new Insets(350, 0, 0, 0);
        }

        caixaImagem = new CaixaImagem();
        add(caixaImagem, gridConstraints);

        if (uIDelegator != null) {

            caixaImagem.setToolTipText("CLIQUE PARA MOSTRAR OU ESCONDER RELATÓRIO DESTE CAIXA");

            caixaImagem.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {

                    if (caixaRelatorioWindow != null) {
                        if (caixaRelatorioWindow.isVisible()) {
                            
                            caixaRelatorioWindow.setVisible(false);
                            System.err.println("atualizar caixa console fechando");
                            
                        } else {
                            
                            caixaRelatorioWindow.setVisible(true);
                            System.err.println("atualizar caixa console abrindo");
                            
                        }
                    }

                }

            });
        }

        if (uIDelegator != null) {
            caixaRelatorioWindow = new RelatorioCaixaWindow(this);
            caixaRelatorioWindow.configure();
        }

        if (uIDelegator != null) {
            new Thread(() -> {
                try {
                    fechar();
                } catch (Exception e) {
                    System.err.println("Algo deu errado em CaixaUI.fechar " + e.getLocalizedMessage());
                }

            }).start();
        } else {

            console.clear();

            setBorder(null);
            caixaImagem.setAsDesligado();
            postoAbertoconsoleBackGround = Color.BLACK;
            console.setBorder(postoAbertoBorder);
            setBackground(postoAbertoconsoleBackGround);
            console.setForeground(postoAbertoconsoleForegound);
            console.clear();

            console.setBackground(postoAbertoconsoleBackGround);

            caixaImagem.setAsLigado();
        }

    }

    public void fechar() {

        setIsAberto(false);
        
        getModelo().setLigado(false);

        new Thread(() -> {

            int sleep = 1000;

            try {

                console.clear();

                if (uIDelegator != null) {

                    try {
                        caixaRelatorioWindow.getCaixaRelatorioUI().clear();
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().clear();
                    } catch (Exception e) {
                    }

                }

                setBorder(postoFechadoBorder);
                if (luzAcesa) {
                    setBackground(Color.WHITE);
                } else {
                    setBackground(Color.DARK_GRAY);
                }
                console.setBackground(postoFechadoconsoleBackGround);
                console.setForeground(Color.BLACK);
                console.setPostoFechadoBorder(postoFechadoBorder);

                console.append("DESCONECTANDO DO SERVIDOR");
                if (uIDelegator != null) {
                    try {
                        caixaRelatorioWindow.getCaixaRelatorioUI().clear();
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().clear();
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().append("DESCONECTANDO DO SERVIDOR");
                    } catch (Exception e) {
                    }

                }

                Thread.sleep(sleep);
                console.append(".");
                if (uIDelegator != null) {
                    try {
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().append(".");
                    } catch (Exception e) {
                    }

                }
                Thread.sleep(sleep);
                console.append(".");
                if (uIDelegator != null) {
                    try {
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().append(".");
                    } catch (Exception e) {
                    }
                }
                Thread.sleep(sleep);
                console.append(".");
                if (uIDelegator != null) {
                    try {
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().append(".");
                    } catch (Exception e) {
                    }
                }
                Thread.sleep(sleep);

                console.clear();

                console.append("CAIXA FECHADO, ");
                console.append(dateFormatter.format(new Date()));

                if (luzAcesa) {
                    setBackground(Color.WHITE);
                } else {
                    setBackground(Color.DARK_GRAY);
                }

                caixaImagem.setAsDesligado();

                System.out.println("[CAIXA UI] : CAIXA fechado");

                if (uIDelegator != null) {
                    try {
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().setIsAberto(false);
                        caixaRelatorioWindow.getCaixaRelatorioUI().clear();
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().clear();
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().append("CAIXA FECHADO, ");
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().append(dateFormatter.format(new Date()));
                    } catch (Exception e) {
                    }

                }

            } catch (Exception e) {
                System.err.println("Algo deu errado em CaixaUI.fechar " + e.getLocalizedMessage());
            }
        }).start();

    }

    public void abrir() {

        new Thread(() -> {
            
            console.clear();
            
            int sleep = 1000;

            setBorder(null);

            try {

                caixaImagem.setAsDesligado();

                console.setBorder(postoAbertoBorder);
                console.setBackground(postoFechadoconsoleBackGround);
                if (luzAcesa) {
                    setBackground(Color.WHITE);
                } else {
                    setBackground(Color.DARK_GRAY);
                }
                console.setForeground(Color.darkGray);

                console.append("CONECTANDO AO SERVIDOR");
                if (uIDelegator != null) {
                    try {
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().clear();
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().append("CONECTANDO AO SERVIDOR");
                    } catch (Exception e) {
                    }

                }
                Thread.sleep(sleep);
                console.append(".");
                if (uIDelegator != null) {
                    try {
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().append(".");
                    } catch (Exception e) {
                    }

                }
                Thread.sleep(sleep);
                console.append(".");
                if (uIDelegator != null) {
                    try {
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().append(".");
                    } catch (Exception e) {
                    }
                }
                Thread.sleep(sleep);
                console.append(".");
                if (uIDelegator != null) {
                    try {
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().append(".");
                    } catch (Exception e) {
                    }
                }
                Thread.sleep(sleep);
                console.append("(OK)\n");
                if (uIDelegator != null) {
                    try {
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().append("(OK)\n");
                    } catch (Exception e) {
                    }

                }

                Thread.sleep(sleep);

                console.clear();
                
                if (uIDelegator != null) {
                    try {
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().clear();
                    } catch (Exception e) {
                    }

                }

                console.append("CAIXA ABERTO, ");
                console.append(dateFormatter.format(new Date()));

                postoAbertoconsoleBackGround = Color.BLACK;
                console.setBackground(postoAbertoconsoleBackGround);
                console.setForeground(postoAbertoconsoleForegound);

                postoAbertoconsoleBackGround = Color.WHITE;

                if (luzAcesa) {
                    setBackground(Color.WHITE);
                } else {
                    setBackground(Color.DARK_GRAY);
                }

                setIsAberto(true);

                getModelo().setLigado(true);
                
                caixaImagem.setAsLigado();
                

                System.out.println("[CAIXA UI] : CAIXA aberto");

                if (uIDelegator != null) {
                    try {
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().append("CAIXA ABERTO, ");
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().getConsole().append(dateFormatter.format(new Date()));
                        caixaRelatorioWindow.getCaixaRelatorioUI().getRelatorioUI().setIsAberto(true);
                    } catch (Exception e) {
                    }

                }

            } catch (InterruptedException e) {
            }
        }).start();

    }

    public void escreverNoConsole(String msg) {

        if (isAberto) {
            getConsole().append(msg);
            if (uIDelegator != null) {
                getCaixaRelatorioWindow().limparEAtualizar();
            }
        } else {
//             System.err.println("tentando escrever no console mas está fechado ");
        }

    }

    public void limparEEscreverNoConsole(String msg) {

        if (isAberto) {
            getConsole().clear();
            getConsole().append(msg);
            if (uIDelegator != null) {
                getCaixaRelatorioWindow().limparEAtualizar();
            }
        }

    }

    public void limparEAtualizar(String msg) {

        if (isAberto()) {
            getConsole().clear();
        }

    }

    public CaixaConsole getConsole() {
        return console;
    }

    public Caixa getModelo() {
        return modelo;
    }

    public RelatorioCaixaWindow getCaixaRelatorioWindow() {
        return caixaRelatorioWindow;
    }

    public UIDelegator getuIDelegator() {
        return uIDelegator;
    }

    public boolean isAberto() {
        return isAberto;
    }

    public void setIsAberto(Boolean isAberto) {
        this.isAberto = isAberto;

    }

    public boolean isLuzAcesa() {
        return luzAcesa;
    }

    public void setLuzAcesa(boolean luzAcesa) {
        this.luzAcesa = luzAcesa;
    }
    
    @Override
    public float getValue() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setValue(float value) {
      getModelo().setVelocidade((int)value);
    }

    @Override
    public String toString() {
        return "Caixa UI " + getModelo().getId();
    }


    
}
