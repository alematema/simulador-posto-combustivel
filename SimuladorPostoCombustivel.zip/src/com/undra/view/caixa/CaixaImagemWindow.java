/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.caixa;

import java.awt.Color;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author alexandre
 */
public class CaixaImagemWindow extends JFrame {

    public static void main(String[] args) {
        new CaixaImagemWindow().configureAndShow();
    }

    public void configureAndShow() {

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }

        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setTitle(getClass().getSimpleName() + " App");

        getContentPane().setBackground(new Color(255, 255, 192));

        setResizable(false);

        setUndecorated(false);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        pack();

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

        setVisible(true);

    }

    private void placeComponentsAtFrame() {

        CaixaImagem imagem = new CaixaImagem();

        getContentPane().add(imagem);

        new Thread(new Runnable() {
            @Override
            public void run() {

                
                try {
                    imagem.pulse();
                    Thread.sleep(6000);
                    imagem.stopPulsing();
                    return;
                } catch (InterruptedException ex) {
                    Logger.getLogger(CaixaImagemWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                
            }
        }).start();

    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }

}
