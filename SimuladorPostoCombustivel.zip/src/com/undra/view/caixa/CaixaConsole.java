/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.caixa;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.text.SimpleDateFormat;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.Border;

/**
 * View console do caixa
 *
 * @author alexandre
 */
public class CaixaConsole extends JPanel {

    private final String dateFormat = "dd/MM/yyy,HH:mm:ss";//"yyyy-MM-dd HH:mm:ss"
    private final SimpleDateFormat dateFormatter = new SimpleDateFormat(dateFormat);

    private final JTextArea console = new JTextArea();
    private Border postoFechadoBorder = BorderFactory.createLineBorder(Color.WHITE, 2, true);
    private Border postoAbertoBorder = BorderFactory.createLineBorder(Color.BLACK, 4, true);

    private Color postoFechadoconsoleBackGround = Color.GRAY;
    private Color postoFechadoconsoleForeground = Color.DARK_GRAY;
    private Color postoAbertoconsoleForegound = Color.GREEN;
    private Color postoAbertoconsoleBackGround = Color.DARK_GRAY;
    
    private Font consoleFont = new Font("Ubuntu", Font.BOLD, 13);
    private Dimension dim = new Dimension(265, 229);
    
    

    public CaixaConsole() {
        configure();
    }
    
    public CaixaConsole(Dimension dim, Font consoleFont) {
        this.dim = dim;
        this.consoleFont = consoleFont;
        configure();
    }
    

    private void configure() {

        setPreferredSize(dim);

        setBackground(postoAbertoconsoleBackGround);

        setBorder(postoAbertoBorder);

        console.setPreferredSize(new Dimension(dim.width-20, dim.height-9));

        console.setBackground(postoFechadoconsoleBackGround);
        console.setForeground(postoFechadoconsoleBackGround);
        console.setFont(consoleFont);

        console.setEditable(false);
        
        add(console);
    }

    public void clear() {
        console.setText("");
    }

    public void append(String msg) {
        console.append(msg);
    }

    public void setPostoFechadoBorder(Border postoFechadoBorder) {
        this.postoFechadoBorder = postoFechadoBorder;
        setBorder(postoFechadoBorder);
    }

    public void setPostoAbertoBorder(Border postoAbertoBorder) {
        this.postoAbertoBorder = postoAbertoBorder;
    }

    public void setPostoFechadoconsoleBackGround(Color postoFechadoconsoleBackGround) {
        this.postoFechadoconsoleBackGround = postoFechadoconsoleBackGround;
    }

    public void setPostoAbertoconsoleBackGround(Color postoAbertoconsoleBackGround) {
        this.postoAbertoconsoleBackGround = postoAbertoconsoleBackGround;
    }

    public void setPostoFechadoconsoleForeground(Color postoFechadoconsoleForeground) {
        this.postoFechadoconsoleForeground = postoFechadoconsoleForeground;
    }

    public void setPostoAbertoconsoleForegound(Color postoAbertoconsoleForegound) {
        this.postoAbertoconsoleForegound = postoAbertoconsoleForegound;
    }

    public JTextArea getConsole() {
        return console;
    }

    public void configureComoPostoFechado() {

        setBorder(postoFechadoBorder);
        setBackground(postoFechadoconsoleBackGround);
        console.setBackground(postoFechadoconsoleBackGround);
        console.setForeground(postoFechadoconsoleForeground);

    }

    public void configureComoPostoAberto() {

        setBorder(postoAbertoBorder);
        console.setForeground(postoAbertoconsoleForegound);
        setBackground(postoAbertoconsoleBackGround);
        console.setBackground(postoAbertoconsoleBackGround);

    }

    @Override
    public void setBackground(Color bg) {

        try {
            super.setBackground(bg);
            console.setBackground(bg);
        } catch (Exception e) {
        }

    }

    @Override
    public void setForeground(Color fg) {

        try {

            super.setForeground(fg);
            console.setForeground(fg);

        } catch (Exception e) {
        }

    }

}
