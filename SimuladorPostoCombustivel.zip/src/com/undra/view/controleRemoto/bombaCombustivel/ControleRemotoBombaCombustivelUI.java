package com.undra.view.controleRemoto.bombaCombustivel;

import com.undra.delegator.UIDelegator;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.combustivel.bomba.Motor;
import com.undra.modelo.combustivel.reservatorio.Reservatorio;
import com.undra.modelo.contabilidade.Abastecimento;
import com.undra.view.relatorios.RelatorioAbastecimentosDeUmaBombaWindow;
import com.undra.view.interfaces.UI;
import com.undra.view.reservatorio.ReservatorioCombustiveisUI;
import com.undra.view.reservatorio.TanqueCombustivelUI;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.border.Border;
import javax.swing.event.ChangeEvent;

/**
 * UI do controle remoto da bomba combustível.
 *
 * @author alexandre
 */
public class ControleRemotoBombaCombustivelUI extends JPanel implements UI {

    public RelatorioAbastecimentosDeUmaBombaWindow abastecimentosWindow;

    private float totalCombustivelAbastecidoDouble = 0.0f;

    private UIDelegator uIDelegator;

    private BombaCombustivel bombaCombustivel;

    private JPanel controleRemotoBombaHeader;
    private JCheckBox onOff;
    private JLabel headerLabel;
    private final Font headerFont = new Font(Font.SANS_SERIF, Font.BOLD, 11);
    private JLabel wifiLabel;

    private JLabel bombaLigadaAsLabel;
    private JLabel bombaAbastecendo;
    private JLabel quantidadeAbastecimentos;
    private JButton verAbastecimentos;
    private JLabel totalCombustivelAbastecido;
    private JLabel nivelDoReservatorio;
    private JLabel velocidadeAbastecimentoLabel;
    private JSlider velocidadeAbastecimento;
    private JLabel temperaturaMotorJLabel;
    private JLabel resfriarMotorLabel;

    private final String dateFormat = "HH:mm:ss";//"yyyy-MM-dd HH:mm:ss"
    private final SimpleDateFormat dateFormatter = new SimpleDateFormat(dateFormat);

    private final Color backgroundColor = new Color(255, 255, 182);
    public final Color luzAcesaColor = Color.WHITE;
    public final Color luzApagadaColor = Color.BLACK;

    private Font normalFont;
    private Font okFont;
    private Font warningFont;
    private Font badFont;
    private Font ligadaFont;
    private Font desligadaFont;

    private final Border outerBorder = BorderFactory.createLineBorder(Color.BLACK, 5, true);
    private final Dimension dimension = new Dimension(240, 301);

    private final ImageIcon offIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/off.24x12.png"));
    private final ImageIcon onIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/on.png"));
//    private final ImageIcon wifiIconOn = new javax.swing.ImageIcon(getClass().getResource("/imagens/WIFI.gif"));
    private final ImageIcon wifiIconOn = new javax.swing.ImageIcon(getClass().getResource("/imagens/wifi.gif"));
    private final ImageIcon wifiIconOff = new javax.swing.ImageIcon(getClass().getResource("/imagens/wifi.gif"));
    private final ImageIcon downArrowIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/downArrow.png"));
    private final ImageIcon upArrowIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/upArrow.png"));

    private float temperaturaMotor;

    private TanqueCombustivelUI tanqueCombustivelUI = null;

    public ControleRemotoBombaCombustivelUI(BombaCombustivel bombaCombustivel, UIDelegator uIDelegator) {

        if (uIDelegator == null) {
            throw new NullPointerException("A UI delegator não pode ser null !!!");
        }

        if (bombaCombustivel == null) {
            throw new NullPointerException("A bomba de combustível não pode ser null !!!");
        }

        this.bombaCombustivel = bombaCombustivel;
        this.uIDelegator = uIDelegator;

        configure();
    }

    private void configure() {

        this.uIDelegator.registrarUI(this);

        setPreferredSize(dimension);
        setBorder(outerBorder);
        setBackground(backgroundColor);
        setLayout(new GridBagLayout());

        GridBagConstraints gridConstraints;

        controleRemotoBombaHeader = new JPanel();
        controleRemotoBombaHeader.setPreferredSize(new Dimension(230, 22));
        controleRemotoBombaHeader.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1, true));

        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.NORTH;
        gridConstraints.insets = new Insets(0, 0, 20, 0);

        add(controleRemotoBombaHeader, gridConstraints);

        controleRemotoBombaHeader.setLayout(new GridBagLayout());

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.EAST;
        gridConstraints.insets = new Insets(0, 0, 0, 190);

        onOff = new JCheckBox();

        onOff.setSelected(false);
        onOff.setIcon(offIcon);
        onOff.setToolTipText("LIGAR A BOMBA");
        onOff.setName(BombaCombustivel.DESLIGADA);
        onOff.setPreferredSize(new Dimension(26, 20));

        onOff.addActionListener(this::onOffButtonActionPerformed);

        controleRemotoBombaHeader.add(onOff, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(0, 0, 0, 60);
        headerLabel = new JLabel("BOMBA" + " " + bombaCombustivel.getId() + ", " + bombaCombustivel.getCombustivel().getNome());
        headerLabel.setFont(headerFont);
        controleRemotoBombaHeader.add(headerLabel, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(0, 210, 0, 0);
        wifiLabel = new JLabel();
        wifiLabel.setIcon(wifiIconOff);
        wifiLabel.setPreferredSize(new Dimension(18, 18));
        controleRemotoBombaHeader.add(wifiLabel, gridConstraints);

        setOnOff();

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(0, 5, 10, 0);

        bombaLigadaAsLabel = new JLabel();

        okFont = bombaLigadaAsLabel.getFont();
        okFont = new Font(okFont.getName(), Font.ITALIC, okFont.getSize());
        warningFont = new Font(okFont.getName(), Font.ITALIC, okFont.getSize() - 1);
        badFont = new Font(okFont.getName(), Font.BOLD, okFont.getSize() - 2);

        ligadaFont = new Font(okFont.getName(), Font.BOLD, okFont.getSize() - 1);
        desligadaFont = new Font(okFont.getName(), Font.BOLD, okFont.getSize() - 1);
        normalFont = new Font(okFont.getName(), Font.BOLD, okFont.getSize() - 1);

        setLigadaAs();

        add(bombaLigadaAsLabel, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(5, 5, 15, 0);

        bombaAbastecendo = new JLabel();

        String abastecendo = "";

        setAbastecendo();

        add(bombaAbastecendo, gridConstraints);

        quantidadeAbastecimentos = new JLabel();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 3;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(5, 5, 5, 5);

        setAbastecimentos();

        add(quantidadeAbastecimentos, gridConstraints);

        verAbastecimentos = new JButton(new javax.swing.ImageIcon(getClass().getResource("/imagens/lista3.png")));
        verAbastecimentos.setPreferredSize(new Dimension(22, 22));
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 3;
        gridConstraints.anchor = GridBagConstraints.EAST;
        gridConstraints.insets = new Insets(5, 15, 5, 10);
        verAbastecimentos.setToolTipText("clique e veja abastecimentos da bomba " + bombaCombustivel.getId());

        abastecimentosWindow = new RelatorioAbastecimentosDeUmaBombaWindow(this);

        verAbastecimentos.addActionListener(this::verAbastecimentosActionPerformed);

        add(verAbastecimentos, gridConstraints);

        totalCombustivelAbastecido = new JLabel();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 4;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(5, 5, 5, 5);
        add(totalCombustivelAbastecido, gridConstraints);

        setTotalCombustivelAbastecido();

        nivelDoReservatorio = new JLabel();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 5;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(15, 5, 5, 5);
        add(nivelDoReservatorio, gridConstraints);

        setNivelReservatorio(getNivelReservatorio(getModelo().getCombustivel()));

        velocidadeAbastecimentoLabel = new JLabel();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 6;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(5, 5, 10, 10);

        setVelocidadeAbastecimento();

        add(velocidadeAbastecimentoLabel, gridConstraints);

        velocidadeAbastecimento = new JSlider(1, 100);
        velocidadeAbastecimento.setPreferredSize(new Dimension(90, 40));
        velocidadeAbastecimento.setValue(bombaCombustivel.getVelocidadeAbastecimento());
        velocidadeAbastecimento.setBackground(backgroundColor);
        velocidadeAbastecimento.addChangeListener(this::setVelocidadeAbastecimento);
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 6;
        gridConstraints.anchor = GridBagConstraints.EAST;
        gridConstraints.insets = new Insets(5, 7, 10, 3);

        velocidadeBombaAntesDesligar = velocidadeAbastecimento.getValue();

        add(velocidadeAbastecimento, gridConstraints);

        temperaturaMotorJLabel = new JLabel();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 7;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(5, 5, 3, 10);
        temperaturaMotorJLabel.setFont(warningFont);
        temperaturaMotorJLabel.setForeground(Color.BLACK);

        setTemperaturaMotor(Motor.TEMPERATURA_AMBIENTE);

        add(temperaturaMotorJLabel, gridConstraints);

        resfriarMotorLabel = new JLabel();

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 7;
        gridConstraints.anchor = GridBagConstraints.EAST;
        gridConstraints.insets = new Insets(5, 10, 3, 0);
        resfriarMotorLabel.setPreferredSize(new Dimension(15, 25));

        add(resfriarMotorLabel, gridConstraints);

    }

    public void setTitle(String newValue) {
        headerLabel.setText(newValue);
    }

    private void onOffButtonActionPerformed(ActionEvent e) {

        System.err.print("performing action : ");

        if (((JCheckBox) e.getSource()).isSelected()) {

            uIDelegator.ligarBombaDoControleRemotoParaViewBomba(bombaCombustivel);

            onOff.setIcon(onIcon);

            System.err.println("turned on : " + bombaCombustivel.toStringShorter());

        } else {

            onOff.setIcon(offIcon);

            uIDelegator.desligarBombaDoControleRemotoParaViewBomba(bombaCombustivel);

            System.err.println("turned off : " + bombaCombustivel.toStringShorter());
        }

    }

    private void verAbastecimentosActionPerformed(ActionEvent e) {

        abastecimentosWindow.setBounds(verAbastecimentos.bounds().x + 150, verAbastecimentos.bounds().y + 50, abastecimentosWindow.bounds().width, abastecimentosWindow.bounds().height);

        abastecimentosWindow.raise();

    }

    private String getQuantidadeAbastecidaAsString() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private float getQuantidadeAbastecida() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setAbastecendo() {

        if (! isTanqueCombustivelAbastecendo()) {

            if (getNivelReservatorio(getModelo().getCombustivel()) <= 0) {

                bombaAbastecendo.setText("SEM COMBUSTÍVEL");

            } else {

                if (bombaCombustivel.isAbastecendo()) {

                    bombaAbastecendo.setText("ABASTECENDO " + String.format("%.2f", quantidadeAbastecendo) + "/" + String.format("%.2f", quantidade) + "" + bombaCombustivel.getCombustivel().getNomeDaUnidadeSI(quantidadeAbastecendo).toUpperCase());

                } else if (getModelo().getEstado().equals(BombaCombustivel.DESLIGADA)) {

                    bombaAbastecendo.setText("NÃO ABASTECENDO (000,00)");

                } else {

                    bombaAbastecendo.setText(getModelo().getEstado());

                }

            }

        }else{
            
            
           // System.err.println( this.toString() + " >>>>>>>>>>> tanque de " + getModelo().getCombustivel().getNome() +  " está abastecendo ");
            
            
        }

        applyStyleAtAbastecendo();

    }

    private void applyStyleAtAbastecendo() {

        if (getNivelReservatorio(getModelo().getCombustivel()) <= 0) {

            bombaAbastecendo.setForeground(Color.RED);
            bombaAbastecendo.setFont(badFont);

        } else {

            if (bombaCombustivel.isAbastecendo()) {

                bombaAbastecendo.setFont(normalFont);
                bombaAbastecendo.setForeground(Color.BLUE.brighter());

            } else if (getModelo().getEstado().equals(BombaCombustivel.DESLIGADA)) {

                bombaAbastecendo.setFont(normalFont);
                bombaAbastecendo.setForeground(Color.gray);

            } else {

                bombaAbastecendo.setFont(normalFont);

                if (getBackground().equals(luzApagadaColor)) {
                    bombaAbastecendo.setForeground(Color.WHITE);
                } else {
                    bombaAbastecendo.setForeground(getBackground().darker().darker());
                }

            }

        }
    }

    private float quantidadeAbastecendo = 0.0f;
    private float quantidade;

    public void setAbastecendo(float quantidade) {
        quantidadeAbastecendo = quantidade;
        setAbastecendo();
    }

    public void setAbastecendo(float f, float quantidade) {
        quantidadeAbastecendo = f;
        this.quantidade = quantidade;
        setAbastecendo();
    }

    public void setLigadaAs() {

        if (bombaCombustivel.isLigada()) {

            bombaLigadaAsLabel.setText("LIGADA ÀS " + dateFormatter.format(bombaCombustivel.getLigadaAs()));

        } else {

            try {

                bombaLigadaAsLabel.setText("DESLIGADA ÀS " + dateFormatter.format(bombaCombustivel.getDesligadaAs()));

            } catch (Exception e) {

                bombaLigadaAsLabel.setText("DESLIGADA");

            }
        }

        applyStyleAtLigadaAs();
    }

    private void applyStyleAtLigadaAs() {

        if (bombaCombustivel.isLigada()) {

            bombaLigadaAsLabel.setForeground(Color.GREEN.darker());
            bombaLigadaAsLabel.setFont(ligadaFont);

        } else {

            bombaLigadaAsLabel.setForeground(Color.RED);
            bombaLigadaAsLabel.setFont(desligadaFont);

        }

    }

    public void setMensagemDoConsole(String novaMensagem) {
        bombaLigadaAsLabel.setText(novaMensagem);
    }

    public void setMensagemDoConsoleAbastecendo(String novaMensagem) {
        bombaAbastecendo.setText(novaMensagem);
    }

    public void setAbastecimentos() {
        quantidadeAbastecimentos.setText("#ABASTECIMENTOS " + bombaCombustivel.getAbastecimentos().size());
    }

    public void setVelocidadeAbastecimento() {

        if (bombaCombustivel.isAbastecendo()) {

            velocidadeAbastecimentoLabel.setText("VELOCIDADE " + bombaCombustivel.getVelocidadeAbastecimento() + "%");

        } else {

            velocidadeAbastecimentoLabel.setText("VELOCIDADE 0%");

        }

        applyStyleAtVelocidadeAbastecimento();
    }

    private void applyStyleAtVelocidadeAbastecimento() {

        if (bombaCombustivel.isAbastecendo()) {

            if (getBackground().equals(luzApagadaColor)) {
                velocidadeAbastecimentoLabel.setForeground(Color.WHITE);
            } else {
                velocidadeAbastecimentoLabel.setForeground(getBackground().darker().darker());
            }

        } else {

            velocidadeAbastecimentoLabel.setForeground(Color.gray);
        }
    }

    private void setVelocidadeAbastecimento(ChangeEvent e) {
        int velocidade = ((JSlider) e.getSource()).getValue();
        bombaCombustivel.setVelocidadeAbastecimento(velocidade);
        setVelocidadeAbastecimento();
    }

    public void setTemperaturaMotor(float temperatura) {
        //~25 - 50 - normal 
        //~51 - 75 - quente
        //~76 - 100 - critica
        String traducaoTemperatura = "";

        if (Motor.isTemperaturaNormal(temperatura)) {
            traducaoTemperatura = "normal";
        }
        if (Motor.isQuente(temperatura)) {
            traducaoTemperatura = "quente";
        }
        if (Motor.isTemperaturaCritica(temperatura)) {
            traducaoTemperatura = "crítica";
        }

        temperaturaMotorJLabel.setText("TEMPERATURA " + String.format("%.2f", temperatura) + "*C (" + traducaoTemperatura + ")");

        temperaturaMotor = temperatura;

        applyStyleAtTemperaturaMotor(temperatura);

    }

    private void applyStyleAtTemperaturaMotor(float temperatura) {

        if (Motor.isTemperaturaNormal(temperatura)) {

            temperaturaMotorJLabel.setFont(warningFont);
            if (getBackground().equals(luzApagadaColor)) {

                temperaturaMotorJLabel.setForeground(Color.WHITE);

            } else {

                temperaturaMotorJLabel.setForeground(getBackground().darker().darker());

            }

        }
        if (Motor.isQuente(temperatura)) {

            temperaturaMotorJLabel.setFont(warningFont);
            temperaturaMotorJLabel.setForeground(Color.RED);

        }
        if (Motor.isTemperaturaCritica(temperatura)) {

            temperaturaMotorJLabel.setFont(badFont);
            temperaturaMotorJLabel.setForeground(Color.RED);

        }
    }

    private void applyStyleAtTemperaturaMotor() {

        applyStyleAtTemperaturaMotor(this.temperaturaMotor);

    }

    public BombaCombustivel getModelo() {
        return this.bombaCombustivel;
    }

    public JButton getVerAbastecimentos() {
        return verAbastecimentos;
    }

    public void atualizaAposBombaLigar() {
        setLigadaAs();
        setAbastecendo(0f);
        setAbastecimentos();
        setVelocidadeAbastecimento();
        velocidadeAbastecimento.setValue(velocidadeBombaAntesDesligar);
        onOff.setIcon(onIcon);
    }

    int velocidadeBombaAntesDesligar;

    public void atualizaAposBombaDesligar() {
        setLigadaAs();
        setAbastecendo(0f);
        setAbastecimentos();
        setVelocidadeAbastecimento();
        velocidadeBombaAntesDesligar = bombaCombustivel.getVelocidadeAbastecimento();
        velocidadeAbastecimento.setValue(velocidadeAbastecimento.getMinimum());
        onOff.setIcon(offIcon);
    }

    public void setMensagemAguardandoCaixa(String msgm) {
        bombaAbastecendo.setText(msgm);
    }

    private void setTotalCombustivelAbastecido() {

        if (isGNV()) {

            totalCombustivelAbastecido.setText("# m3(abastecidos) " + String.format("%.2f", totalCombustivelAbastecidoDouble));
            totalCombustivelAbastecido.setToolTipText("UNIDADE EM m3 = M3 = METRO CÚBICO(m3)");

        } else {

            totalCombustivelAbastecido.setText("#LITROS(abastecidos) " + String.format("%.2f", totalCombustivelAbastecidoDouble));
            totalCombustivelAbastecido.setToolTipText("UNIDADE EM LITROS(l)");
        }
    }

    private void atualizaTotalCombustivelAbastecido(float quantidadeAbastecido) {

        if (isGNV()) {

            totalCombustivelAbastecido.setText("# m3(abastecidos) " + String.format("%.2f", quantidadeAbastecido));
            totalCombustivelAbastecido.setToolTipText("UNIDADE EM m3 = M3 = METRO CÚBICO(m3)");

        } else {

            totalCombustivelAbastecido.setText("#LITROS(abastecidos) " + String.format("%.2f", quantidadeAbastecido));
            totalCombustivelAbastecido.setToolTipText("UNIDADE EM LITRO(l)");
        }
    }

    public void setTotalCombustivelAbastecido(float quantidadeAbastecido) {
        totalCombustivelAbastecidoDouble += quantidadeAbastecido;
        setTotalCombustivelAbastecido();
    }

    public void atualizarTotalCombustivelAbastecido(float quantidadeAbastecido) {
        this.atualizaTotalCombustivelAbastecido(totalCombustivelAbastecidoDouble + quantidadeAbastecido);
    }

    public void atualizarNivelReservatorio(float nivel) {
        setNivelReservatorio(nivel);
    }

    public void setNivelReservatorio(float nivel) {

        applyStyleAtNivelReservatorio();

        if (isReservatorioNivelNormal()) {

            if (isGNV()) {

                nivelDoReservatorio.setText("#NÍVEL(normal) " + String.format("%.2f", nivel) + " m3");
                nivelDoReservatorio.setToolTipText("UNIDADE EM m3 = M3 = METRO CÚBICO(m3)");

            } else {

                nivelDoReservatorio.setText("#NÍVEL(normal) " + String.format("%.2f", nivel) + " l");
                nivelDoReservatorio.setToolTipText("UNIDADE EM LITRO(l)");
            }

        } else if (isReservatorioAbaixoNivelCriticoEAcimaUmQuartoNivelCritico()) {

            if (isGNV()) {

                nivelDoReservatorio.setText("#NÍVEL(baixo) " + String.format("%.2f", nivel) + " m3");
                nivelDoReservatorio.setToolTipText("UNIDADE EM m3 = M3 = METRO CÚBICO(m3)");

            } else {

                nivelDoReservatorio.setText("#NÍVEL(baixo) " + String.format("%.2f", nivel) + " l");
                nivelDoReservatorio.setToolTipText("UNIDADE EM LITRO(l)");
            }

        } else {//esta muito critico o nivel deste tanque combustivel, prestes a ficar sem combustivel para abastecer

            if (!isReservatorioVazio()) {

                if (isGNV()) {

                    nivelDoReservatorio.setText("#NÍVEL(crítico) " + String.format("%.2f", nivel) + " m3");
                    nivelDoReservatorio.setToolTipText("UNIDADE EM m3 = M3 = METRO CÚBICO(m3)");

                } else {

                    nivelDoReservatorio.setText("#NÍVEL(crítico) " + String.format("%.2f", nivel) + " l");
                    nivelDoReservatorio.setToolTipText("UNIDADE EM LITRO(l)");
                }

            } else {

                nivelDoReservatorio.setText("SEM COMBUSTÍVEL");

            }

        }

    }

    private void applyStyleAtNivelReservatorio() {

        if (isReservatorioNivelNormal()) {

            nivelDoReservatorio.setForeground(Color.GREEN.darker());
            nivelDoReservatorio.setFont(new Font(okFont.getName(), Font.BOLD, okFont.getSize() - 2));

        } else if (isReservatorioAbaixoNivelCriticoEAcimaUmQuartoNivelCritico()) {

            nivelDoReservatorio.setForeground(Color.RED.brighter());
            nivelDoReservatorio.setFont(warningFont);

        } else {//esta muito critico o nivel deste tanque combustivel, prestes a ficar sem combustivel para abastecer

            nivelDoReservatorio.setForeground(Color.RED.darker());
            nivelDoReservatorio.setFont(badFont);

        }
    }

    private float getNivelReservatorio(Combustivel combustivel) {
        return uIDelegator.getNivelReservatorio(combustivel);
    }

    private boolean isTanqueCombustivelAbastecendo() {

        boolean isTanqueCombustivelAbastecendo = false;

        if (tanqueCombustivelUI == null) {

            try {
                
                ReservatorioCombustiveisUI reservatorioCombustiveisUI = (ReservatorioCombustiveisUI)getModelo().getUIDelegator().getUI(ReservatorioCombustiveisUI.class);

                for (TanqueCombustivelUI tanqueUI : reservatorioCombustiveisUI.getReservatorioUI()) {

                    if (getModelo().getCombustivel().getNome().equals(tanqueUI.getNomeCombustivel())) {

                        this.tanqueCombustivelUI = tanqueUI;

                        isTanqueCombustivelAbastecendo = this.tanqueCombustivelUI.isAbastecendo();
                        
                        break;

                    }

                }

            } catch (Exception e) {
            }

        } else {
            
            isTanqueCombustivelAbastecendo = tanqueCombustivelUI.isAbastecendo();
            
        }

        return isTanqueCombustivelAbastecendo;

    }

    private boolean isReservatorioNivelNormal() {
        return getNivelReservatorio(getModelo().getCombustivel()) > Reservatorio.NIVEL_MINIMO_TANQUE;
    }

    private boolean isReservatorioAbaixoNivelCriticoEAcimaUmQuartoNivelCritico() {
        return getNivelReservatorio(getModelo().getCombustivel()) > Reservatorio.NIVEL_MINIMO_TANQUE / 4;
    }

    private boolean isReservatorioVazio() {
        return getNivelReservatorio(getModelo().getCombustivel()) == 0;
    }

    public void setOnOff() {

        if (getModelo().isLigada()) {
            onOff.setIcon(onIcon);
            onOff.setToolTipText("DESLIGAR A BOMBA");
            wifiLabel.setIcon(wifiIconOn);
        } else {
            onOff.setIcon(offIcon);
            onOff.setToolTipText("LIGAR A BOMBA");
            wifiLabel.setIcon(wifiIconOff);
        }

    }

    public void setUpArrow() {

        new Thread(() -> {
            resfriarMotorLabel.setIcon(upArrowIcon);
        }).start();

    }

    public void setDownArrow() {
        new Thread(() -> {
            resfriarMotorLabel.setIcon(downArrowIcon);
        }).start();
    }

    public void addAbastecimento(Abastecimento abastecimento) {
        abastecimentosWindow.addAbastecimento(abastecimento);
    }

    public boolean isGNV() {
        return getModelo().isGNV();
    }

    public boolean isDesteCombustivel(Combustivel combustivel) {
        return getModelo().getCombustivel().equals(combustivel);
    }

    public boolean isDesteCombustivel(String combustivel) {
        return getModelo().getCombustivel().getNome().equals(combustivel);
    }

    public void updateStyle() {
        applyStyleAtVelocidadeAbastecimento();
        applyStyleAtAbastecendo();
        applyStyleAtLigadaAs();
        applyStyleAtNivelReservatorio();
        applyStyleAtTemperaturaMotor();
    }

    @Override
    public String toString() {
        return "ControleRemotoBombaCombustivel UI " + bombaCombustivel.toStringShorter();
    }

}
