/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.controleRemoto.bombaCombustivel;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.view.interfaces.FadableAndRaisableUI;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.combustivel.bomba.excetion.BombaCombustivelException;
import com.undra.modelo.combustivel.reservatorio.Reservatorio;
import com.undra.modelo.combustivel.reservatorio.exception.NivelCriticoDeCombustivelException;
import com.undra.modelo.combustivel.reservatorio.exception.ReservatorioExeption;
import com.undra.modelo.contabilidade.Caixa;
import com.undra.modelo.postocombustivel.PostoCombustivel;
import com.undra.view.bombacombustivel.BombaCombustivelUIWindow;
import java.awt.HeadlessException;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author alexandre
 */
public final class ControleRemotoBombaCombustivelUIWindow extends JFrame implements FadableAndRaisableUI{

    UIDelegator uIDelegator;

    ControleRemotoBombaCombustivelUI crbcui;

    Reservatorio reservatorio;
    PostoCombustivel postoCombustivel;

    public static void main(String[] args) {

        new ControleRemotoBombaCombustivelUIWindow(new UIDelegator()).configureAndShow();

    }


    public ControleRemotoBombaCombustivelUIWindow(UIDelegator uIDelegator) throws HeadlessException {

        reservatorio = new Reservatorio(130f, 800f);
        Combustivel gasolina = new Combustivel(Combustivel.GASOLINA, 3.34f, Combustivel.LITRO);
        try {
            reservatorio.abastecer(gasolina, reservatorio.getNIVEL_MAX_TANQUE());
        } catch (NivelCriticoDeCombustivelException ex) {
            Logger.getLogger(BombaCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
        Caixa caixa = new Caixa();
        ModelDelegator businessDelegator = new ModelDelegator(reservatorio, caixa);
        caixa.setDelegator(businessDelegator);

        try {
            crbcui = new ControleRemotoBombaCombustivelUI(new BombaCombustivel(gasolina, 1, businessDelegator), uIDelegator);
        } catch (BombaCombustivelException ex) {
            Logger.getLogger(ControleRemotoBombaCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
        configureAndShow();

    }

    
    public ControleRemotoBombaCombustivelUIWindow(BombaCombustivel bombaCombustivel, UIDelegator uIDelegator) throws HeadlessException {

        crbcui = new ControleRemotoBombaCombustivelUI(bombaCombustivel, uIDelegator);
        configureAndShow();

    }
    
    public void configureAndShow() {

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }

        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setTitle(getClass().getSimpleName() + " App");
       

        setResizable(false);

        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

        setUndecorated(true);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        pack();

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

        
        setOpacity(0);
        setVisible(true);
        
        new Thread(() -> {
            float opacity1 = 1.0f;
            for (int i = 0; i < 100; i++) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ControleRemotoBombaCombustivelUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            setOpacity(0.87f);
        }).start();
        
    }

    private void placeComponentsAtFrame() {

        getContentPane().add(crbcui);
        
    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }

    @Override
    public void fade() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void raise() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
