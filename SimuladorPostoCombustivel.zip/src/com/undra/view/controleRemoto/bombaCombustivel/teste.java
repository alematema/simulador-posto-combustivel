/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.controleRemoto.bombaCombustivel;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.combustivel.bomba.excetion.BombaCombustivelException;
import com.undra.modelo.combustivel.reservatorio.Reservatorio;
import com.undra.modelo.combustivel.reservatorio.exception.NivelCriticoDeCombustivelException;
import com.undra.modelo.combustivel.reservatorio.exception.ReservatorioExeption;
import com.undra.modelo.contabilidade.Caixa;
import com.undra.modelo.contabilidade.exception.CaixaException;
import com.undra.modelo.postocombustivel.PostoCombustivel;
import com.undra.modelo.postocombustivel.PostoGasolinaException;
import com.undra.modelo.recursoshumanos.exception.RecursosHumanosException;
import com.undra.view.bombacombustivel.BombaCombustivelUIWindow;
import com.undra.view.bombacombustivel.DisplayDigitalException;
import java.awt.HeadlessException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author alexandre
 */
public class teste {

    public static void main(String[] args) {

        UIDelegator uIDelegator = new UIDelegator();

        Reservatorio reservatorio;
        PostoCombustivel postoCombustivel;

        reservatorio = new Reservatorio(90000, 800f);
        
        Combustivel gasolina = new Combustivel(Combustivel.GASOLINA, 3.34f, Combustivel.LITRO);
        Combustivel gnv = new Combustivel(Combustivel.GNV, 2.22f, Combustivel.METRO_CUBICO);
        try {
            
            reservatorio.abastecer(gasolina, reservatorio.getNIVEL_MAX_TANQUE());
            reservatorio.abastecer(gnv, reservatorio.getNIVEL_MAX_TANQUE());
            
        } catch (NivelCriticoDeCombustivelException ex) {
            Logger.getLogger(BombaCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        Caixa caixa = new Caixa();
        ModelDelegator businessDelegator = new ModelDelegator(reservatorio, caixa);
        caixa.setDelegator(businessDelegator);

        try {

            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {

                if ("GTK+".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }

//            BombaCombustivel bombaCombustivel = new BombaCombustivel(gasolina, 1, businessDelegator);
//            BombaCombustivelUIWindow combustivelUIWindow = new BombaCombustivelUIWindow(bombaCombustivel, uIDelegator);
//            ControleRemotoBombaCombustivelUIWindow remotoBombaCombustivelUIWindow = new ControleRemotoBombaCombustivelUIWindow(bombaCombustivel, uIDelegator);
//            bombaCombustivel = new BombaCombustivel(gasolina, 2, businessDelegator);
//            combustivelUIWindow = new BombaCombustivelUIWindow(bombaCombustivel, uIDelegator);
//            remotoBombaCombustivelUIWindow = new ControleRemotoBombaCombustivelUIWindow(bombaCombustivel, uIDelegator);

            BombaCombustivel bombaCombustivel = new BombaCombustivel(gasolina, 1, businessDelegator);
            new BombaCombustivelUIWindow(bombaCombustivel, uIDelegator);
            new ControleRemotoBombaCombustivelUIWindow(bombaCombustivel, uIDelegator);
            bombaCombustivel = new BombaCombustivel(gnv, 2, businessDelegator);
            new BombaCombustivelUIWindow(bombaCombustivel, uIDelegator);
            new ControleRemotoBombaCombustivelUIWindow(bombaCombustivel, uIDelegator);
            bombaCombustivel = new BombaCombustivel(gnv, 3, businessDelegator);
            new BombaCombustivelUIWindow(bombaCombustivel, uIDelegator);
            new ControleRemotoBombaCombustivelUIWindow(bombaCombustivel, uIDelegator);
            bombaCombustivel = new BombaCombustivel(gnv, 4, businessDelegator);
            new BombaCombustivelUIWindow(bombaCombustivel, uIDelegator);
            new ControleRemotoBombaCombustivelUIWindow(bombaCombustivel, uIDelegator);

                    
            
        } catch (HeadlessException ex) {
            Logger.getLogger(teste.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ReservatorioExeption ex) {
            Logger.getLogger(teste.class.getName()).log(Level.SEVERE, null, ex);
        } catch (CaixaException ex) {
            Logger.getLogger(teste.class.getName()).log(Level.SEVERE, null, ex);
        } catch (BombaCombustivelException ex) {
            Logger.getLogger(teste.class.getName()).log(Level.SEVERE, null, ex);
        } catch (PostoGasolinaException ex) {
            Logger.getLogger(teste.class.getName()).log(Level.SEVERE, null, ex);
        } catch (RecursosHumanosException ex) {
            Logger.getLogger(teste.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DisplayDigitalException ex) {
            Logger.getLogger(teste.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(teste.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(teste.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(teste.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(teste.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
