package com.undra.view.genericsliderwindow;

import com.undra.view.interfaces.FadableAndRaisableUI;
import com.undra.view.relatorios.RelatoriosFrentistasAbastecimentosUIWindow;
import com.undra.app.util.OutPut;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.HeadlessException;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.ChangeEvent;

/**
 * Window Generic JSlider
 *
 * @author alexandre
 */
public final class JSliderGenericoUIWindow extends JFrame implements FadableAndRaisableUI {

    public static void main(String[] args) {

        new Thread(() -> {
            JSliderGenericoUIWindow window = new JSliderGenericoUIWindow(new OutPut() {
                @Override
                public float getValue() {
                    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }
                
                @Override
                public void setValue(float value) {
                    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }
            }, "VELOCIDADE DO CAIXA");
            
            window.configureAndShow();

        }).start();

    }

    private JSliderGenericoUI jSliderGenericoUI;

    private JPanel genericJSliderHeader;
    private JCheckBox onOff;
    private JLabel headerLabel;
    private final Font headerFont = new Font("Ubuntu", Font.BOLD, 14);
    private final ImageIcon offIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/off.24x12.png"));
    private String tituloDaJanela;

    private OutPut outPut;
    
    private String traducaoDoValor;

    public JSliderGenericoUIWindow() throws HeadlessException {

        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {

            if ("GTK+".equals(info.getName())) {
                try {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                    Logger.getLogger(JSliderGenericoUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
                break;

            }
        }
    }
    

    public JSliderGenericoUIWindow(OutPut outPut, String title) {
        this();
        this.outPut = outPut;
        setTitle(title+"-");
        configure();
    }

    public void configure() {

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
            }

        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        getContentPane().setBackground(Color.WHITE);

        setResizable(false);

        setUndecorated(true);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        pack();

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

        setLocation((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 5, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 15);
        
    }

    public void configureAndShow() {

        configure();
        raise();

    }

    private void placeComponentsAtFrame() {

        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints();

        jSliderGenericoUI = new JSliderGenericoUI();
        jSliderGenericoUI.setBackground(getContentPane().getBackground());

        genericJSliderHeader = new JPanel();
        genericJSliderHeader.setPreferredSize(new Dimension(jSliderGenericoUI.getPreferredSize().width + 35, 25));
        genericJSliderHeader.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1, true));
        genericJSliderHeader.setBackground(Color.WHITE);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.NORTH;
        gridConstraints.insets = new Insets(0, 0, 5, 0);

        add(genericJSliderHeader, gridConstraints);

        genericJSliderHeader.setLayout(new GridBagLayout());

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;

        onOff = new JCheckBox();
        onOff.setToolTipText("CLIQUE PARA FECHAR");

        onOff.setSelected(false);
        onOff.setIcon(offIcon);
        onOff.setPreferredSize(new Dimension(26, 20));

        gridConstraints.insets = new Insets(5, 0, 5, ((int) genericJSliderHeader.getPreferredSize().width) - onOff.getPreferredSize().width);

        onOff.addActionListener(this::onOffButtonActionPerformed);

        genericJSliderHeader.add(onOff, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(0, 25, 0, 0);
        
        headerLabel = new JLabel();
        headerLabel.setForeground(Color.BLACK);
        headerLabel.setFont(headerFont);
        genericJSliderHeader.add(headerLabel, gridConstraints);

        jSliderGenericoUI.getjSlider().addChangeListener((ChangeEvent e) -> {
            
            int valor = ((JSlider) e.getSource()).getValue();
            
            try {

                outPut.setValue(valor);

            } catch (Exception ex) {
            }

            //traducao do valor
            if(valor<15)traducaoDoValor="BAIXÍSSIMA";
            else if(valor<35)traducaoDoValor = "BAIXA";
            else if(valor<65)traducaoDoValor = "MÉDIA";
            else if(valor<85)traducaoDoValor = "ALTA";
            else traducaoDoValor="ALTÍSSIMA";
            
            setTitle(getTitle().split("-")[0]+"-"+traducaoDoValor);
            
//            System.err.println("new value " + valor + " traducao do valor " + traducaoDoValor);
            
        });

        jSliderGenericoUI.getjSlider().setValue(50);
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;

        getContentPane().add(jSliderGenericoUI, gridConstraints);

    }

    private void onOffButtonActionPerformed(ActionEvent e) {
        fade();
    }

    
    @Override
    public void setTitle(String title) {

        try {

            super.setTitle(title);
            headerLabel.setText(title);
            tituloDaJanela = title;

        } catch (Exception e) {
        }

    }

    public void setValue(int newValue) {
        jSliderGenericoUI.getjSlider().setValue(newValue);
    }

    public int getValue() {
        return jSliderGenericoUI.getjSlider().getValue();
    }

    public String getTraducaoDoValor() {
        return traducaoDoValor;
    }
    
    @Override
    public void fade() {

        new Thread(() -> {

            for (int i = 100; i > 1; i--) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(RelatoriosFrentistasAbastecimentosUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            setVisible(false);

        }).start();
    }

    @Override
    public void raise() {

        new Thread(() -> {

            setAlwaysOnTop(true);
            setOpacity(0.11f);
            setVisible(true);
            float opacity1 = 1.0f;

            for (int i = 0; i < 95; i++) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(RelatoriosFrentistasAbastecimentosUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            requestFocus();

        }).start();
    }

}
