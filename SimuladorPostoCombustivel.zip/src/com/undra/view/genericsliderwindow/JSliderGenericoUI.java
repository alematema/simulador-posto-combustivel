package com.undra.view.genericsliderwindow;

import java.awt.Dimension;
import javax.swing.JPanel;
import javax.swing.JSlider;

/**
 * Um JSlider Generico
 *
 * @author alexandre
 */
public class JSliderGenericoUI extends JPanel {

    private Dimension dimension;
    private JSlider jSlider;

    public JSliderGenericoUI() {
        configure();
    }

    private void configure() {

        dimension = new Dimension(300, 65);

        setPreferredSize(dimension);

        jSlider = new JSlider(1, 100, 1);

        jSlider.setPreferredSize(new Dimension(dimension.width - 15, dimension.height - 20));

        add(jSlider);

    }

    public JSlider getjSlider() {
        return jSlider;
    }

    public Dimension getDimension() {
        return dimension;
    }

}
