package com.undra.view.interfaces;

/**
 *
 * @author alexandre
 */
public interface FadableAndRaisableUI {
    
    void fade();
    void raise();

}
