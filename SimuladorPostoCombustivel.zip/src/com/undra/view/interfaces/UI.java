package com.undra.view.interfaces;

/**
 * Interface de marcação para classes que sao User Interface - UI
 * @author alexandre
 */
public interface UI {}
