/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.reservatorio;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.view.interfaces.FadableAndRaisableUI;
import com.undra.menu.MyMenuBar;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.reservatorio.Reservatorio;
import com.undra.modelo.combustivel.reservatorio.exception.NivelCriticoDeCombustivelException;
import com.undra.view.interfaces.UI;
import com.undra.view.mesaControleRemotoDasBombasCombustivelUI.MesaControleRemotoDasBombasUIWindow;
import java.awt.Color;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * Window do reservatorio de combustíveis
 *
 * @author alexandre
 */
public class ReservatorioCombustiveisUIWindow extends JFrame implements FadableAndRaisableUI, UI {

    private final Reservatorio modelo;
    private ReservatorioCombustiveisUI reservatorioCombustiveisUI;

    public ReservatorioCombustiveisUIWindow(Reservatorio modelo) {

        if (modelo == null) {
            throw new NullPointerException("O reservatório não pode ser null !!!");
        }
        if (modelo.getTanques() == null) {
            throw new NullPointerException("Os tanques não podem ser null !!!");
        }

        if (modelo.getuIDelegator() == null) {
            throw new NullPointerException("O UIDelegator não pode ser null !!!");
        }
        if (modelo.getModelDelegator() == null) {
            throw new NullPointerException("O ModelDelegator não pode ser null !!!");
        }

        this.modelo = modelo;

    }

    public void configure() {

        
        modelo.getuIDelegator().registrarUI(this);
        
        
        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
            if ("GTK+".equals(info.getName())) {
                try {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                    Logger.getLogger(ReservatorioCombustiveisUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
                break;
            }
        }

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }

        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setTitle("Tanques dos Combustíveis - SIMULADOR POSTO COMBUSTÍVEL");

        getContentPane().setBackground(new Color(255, 255, 192));

        setResizable(false);

        setUndecorated(true);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        pack();

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

    }

    public void configureAndShow() {

        configure();

        setVisible(true);

    }

    private void placeComponentsAtFrame() {
        reservatorioCombustiveisUI = new ReservatorioCombustiveisUI(modelo);
        getContentPane().add(reservatorioCombustiveisUI);
    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }

    public Reservatorio getModelo() {
        return modelo;
    }

    public ReservatorioCombustiveisUI getReservatorioCombustiveisUI() {
        return reservatorioCombustiveisUI;
    }

    @Override
    public void fade() {

        new Thread(() -> {

            for (int i = 100; i > 1; i--) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(MesaControleRemotoDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            setVisible(false);
            transferFocus();

        }).start();
    }

    @Override
    public void raise() {

        new Thread(() -> {

            try {
                ((MyMenuBar) getJMenuBar()).setVisibleInvisibleMenus();
               
            } catch (Exception e) {

            }

            setOpacity(0.11f);
            setVisible(true);
            float opacity1 = 1.0f;
            for (int i = 0; i < 100; i++) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(MesaControleRemotoDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            requestFocus();

        }).start();

    }

    @Override
    public String toString() {
        return "ReservatorioCombustiveisUIWindow UI";
    }

    public static void main(String[] args) {

        Combustivel gasolina = new Combustivel(Combustivel.GASOLINA, 2.55f, Combustivel.LITRO);
        Combustivel etanol = new Combustivel(Combustivel.ETANOL, 1.99f, Combustivel.LITRO);
        Combustivel diesel = new Combustivel(Combustivel.DIESEL, 3.04f, Combustivel.LITRO);
        Combustivel gnv = new Combustivel(Combustivel.GNV, 1.5f, Combustivel.METRO_CUBICO);

        Reservatorio reservatorio1 = new Reservatorio(90000f, 300f, new ModelDelegator(), new UIDelegator());

        try {
            reservatorio1.abastecer(gasolina, reservatorio1.getNIVEL_MAX_TANQUE());
            reservatorio1.abastecer(etanol, reservatorio1.getNIVEL_MAX_TANQUE());
            reservatorio1.abastecer(diesel, reservatorio1.getNIVEL_MAX_TANQUE());
            reservatorio1.abastecer(gnv, reservatorio1.getNIVEL_MAX_TANQUE());
        } catch (NivelCriticoDeCombustivelException ex) {
//            Logger.getLogger(PostoCombustivel.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("Algo excepcional ocorreu em PostoCombustivel.abastecerTanquesDosCombustiveis " + ex.getLocalizedMessage());
        }
        
        ReservatorioCombustiveisUIWindow window = new ReservatorioCombustiveisUIWindow(reservatorio1);

        window.configure();

        new Thread(() -> {
            try {
                System.err.println("esperando ");
                Thread.sleep(5000);
            } catch (InterruptedException ex) {
                Logger.getLogger(ReservatorioCombustiveisUIWindow.class.getName()).log(Level.SEVERE, null, ex);
            }
            window.raise();
            window.getReservatorioCombustiveisUI().setNivelTanques(window.getModelo().getNivel(Combustivel.DIESEL));
        }).start();
        
        

    }

}
