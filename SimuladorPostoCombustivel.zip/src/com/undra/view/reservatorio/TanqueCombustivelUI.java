package com.undra.view.reservatorio;

import com.undra.dialogo.DialogoPane;
import com.undra.dialogo.DialogoWindowUI;
import com.undra.menu.MenuNavigator;
import com.undra.modelo.combustivel.reservatorio.Reservatorio;
import com.undra.modelo.combustivel.reservatorio.exception.NivelCriticoDeCombustivelException;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.util.List;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

/**
 * UI do tanque de combustivel
 *
 * @author alexandre
 */
public class TanqueCombustivelUI extends JPanel {

    private final float tanqueCombustivelHeight = 550f;
    private final float tanqueCombustivelWidth = 275f;

    private javax.swing.JProgressBar liveLevelProgressBar;
    private javax.swing.JPanel tanqueCombustivel;

    private volatile JLabel headerTitleJLabel;
    private JPanel header;

    private JButton abastecerJButton;

    private final String nomeCombustivel;
    private volatile float nivel;
    private volatile float nivelInicial;
    private float MAX_CAPACIDADE;

    volatile private boolean abastecendo = false;
    volatile private boolean starting = false;

    private final Font microSize = new Font("Ubuntu", Font.BOLD, 5);
    private final Font verySmall = new Font("Ubuntu", Font.BOLD, 5);
    private final Font small = new Font("Ubuntu", Font.BOLD, 8);
    private final Font normal = new Font("Ubuntu", Font.BOLD, 13);

    private final int NIVEL_ALTO = 75;
    private final int NIVEL_MEDIO = 30;
    private final int NIVEL_BAIXO = 0;

    GridBagConstraints gridConstraints = new GridBagConstraints();

    private Reservatorio modelo;

    public TanqueCombustivelUI(String nomeCombustivel, float nivel, float MAX_CAPACIDADE, Reservatorio modelo) {

        if (nomeCombustivel == null) {
            nomeCombustivel = "COMBUSTÍVEL ?";
        }

        this.nomeCombustivel = nomeCombustivel;

        if (MAX_CAPACIDADE <= 0) {
            throw new IllegalArgumentException("MAX_CAPACIDADE do tanque deve ser >= do que ZERO : valor passado=" + MAX_CAPACIDADE);
        }

        this.MAX_CAPACIDADE = MAX_CAPACIDADE;

        if (nivel < 0) {
            nivel = 0;
        }

        if (nivel > MAX_CAPACIDADE) {
            nivel = MAX_CAPACIDADE;
        }

        this.nivel = nivel;
        nivelInicial = nivel;

        if (modelo == null) {
            throw new NullPointerException("O Reservatório não pode ser null !!!");
        }

        this.modelo = modelo;

        headerTitleJLabel = new JLabel("TANQUE " + nomeCombustivel.toUpperCase() + ", " + String.format("%.2f", MAX_CAPACIDADE));

        configure();

    }

    private void configure() {

        removeAll();

        setLayout(new GridBagLayout());

        setSize(new Dimension((int) tanqueCombustivelWidth, (int) tanqueCombustivelHeight + 100));

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(0, 0, 0, 0);

        header = new JPanel();
        headerTitleJLabel.setSize(new Dimension(getPreferredSize().width - 6, 60));

        headerTitleJLabel.setFont(normal);

        header.add(headerTitleJLabel);

        add(header, gridConstraints, 0);

        tanqueCombustivel = new javax.swing.JPanel();
        liveLevelProgressBar = new javax.swing.JProgressBar();
        tanqueCombustivel.setBackground(new java.awt.Color(80, 248, 34));
        tanqueCombustivel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));
        tanqueCombustivel.setSize(new Dimension((int) tanqueCombustivelWidth, (int) tanqueCombustivelHeight));
        tanqueCombustivel.setPreferredSize(new Dimension((int) tanqueCombustivelWidth, (int) tanqueCombustivelHeight + 5));

        liveLevelProgressBar.setBackground(new java.awt.Color(91, 234, 57));
        liveLevelProgressBar.setOrientation(1);
        liveLevelProgressBar.setToolTipText("");
        liveLevelProgressBar.setValue(0);
        liveLevelProgressBar.setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        liveLevelProgressBar.setIndeterminate(true);
        liveLevelProgressBar.setStringPainted(true);
        liveLevelProgressBar.setPreferredSize(new Dimension(0, 0));
        liveLevelProgressBar.setSize(liveLevelProgressBar.getPreferredSize());

        tanqueCombustivel.setLayout(new GridLayout(0, 1));
        liveLevelProgressBar.setVisible(true);
        tanqueCombustivel.add(liveLevelProgressBar);

        liveLevelProgressBar.setFont(normal);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;

        add(tanqueCombustivel, gridConstraints);

        abastecerJButton = new JButton("abastecer");

        appyStyleToAbastecerJButton();

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        gridConstraints.insets = new Insets(10, 0, 0, 0);

        abastecerJButton.setFont(normal);

        abastecerJButton.addActionListener((ActionEvent e) -> {

            if (!isAbastecendo()) {

                new Thread(() -> {

                    setAbastecendo(true);

                    List<DialogoWindowUI> dialogos = DialogoPane.getTodosDialogosDesteCombustivel(nomeCombustivel);

                    dialogos.stream().map((dialogo) -> {

                        dialogo.getDialogo().getCancelarButton().doClick();
                        return dialogo;

                    }).forEachOrdered((dialogo) -> {
                        System.err.println("DIALOGO " + dialogo.getNaoMostrarEsseDialogoDeNovoCheckBox().getName() + " CANCELADO @ TanqueCombustivelUI " + nomeCombustivel);
                    });

                    appyStyleToAbastecerJButton();

                    int sleep = 100;

                    while (true) {

                        appyStyleToAbastecerJButton();

                        try {

                            if (modelo.getNivel(nomeCombustivel) + MAX_CAPACIDADE / 100 > MAX_CAPACIDADE) {
                                modelo.abastecer(nomeCombustivel, MAX_CAPACIDADE - modelo.getNivel(nomeCombustivel));
                                break;
                            }

                            modelo.abastecer(nomeCombustivel, MAX_CAPACIDADE / 100);

                            Thread.sleep(sleep);

                        } catch (InterruptedException ex) {
                            Logger.getLogger(TanqueCombustivelUI.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (NivelCriticoDeCombustivelException ex) {
                            Logger.getLogger(TanqueCombustivelUI.class.getName()).log(Level.SEVERE, null, ex);
                        }

                    }

                    modelo.getuIDelegator().notificarTanqueCheioBombasDesteCombustivel(nomeCombustivel);

                    setAbastecendo(false);

                    appyStyleToAbastecerJButton();

                    System.err.println("ABASTECEU TANQUE " + nomeCombustivel + " " + getNivel() + "/" + modelo.getNivel(nomeCombustivel));

                }).start();

            }
        });

        add(abastecerJButton, gridConstraints);

        setToolTipText(nomeCombustivel + ", NÍVEL ATUAL " + String.format("%.2f", nivel) + ", CAPACIDADE " + String.format("%.2f", MAX_CAPACIDADE) + (nomeCombustivel.equals("GNV") ? " METROS CÚBICOS" : " LITROS"));

        doStartUp();

        setNivel(nivel);

    }

    public void setNivel(float nivel) {

        if (nivel < 0) {
            nivel = 0;
        }

        if (nivel > MAX_CAPACIDADE) {
            nivel = MAX_CAPACIDADE;
        }

        this.nivel = nivel;

        //Impossível divisao por zero aqui, pq já foi garantido MAX_CAPACIDADE > 0, no construtor.
        //Igualmente, foi garantido ser nivel >= 0 e nivel <= MAX_CAPACIDADE e, então, nivelAsPorcentagem >= 0 e nivelAsPorcentagem <= 100 
        float nivelAsPorcentagem = (nivel / MAX_CAPACIDADE) * 100;

        try {

            liveLevelProgressBar.setSize((int) tanqueCombustivelWidth - 6, (int) (tanqueCombustivelHeight * (1 - (nivelAsPorcentagem / 100))));

            liveLevelProgressBar.setString(nomeCombustivel.toUpperCase() + ", (" + String.format("%.2f", getNivel()) + "/" + String.format("%.2f", MAX_CAPACIDADE) + ")");

            applyStyleToTanqueCombustivel();
            appyStyleToAbastecerJButton();

        } catch (Exception e) {
        }

    }

    private void applyStyleToTanqueCombustivel() {

        new Thread(() -> {
            if (getNivelAsPorcentagem() >= 95) {
                liveLevelProgressBar.setIndeterminate(true);
            } else {
                liveLevelProgressBar.setIndeterminate(false);
            }
            
            if (!isAbastecendo()) {
                
                if (getNivelAsPorcentagem() > NIVEL_ALTO) {
                    tanqueCombustivel.setBackground(Color.GREEN);
                }
                
                if (getNivelAsPorcentagem() > NIVEL_MEDIO && getNivelAsPorcentagem() <= NIVEL_ALTO) {
                    tanqueCombustivel.setBackground(Color.ORANGE);
                }
                
                if (getNivelAsPorcentagem() >= NIVEL_BAIXO && getNivelAsPorcentagem() <= NIVEL_MEDIO) {
                    tanqueCombustivel.setBackground(Color.RED);
                }
                
            } else {
                
                tanqueCombustivel.setBackground(Color.GREEN);
                
            }
            
            setToolTipText(nomeCombustivel + ", NÍVEL ATUAL " + String.format("%.2f", nivel) + ", CAPACIDADE " + String.format("%.2f", MAX_CAPACIDADE) + (nomeCombustivel.equals("GNV") ? " METROS CÚBICOS" : " LITROS"));
        }).start();
        
    }

    private void appyStyleToAbastecerJButton() {

        if (isAbastecendo()) {
            abastecerJButton.setToolTipText("ABASTECENDO TANQUE " + nomeCombustivel + ", " + String.format("%.2f", nivel) + "/" + String.format("%.2f", MAX_CAPACIDADE) + (nomeCombustivel.equals("GNV") ? " METROS CÚBICOS" : " LITROS"));
            abastecerJButton.setEnabled(false);
        } else {

            if (getNivelAsPorcentagem() > 96.0f) {
                abastecerJButton.setEnabled(false);
                abastecerJButton.setToolTipText("TANQUE " + nomeCombustivel + " CHEIO : " + String.format("%.2f", MAX_CAPACIDADE) + (nomeCombustivel.equals("GNV") ? " METROS CÚBICOS" : " LITROS"));
            } else {
                abastecerJButton.setEnabled(true);
                abastecerJButton.setToolTipText("CLIQUE PARA ABASTECER TANQUE " + nomeCombustivel + ", NÍVEL ATUAL " + String.format("%.2f", nivel) + "/" + String.format("%.2f", MAX_CAPACIDADE) + (nomeCombustivel.equals("GNV") ? " METROS CÚBICOS" : " LITROS"));
            }

        }

    }

    public JProgressBar getLiveLevelProgressBar() {
        return liveLevelProgressBar;
    }

    public float getNivel() {
        return nivel;
    }

    public float getNivelAsPorcentagem() {
        return (getNivel() / MAX_CAPACIDADE) * 100;
    }

    public void setNomeCombustivelENiveisHeader() {
        headerTitleJLabel.setText(nomeCombustivel.toUpperCase() + ", " + String.format("%.2f", getNivel()) + ", " + String.format("%.2f", MAX_CAPACIDADE));
    }

    public void setHeader(String msg) {
        headerTitleJLabel.setText(msg);
    }

    private void doStartUp() {

        setStarting(true);

        TanqueCombustivelUI tanque = this;

        Thread t = new Thread(() -> {
            try {

                int sleep = 15;

                setAbastecendo(false);

                while (true) {

                    if (getNivel() - MAX_CAPACIDADE / 100 < 0) {
                        setNivel(0);
                        break;
                    }

                    setNivel(getNivel() - MAX_CAPACIDADE / 100);

                    Thread.sleep(sleep);

                }

                Thread.sleep(500);

                setAbastecendo(true);

                while (true) {

                    if (getNivel() + MAX_CAPACIDADE / 100 > MAX_CAPACIDADE) {
                        setNivel(MAX_CAPACIDADE);
                        break;
                    }

                    setNivel(getNivel() + MAX_CAPACIDADE / 100);

                    Thread.sleep(sleep);

                }

                setNivel(nivelInicial);

                setAbastecendo(false);
                setStarting(false);

            } catch (InterruptedException ex) {
            } catch (Exception e) {

            }
        });

        t.start();

    }

    public boolean isAbastecendo() {
        return abastecendo;
    }

    public void setAbastecendo(boolean abastecendo) {
        this.abastecendo = abastecendo;
    }

    public boolean isStarting() {
        return starting;
    }

    public void setStarting(boolean starting) {
        this.starting = starting;
    }

    public String getNomeCombustivel() {
        return nomeCombustivel;
    }

    public JButton getAbastecerJButton() {
        return abastecerJButton;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + Objects.hashCode(this.nomeCombustivel);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TanqueCombustivelUI other = (TanqueCombustivelUI) obj;
        if (!Objects.equals(this.nomeCombustivel, other.nomeCombustivel)) {
            return false;
        }
        return true;
    }
    
    
    

}
