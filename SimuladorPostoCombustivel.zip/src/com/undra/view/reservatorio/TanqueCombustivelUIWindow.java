/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.undra.view.reservatorio;

import com.undra.delegator.UIDelegator;
import java.awt.Color;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * 
 * @author alexandre
 */
public class TanqueCombustivelUIWindow extends JFrame{

    
    public static void main(String[] args) {
        new TanqueCombustivelUIWindow().configureAndShow();
    }
    
    
    TanqueCombustivelUI tanqueCombustivelUI;
    
    public void configureAndShow() {
        
        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("GTK+".equals(info.getName())) {
                    try {
                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                        Logger.getLogger(TanqueCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    break;
                }
            }

        
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }

        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setTitle(getClass().getSimpleName() + " App");

        getContentPane().setBackground(new Color(255, 255, 192));

        setResizable(false);

        
        setUndecorated(false);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        pack();

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

        setVisible(true);
        
        
        while(tanqueCombustivelUI.isStarting()){}
        
        
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        tanqueCombustivelUI.setNivel(tanqueCombustivelUI.getNivel()-10000/100);
        
        

    }

    private void placeComponentsAtFrame() {
        
        
//        tanqueCombustivelUI = new TanqueCombustivelUI("GASOLINA", 10000f, 10000f, new UIDelegator());
        
        getContentPane().add(tanqueCombustivelUI);
        
        
        
//        getContentPane().setLayout(new GridBagLayout());
//        GridBagConstraints gridConstraints;
        
    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }

    
}
