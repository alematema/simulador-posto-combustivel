package com.undra.view.reservatorio;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.reservatorio.Reservatorio;
import com.undra.view.interfaces.UI;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Collection;
import javax.swing.JPanel;

/**
 * UI do reservatório dos combustíveis do posto.
 *
 * @author alexandre
 */
public class ReservatorioCombustiveisUI extends JPanel implements UI {

    //o reservatório tem quatro tanques
    private TanqueCombustivelUI tanqueCombustivelUI0;
    private TanqueCombustivelUI tanqueCombustivelUI1;
    private TanqueCombustivelUI tanqueCombustivelUI2;
    private TanqueCombustivelUI tanqueCombustivelUI3;

    private Collection<TanqueCombustivelUI> reservatorioUI;
    private Reservatorio modelo;

    private UIDelegator uIDelegator;
    private ModelDelegator modelDelegator;

    public ReservatorioCombustiveisUI(Reservatorio modelo) {

        if (modelo == null) {
            throw new NullPointerException("O reservatório não pode ser null !!!");
        }
        if (modelo.getTanques() == null) {
            throw new NullPointerException("Os tanques não podem ser null !!!");
        }

        if (modelo.getuIDelegator() == null) {
            throw new NullPointerException("O UIDelegator não pode ser null !!!");
        }
        if (modelo.getModelDelegator() == null) {
            throw new NullPointerException("O ModelDelegator não pode ser null !!!");
        }

        this.modelo = modelo;
        this.uIDelegator = modelo.getuIDelegator();
        this.modelDelegator = modelo.getModelDelegator();

        reservatorioUI = new ArrayList();

        registrarNoUIDelegator();

        construirReservatorioUI();

    }

    private void registrarNoUIDelegator() {
        uIDelegator.registrarUI(this);
    }

    private void construirReservatorioUI() {

        String[] tanques = new String[modelo.getTanques().keySet().size()];
        int i = 0;
        for (String tanque : modelo.getTanques().keySet()) {

            tanques[i] = tanque;
            i++;

        }

        GridBagConstraints gridConstraints;

        setPreferredSize(new Dimension(Toolkit.getDefaultToolkit().getScreenSize().width, Toolkit.getDefaultToolkit().getScreenSize().height - 20));
        setBackground(new Color(192, 192, 255));
        setLayout(new GridBagLayout());
        setBackground(Color.WHITE);

        gridConstraints = new GridBagConstraints();

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(10, 15, 0, 15);

        //comeca com tanque cheio de cada combustivel
        tanqueCombustivelUI0 = new TanqueCombustivelUI(tanques[0], modelo.getNivel(tanques[0]), modelo.getNIVEL_MAX_TANQUE(), modelo);

        add(tanqueCombustivelUI0, gridConstraints);

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(10, 15, 0, 15);

        //comeca com tanque cheio de cada combustivel
        tanqueCombustivelUI1 = new TanqueCombustivelUI(tanques[1], modelo.getNivel(tanques[1]), modelo.getNIVEL_MAX_TANQUE(), modelo);

        add(tanqueCombustivelUI1, gridConstraints);

        gridConstraints.gridx = 2;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(10, 15, 0, 15);

        //comeca com tanque cheio de cada combustivel
        tanqueCombustivelUI2 = new TanqueCombustivelUI(tanques[2], modelo.getNivel(tanques[2]), modelo.getNIVEL_MAX_TANQUE(), modelo);

        add(tanqueCombustivelUI2, gridConstraints);

        gridConstraints.gridx = 3;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(10, 15, 0, 15);

        //comeca com tanque cheio de cada combustivel
        tanqueCombustivelUI3 = new TanqueCombustivelUI(tanques[3], modelo.getNivel(tanques[3]), modelo.getNIVEL_MAX_TANQUE(), modelo);

        add(tanqueCombustivelUI3, gridConstraints);

        reservatorioUI.add(tanqueCombustivelUI0);
        reservatorioUI.add(tanqueCombustivelUI1);
        reservatorioUI.add(tanqueCombustivelUI2);
        reservatorioUI.add(tanqueCombustivelUI3);

    }

    public void setNivel(Combustivel combustivel, float nivel) {

        reservatorioUI.stream().filter((tanque) -> (tanque.getNomeCombustivel().equals(combustivel.getNome()))).forEachOrdered((tanque) -> {
            tanque.setNivel(nivel);
        });

    }

    public void setNivel(String combustivel, float nivel) {

        reservatorioUI.stream().filter((tanque) -> (tanque.getNomeCombustivel().equals(combustivel))).forEachOrdered((tanque) -> {
            tanque.setNivel(nivel);
        });


    }

    public void setNivelTanques(float nivel) {

        reservatorioUI.forEach((tanque) -> {
            tanque.setNivel(nivel);
        });

    }

    public void setNivelTanques() {

        reservatorioUI.forEach((tanque) -> {
            tanque.setNivel(tanque.getNivel());
        });

    }

    public Collection<TanqueCombustivelUI> getReservatorioUI() {
        return reservatorioUI;
    }
    
    public TanqueCombustivelUI getTanqueUI(String nomeCombustivel){
        
        TanqueCombustivelUI tanqueCombustivelUI = null;
        
        for(TanqueCombustivelUI tanqueUI : reservatorioUI){
            if(tanqueUI.getNomeCombustivel().equals(nomeCombustivel)){
                tanqueCombustivelUI = tanqueUI;
                break;
            }
        }
        
        return tanqueCombustivelUI;
        
    }

    public Reservatorio getModelo() {
        return modelo;
    }

    public void apagarLuz() {
        setBackground(Color.BLACK);
    }

    public void acenderLuz() {
        setBackground(Color.WHITE);
    }

}
