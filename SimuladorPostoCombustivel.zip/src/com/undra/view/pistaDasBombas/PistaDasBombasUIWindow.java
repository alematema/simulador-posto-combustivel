package com.undra.view.pistaDasBombas;

import com.undra.delegator.UIDelegator;
import com.undra.view.interfaces.FadableAndRaisableUI;
import com.undra.menu.MyMenuBar;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.combustivel.bomba.excetion.BombaCombustivelException;
import com.undra.modelo.contabilidade.Caixa;
import com.undra.view.interfaces.UI;
import java.awt.HeadlessException;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 * Window da pista das bombas combustivel
 *
 * @author alexandre
 */
public class PistaDasBombasUIWindow extends JFrame implements FadableAndRaisableUI , UI{

    private List<BombaCombustivel> modeloPistaBombasCombustivel = new ArrayList();
    private final List<Caixa> modeloCaixas;
    private PistaDasBombasUI pistaDasBombasUI;
    private final UIDelegator uIDelegator;

    public PistaDasBombasUIWindow(List<BombaCombustivel> modeloPistaBombasCombustivel, List<Caixa> modeloCaixas, UIDelegator uIDelegator) throws HeadlessException {

        this.modeloPistaBombasCombustivel = modeloPistaBombasCombustivel;
        this.modeloCaixas = modeloCaixas;
        this.uIDelegator = uIDelegator;

    }

    public void configureAndShow() {

        configure();

        setVisible(true);

    }

    public void configure() {
        
        uIDelegator.registrarUI(this);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setTitle("Pista das Bombas - SIMULADOR POSTO COMBUSTÍVEL");
        
        setResizable(false);

        setUndecorated(true);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        pack();

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

    }

    private void placeComponentsAtFrame() {

        try {
            pistaDasBombasUI = new PistaDasBombasUI(modeloPistaBombasCombustivel, modeloCaixas, uIDelegator);
            getContentPane().add(pistaDasBombasUI);
        } catch (BombaCombustivelException ex) {
            Logger.getLogger(PistaDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }

    public PistaDasBombasUI getPistaDasBombasUI() {
        return pistaDasBombasUI;
    }

    @Override
    public void fade() {

        new Thread(() -> {
            for (int i = 100; i > 1; i--) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(PistaDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            setVisible(false);
            transferFocus();

        }).start();

    }

    @Override
    public void raise() {

        new Thread(() -> {
            
            ((MyMenuBar)getJMenuBar()).setVisibleInvisibleMenus();
            ((MyMenuBar)getJMenuBar()).reconfigureMenuIniciarParaAbrirPosto();
            
            setOpacity(0.11f);
            setVisible(true);
            float opacity1 = 1.0f;
            for (int i = 0; i < 100; i++) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(PistaDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            requestFocus();
            
            
            
        }).start();

    }

    @Override
    public String toString() {
        return "PistaDasBombasUIWindow UI";
    }

}
