/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.bombacombustivel;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.combustivel.bomba.excetion.BombaCombustivelException;
import com.undra.modelo.combustivel.reservatorio.Reservatorio;
import com.undra.modelo.combustivel.reservatorio.exception.NivelCriticoDeCombustivelException;
import com.undra.modelo.combustivel.reservatorio.exception.ReservatorioExeption;
import com.undra.modelo.contabilidade.Caixa;
import com.undra.modelo.contabilidade.exception.CaixaException;
import com.undra.modelo.postocombustivel.PostoCombustivel;
import com.undra.modelo.postocombustivel.PostoGasolinaException;
import com.undra.modelo.recursoshumanos.Frentista;
import com.undra.modelo.recursoshumanos.exception.RecursosHumanosException;
import com.undra.view.controleRemoto.bombaCombustivel.ControleRemotoBombaCombustivelUI;
import java.awt.Color;
import java.awt.HeadlessException;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.security.SecureRandom;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author alexandre
 */
public final class BombaCombustivelUIWindow extends JFrame {

    public volatile boolean ready = false; // volatile forces memory barrier crossing

    public BombaCombustivelUI bombaCombustivelUI;

    Reservatorio reservatorio;
    PostoCombustivel postoCombustivel;
    UIDelegator uIDelegator;

    public void go() {

        ready = true;
        
        SecureRandom random = new SecureRandom();

        new Thread(() -> {
            try {
                
                int i = 0;
                
                Frentista frentista = new Frentista(5, "JOLIE", "398274987", "9073495");
                frentista.setCaminhoPraFoto("/imagens/jolie.jpg");
                while (i < 100000) {
                    
                    while (!bombaCombustivelUI.isIsLigada()) {
                        System.out.println();
                    }
                    
                    while (!bombaCombustivelUI.getModelo().isLiberada()) {
                    }
                    
//                    Thread.sleep(25*random.nextInt(300));
                    Thread.sleep(200);
                    
                    frentista.abasteceComABomba(bombaCombustivelUI.getModelo()).aQuantidade(100*random.nextFloat()+1);
                    
                    while (bombaCombustivelUI.getModelo().isLiberada()) {
                    }
                    
                    i++;
                }
                
            } catch (InterruptedException ex) {
                Logger.getLogger(BombaCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
            }
        }).start();

    }

    public static void main(String[] args) throws HeadlessException, ReservatorioExeption, CaixaException, BombaCombustivelException, PostoGasolinaException, RecursosHumanosException {

        BombaCombustivelUIWindow app;

        try {

            app = new BombaCombustivelUIWindow(new UIDelegator());
            app.configureAndShow();

            int i = 0;

            Frentista frentista = new Frentista(5, "JOLIE", "398274987", "9073495");
            frentista.setCaminhoPraFoto("/imagens/jolie.jpg");
            while (i < 100) {

                while (!app.bombaCombustivelUI.isIsLigada()) {
                    System.out.println();
                }

                while (!app.bombaCombustivelUI.getModelo().isLiberada()) {
                }

                Thread.sleep(200);

                frentista.abasteceComABomba(app.bombaCombustivelUI.getModelo()).aQuantidade(6f);

                while (app.bombaCombustivelUI.getModelo().isLiberada()) {
                }

                i++;
            }

        } catch (DisplayDigitalException ex) {
            Logger.getLogger(BombaCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(BombaCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public BombaCombustivelUIWindow(BombaCombustivel bombaCombustivel, UIDelegator uIDelegator) throws HeadlessException, ReservatorioExeption, CaixaException, BombaCombustivelException, PostoGasolinaException, RecursosHumanosException, DisplayDigitalException {

        bombaCombustivelUI = new BombaCombustivelUI(bombaCombustivel, uIDelegator);
        configureAndShow();
//        go();
    }

    public BombaCombustivelUIWindow(UIDelegator uIDelegator) throws HeadlessException, ReservatorioExeption, CaixaException, BombaCombustivelException, PostoGasolinaException, RecursosHumanosException, DisplayDigitalException {

        reservatorio = new Reservatorio(130f, 800f);
        Combustivel gasolina = new Combustivel(Combustivel.GASOLINA, 3.34f, Combustivel.LITRO);
        try {
            reservatorio.abastecer(gasolina, reservatorio.getNIVEL_MAX_TANQUE());
        } catch (NivelCriticoDeCombustivelException ex) {
            Logger.getLogger(BombaCombustivelUIWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
        Caixa caixa = new Caixa();
        ModelDelegator businessDelegator = new ModelDelegator(reservatorio, caixa);
        caixa.setDelegator(businessDelegator);

        bombaCombustivelUI = new BombaCombustivelUI(new BombaCombustivel(gasolina, 1, businessDelegator), uIDelegator);
        configureAndShow();
//        go();
    }

    public BombaCombustivelUIWindow() throws HeadlessException, ReservatorioExeption, CaixaException, BombaCombustivelException, PostoGasolinaException, RecursosHumanosException, DisplayDigitalException {

    }

    public void configureAndShow() {

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }

        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setTitle(getClass().getSimpleName() + " App");

        getContentPane().setBackground(new Color(255, 255, 192));

        setResizable(false);

        setUndecorated(true);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }

        });

        placeComponentsAtFrame();

        pack();
        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());
        
        
        setOpacity(0);
        setVisible(true);

        new Thread(() -> {
            float opacity1 = 1.0f;
            for (int i = 0; i < 100; i++) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ControleRemotoBombaCombustivelUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }).start();

    }

    private void placeComponentsAtFrame() {
        getContentPane().add(bombaCombustivelUI);
    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }

}
