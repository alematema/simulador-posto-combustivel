package com.undra.view.bombacombustivel;

import com.undra.view.interfaces.FadableAndRaisableUI;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.HeadlessException;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Window do abastecimento manual
 *
 * @author alexandre
 */
public final class AbastecimentoManualWindow extends JFrame implements FadableAndRaisableUI {

    private BombaCombustivelUI modeloUI;
    private DisplayDigital outPut;

    private JPanel abastecimentoManualHeader;
    private JCheckBox onOff;
    private JLabel tituloDaJanelaLabel;
    private final Font headerFont = new Font("Ubuntu", Font.BOLD, 12);
    private final ImageIcon offIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/off.24x12.png"));
    private String tituloDaJanela;

    public Point clickPoint;

    private AbastecimentoManualUI abastecimentoManualUI;

    public AbastecimentoManualWindow(BombaCombustivelUI modeloUI) throws HeadlessException {

        if (modeloUI == null) {
            throw new NullPointerException("A bomba UI não pode ser null !!! ");
        }

        this.modeloUI = modeloUI;

        configure();
    }

    public void configure() {
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
            }

        });

        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

        getContentPane().setBackground(Color.WHITE);

        setResizable(false);

        setUndecorated(true);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        //centralizes the frame
        setBounds(modeloUI.getBounds().x + 300, modeloUI.getBounds().y + 100, getWidth(), getHeight());

        pack();

        setVisible(false);

    }

    public void configureAndShow() {

        configure();

        setVisible(true);

    }

    private void placeComponentsAtFrame() {

        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints;

        abastecimentoManualHeader = new JPanel();
        abastecimentoManualHeader.setPreferredSize(new Dimension(290, 23));
        abastecimentoManualHeader.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1, true));
        abastecimentoManualHeader.setBackground(Color.WHITE);

        gridConstraints = new GridBagConstraints();

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.NORTH;
        gridConstraints.insets = new Insets(0, 0, 0, 0);

        add(abastecimentoManualHeader, gridConstraints);

        abastecimentoManualHeader.setLayout(new GridBagLayout());

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;

        onOff = new JCheckBox();
        onOff.setToolTipText("CLIQUE PARA FECHAR");

        onOff.setSelected(false);
        onOff.setIcon(offIcon);
        onOff.setPreferredSize(new Dimension(26, 25));
        gridConstraints.insets = new Insets(0, 0, 0, this.getPreferredSize().width - onOff.getPreferredSize().width);

        onOff.addActionListener(this::onOffButtonActionPerformed);

        abastecimentoManualHeader.add(onOff, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(0, 30, 0, 5);
        tituloDaJanela = "ASSISTENTE DE ABASTECIMENTO MANUAL";
        tituloDaJanelaLabel = new JLabel(tituloDaJanela);
        tituloDaJanelaLabel.setForeground(Color.BLACK);
        tituloDaJanelaLabel.setFont(headerFont);
        abastecimentoManualHeader.add(tituloDaJanelaLabel, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        abastecimentoManualUI = new AbastecimentoManualUI(this);
        add(abastecimentoManualUI, gridConstraints);

    }

    public void setTituloDaJanela(String tituloDaJanela) {
        this.tituloDaJanela = tituloDaJanela;
        tituloDaJanelaLabel.setText(tituloDaJanela);
    }

    public void setOutPut(DisplayDigital outPut) {
        if (outPut == null) {
            throw new NullPointerException("O display digital não pode ser null !!! ");
        }
        this.outPut = outPut;
    }

    public DisplayDigital getOutPut() {
        return outPut;
    }

    @Override
    public void fade() {

        abastecimentoManualUI.isRaised = false;

        new Thread(() -> {

            for (int i = 100; i > 1; i--) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(AbastecimentoManualWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            setVisible(false);

        }).start();
    }

    @Override
    public void raise() {

        abastecimentoManualUI.isRaised = true;

        new Thread(() -> {

            setOpacity(0.11f);
            setLocation(clickPoint.x + 65, clickPoint.y - 40);
            abastecimentoManualUI.getPlaceHolderFrentistaFoto().setIcon(abastecimentoManualUI.semFotoIcon);
            abastecimentoManualUI.getNomeFrentistaJLabel().setText("FRENTISTA ?");
            if (!abastecimentoManualUI.isSetandoValorCombustivel) {
                abastecimentoManualUI.getOKButton().setEnabled(false);
            }else{
                abastecimentoManualUI.getOKButton().setEnabled(true);
            }
            abastecimentoManualUI.getTecladoManual().getVirgula().setEnabled(true);
            setAlwaysOnTop(true);
            setVisible(true);
            float opacity1 = 1.0f;

            for (int i = 0; i < 100; i++) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(AbastecimentoManualWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            requestFocus();

        }).start();
    }

    private void onOffButtonActionPerformed(ActionEvent e) {
        abastecimentoManualUI.getCancelarButton().doClick();
    }

    public BombaCombustivelUI getModeloUI() {
        return modeloUI;
    }

    public AbastecimentoManualUI getAbastecimentoManualUI() {
        return abastecimentoManualUI;
    }

    @Override
    public String toString() {
        return "";
    }

}
