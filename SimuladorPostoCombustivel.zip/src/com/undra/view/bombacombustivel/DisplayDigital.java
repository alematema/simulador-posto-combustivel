package com.undra.view.bombacombustivel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.text.DecimalFormat;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

/**
 * Uma classe que simula um multi display digital (5 led displays de 7
 * segmentos)<br>
 * Suporta algarismos de 0 a 9.<br>
 * Mínimo valor representado 0,00<br>
 * Máximo valor representado 999,99
 *
 * @author alexandre
 */
public class DisplayDigital extends JPanel {

    public static float MAX_VALUE = 999.99f;
    public static float MIN_VALUE = 0f;

    private LedDisplay diplaay0;//o primeiro display 
    private LedDisplay display1;//o segundo display 
    private LedDisplay display2;//o terceiro display 
    private LedDisplay display3;//o quarto displa 
    private LedDisplay display4;//o quinto display 

    private float valor;//o valor que este display digital irá representar
    private String nome;//um nome para o display
    private Byte tamanho;//o tamanho do display

    private Color displayBackgroundColor = Color.BLACK;//a cor de fundo do display
    private Color ledColor = Color.GREEN;//a cor do led

    private final Color displayLedBorder = new Color(192, 192, 255);

    private final DecimalFormat decimalFormatLeft = new DecimalFormat("000");
    private final DecimalFormat decimalFormatRight = new DecimalFormat("00");

    public DisplayDigital() throws DisplayDigitalException {
        displayBackgroundColor = Color.BLACK;
        ledColor = Color.GREEN;
        valor = 0f;
        configure();

    }

    public DisplayDigital(float valor) throws DisplayDigitalException {

        if (valor < MIN_VALUE || valor > MAX_VALUE) {
            throw new IllegalArgumentException("O valor deve ser maior ou igual do que " + MIN_VALUE + " e menor igual do que " + MAX_VALUE);
        }
        this.valor = valor;
        displayBackgroundColor = Color.BLACK;
        ledColor = Color.GREEN;
        configure();

    }

    public DisplayDigital(float valor, Color displayBackgroundColor, Color ledColor) {

        if (valor < MIN_VALUE || valor > MAX_VALUE) {
            throw new IllegalArgumentException("O valor deve ser maior ou igual do que " + MIN_VALUE + " e menor igual do que " + MAX_VALUE + ". Valor passado=" + valor);
        }

        this.valor = valor;

        if (displayBackgroundColor == null || ledColor == null) {
            displayBackgroundColor = Color.BLACK;
            ledColor = Color.GREEN;
        } else {
            this.displayBackgroundColor = displayBackgroundColor;
            this.ledColor = ledColor;
        }

        configure();

    }

    public DisplayDigital(float valor, Color displayBackgroundColor, Color ledColor, String nome) {

        this(valor, displayBackgroundColor, ledColor);

        if (nome == null) {
            this.nome = getClass().getSimpleName();
        } else {
            this.nome = nome;
        }

    }

    public DisplayDigital(byte tamanho, float valor, Color displayBackgroundColor, Color ledColor, String nome) {

        this(valor, displayBackgroundColor, ledColor, nome);

        this.tamanho = tamanho;

    }

    private void configure() {

        setLayout(new GridBagLayout());

        GridBagConstraints gridConstraints = new GridBagConstraints();

        setPreferredSize(new Dimension(140, 37));

        setBackground(displayBackgroundColor);
        setBorder(BorderFactory.createLineBorder(displayLedBorder, 2, true));

        if (tamanho == null) {
            tamanho = LedDisplay.SMALL;
        }

        gridConstraints.gridy = 0;
        gridConstraints.gridx = 0;
        gridConstraints.insets = new Insets(1, 0, 1, 0);
        diplaay0 = new LedDisplay(tamanho, displayBackgroundColor, ledColor);
        add(diplaay0, gridConstraints);

        gridConstraints.gridy = 0;
        gridConstraints.gridx = 1;
        gridConstraints.insets = new Insets(1, 0, 1, 0);
        display1 = new LedDisplay(tamanho, displayBackgroundColor, ledColor);
        add(display1, gridConstraints);

        gridConstraints.gridy = 0;
        gridConstraints.gridx = 2;
        gridConstraints.insets = new Insets(1, 0, 1, 0);
        display2 = new LedDisplay(tamanho, displayBackgroundColor, ledColor);
        add(display2, gridConstraints);

        gridConstraints.gridy = 0;
        gridConstraints.gridx = 3;
        gridConstraints.insets = new Insets(1, 7, 1, 0);
        display3 = new LedDisplay(tamanho, displayBackgroundColor, ledColor);
        add(display3, gridConstraints);

        gridConstraints.gridy = 0;
        gridConstraints.gridx = 4;
        gridConstraints.insets = new Insets(1, 0, 1, 0);
        display4 = new LedDisplay(tamanho, displayBackgroundColor, ledColor);
        add(display4, gridConstraints);

        setValor(valor);

    }

    public void setValor(float valor) {

        if (valor < MIN_VALUE || valor > MAX_VALUE) {
            throw new IllegalArgumentException("O valor deve ser maior ou igual do que " + MIN_VALUE + " e menor igual do que " + MAX_VALUE + ". Valor passado=" + valor);
        }

        String valorAsString = Float.toString(valor);

        String[] valorParseado;
        valorParseado = valorAsString.replaceAll("\\.", ",").split(",");

        try {

            valorParseado[0] = decimalFormatLeft.format(Integer.parseInt(valorParseado[0]));

            diplaay0.setValue((byte) Integer.parseInt(String.valueOf(valorParseado[0].charAt(0))));
            display1.setValue((byte) Integer.parseInt(String.valueOf(valorParseado[0].charAt(1))));
            display2.setValue((byte) Integer.parseInt(String.valueOf(valorParseado[0].charAt(2))));

            display3.setValue((byte) Integer.parseInt(String.valueOf(valorParseado[1].charAt(0))));
            try {
                display4.setValue((byte) Integer.parseInt(String.valueOf(valorParseado[1].charAt(1))));
            } catch (java.lang.StringIndexOutOfBoundsException e) {
                display4.setValue((byte) 0);
            }

        } catch (NumberFormatException e) {
            System.err.println("DisplayDigital : Erro ao parsear : Formato numérico inesperado");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
            //ok : é esperada essa out of bounds
        } catch (Exception e) {
            System.err.println("Algo excepcional ocorreu em DisplayDigital.setValor(" + valor + ") : " + e.getLocalizedMessage());
        } finally {

            this.valor = valor;
        }

    }

    public float getValor() {
        return valor;
    }

    public Color getDisplayBackgroundColor() {
        return displayBackgroundColor;
    }

    public void setDisplayBackgroundColor(Color displayBackgroundColor) {
        this.displayBackgroundColor = displayBackgroundColor;
        setBackground(displayBackgroundColor);
        this.diplaay0.setDisplayBackGroundColor(displayBackgroundColor);
        this.display1.setDisplayBackGroundColor(displayBackgroundColor);
        this.display2.setDisplayBackGroundColor(displayBackgroundColor);
        this.display3.setDisplayBackGroundColor(displayBackgroundColor);
        this.display4.setDisplayBackGroundColor(displayBackgroundColor);
    }

    public Color getLedColor() {
        return ledColor;
    }

    public void setLedColor(Color ledColor) {
        this.ledColor = ledColor;
        this.diplaay0.setLedColor(ledColor);
        this.display1.setLedColor(ledColor);
        this.display2.setLedColor(ledColor);
        this.display3.setLedColor(ledColor);
        this.display4.setLedColor(ledColor);
    }

    public float getMAX_VALUE() {
        return MAX_VALUE;
    }

    public String getNome() {
        return nome;
    }

    @Override
    public String toString() {
        return nome + " " + ", valor " + valor;
    }

    public static void main(String[] args) throws DisplayDigitalException {

        DisplayDigital displayDigital = new DisplayDigital();

        for (int i = (int) DisplayDigital.MIN_VALUE; i <= DisplayDigital.MAX_VALUE; i++) {
            displayDigital.setValor(i);
        }

        float delta = 0f;

        //testa setting de todos os valores possiveis q o display pode assumir
        for (int i = 0; i <= 99999; i++) {

            if (i % 100 < 10) {

                displayDigital.setValor(Float.parseFloat(i / 100 + ".0" + i % 100));

            } else {

                displayDigital.setValor(Float.parseFloat(i / 100 + "." + i % 100));

            }

            System.err.println(displayDigital.getValor());

        }
    }
}
