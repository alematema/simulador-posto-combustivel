package com.undra.view.bombacombustivel;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.dialogo.DialogoPane;
import com.undra.dialogo.DialogoWindowUI;
import com.undra.menu.MyMenuBar;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.recursoshumanos.Funcionario;
import com.undra.view.interfaces.UI;
import com.undra.view.pistaDasBombas.PistaDasBombasUIWindow;
import com.undra.view.reservatorio.ReservatorioCombustiveisUIWindow;
import com.undra.view.reservatorio.TanqueCombustivelUI;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingWorker;
import javax.swing.Timer;
import javax.swing.border.Border;

/**
 * A UI da bomba de combustível do simulador de posto de combustível
 *
 * @author alexandre
 */
public final class BombaCombustivelUI extends JPanel implements UI {

    static public String INFORMADO_DINHEIRO = "DISPLAY_QUANTIDADE_DINHEIRO";
    static public String INFORMADO_COMBUSTIVEL = "DISPLAY_QUANTIDADE_COMBUSTIVEL";

    private final UIDelegator uIDelegator;

    private final BombaCombustivel bombaCombustivel;
    private final ModelDelegator modelDelegator;
    private final Combustivel combustivel;
    private final int id;

    private AbastecimentoManualWindow abastecimentoManualWindow;

    private JPanel bombaHeader;
    private JCheckBox onOff;
    private JLabel headerLabel;
    private JLabel wifiLabel;
    private JPanel bombaDisplaysEConsoleBomba;
    private ImagePanel fotoFrentista;
    private JLabel bombaTotalAbastecido;
    private JLabel bombaTotalAbastecidoTexto;
    private JLabel bombaLitros;
    private JLabel bombaLitrosTexto;
    private JLabel bombaNomeFrentistaAbastecendo;
    private JLabel bombaNomeFrentistaAbastecendoTexto;
    private JLabel moedaLabel;
    private JLabel moedaLabel0;
    private JLabel totalAPagarLabel0;
    private JLabel totalAPagarLabel;
    private JLabel totalUnidades;
    private JPanel bombaRodape;
    private JLabel labelConsole;
    private JLabel labelNomeFrentita;
    private DisplayDigital displayTotalDinheiro;
    private DisplayDigital displayTotalUnidadeCombustivel;
    private DisplayDigital displayValorUnidadeCombustivel;

    private final ImageIcon offIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/off.24x12.png"));
    private final ImageIcon onIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/on.png"));
    private final ImageIcon grayScaledOffIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/off.grayscale.png"));
    private final int ratio = 20;
    private final ImageIcon bombaReadyStateIcon = new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bombaOk.png")).getImage().getScaledInstance(ratio, ratio, Image.SCALE_REPLICATE));
    private final ImageIcon bombaWaitingStateIcon = new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bombaAdvertencia.png")).getImage().getScaledInstance(28, 22, Image.SCALE_REPLICATE));
    private final ImageIcon bombaBadStateIcon = new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bombaNoVermelho.png")).getImage().getScaledInstance(ratio, ratio, Image.SCALE_REPLICATE));
    private ImageIcon bombaStateIcon;
    private final ImageIcon wifiIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/wifi.gif"));

    private JLabel bombaStateContainer;

    private final Color backgroundColor = new Color(180, 180, 255);
    private final Color bombaLigadaBackGroudColor = new Color(255, 255, 220);
    ;
    private final Color bombaDesligadaColor = Color.DARK_GRAY;
    private final Color bombaDesligadaForeground = Color.WHITE;
    private final Color bombaLigadaForeground = Color.BLACK;

    private final Color bombaDesligadaDisplayBackgroundColor = Color.BLACK;
    private final Color bombaDesligadaLedColor = Color.GRAY;

    private final Color bombaLigadaDisplayBackgroundColor = Color.BLACK;
    private final Color bombaLigadaLedColor = Color.YELLOW;

    private final Color aguardandoCaixaColor = Color.YELLOW;
    private final Color bombaProntaColor = new Color(255, 255, 220);
    private final Color bombaAbastecendoColor = new Color(107, 247, 0);
    private final Color bombaAbastecimentoTerminadoColor = bombaLigadaBackGroudColor;

    private final Font headerFont = new Font(Font.SANS_SERIF, Font.BOLD, 10);
    private final Font consoleFont = new Font("Arial", Font.BOLD, 11);
    private final Border outerBorder = BorderFactory.createLineBorder(Color.BLACK, 3, true);
    private final Border borderBombaDesligada = BorderFactory.createLineBorder(Color.WHITE, 3, true);
    private final Border borderBombaLigada = BorderFactory.createLineBorder(Color.BLACK, 2, true);
    private final Dimension dimension = new Dimension(240, 348);

    private final Timer onOffOscilatorTimer = new Timer(800, this::onOffOscilatorTimerActionPerformed);
    private final Timer bombaStateContainerTimer = new Timer(800, this::bombaStateContainerTimerActionPerformed);

    public volatile boolean isLigada = false;

    private JCheckBox naoMostrarEsseDialogoDeNovoCheckBox;

    volatile private List<DialogoWindowUI> dialogosAbertos = new ArrayList();

    public BombaCombustivelUI(BombaCombustivel bombaCombustivel, UIDelegator uIDelegator) throws DisplayDigitalException {

        if (uIDelegator == null) {
            throw new NullPointerException("A UI delegator não pode ser null !!!");
        }

        if (bombaCombustivel == null) {
            throw new NullPointerException("A bomba de combustível não pode ser null !!!");
        }
        if (bombaCombustivel.getCombustivel() == null) {
            throw new NullPointerException("O combustível não pode ser null !!!");
        }
        if (bombaCombustivel.getModelDelegator() == null) {
            throw new NullPointerException("O delegator não pode ser null !!!");
        }

        this.uIDelegator = uIDelegator;
        modelDelegator = bombaCombustivel.getModelDelegator();
        combustivel = bombaCombustivel.getCombustivel();
        id = bombaCombustivel.getId();

        bombaCombustivel.setUiDelegator(uIDelegator);
        this.bombaCombustivel = bombaCombustivel;

        configure();

        onOffOscilatorTimer.start();

    }

    public void configure() throws DisplayDigitalException {

        uIDelegator.registrarUI(this);

        setBorder(outerBorder);
        setBackground(Color.BLACK);
        setLayout(new GridBagLayout());

        GridBagConstraints gridConstraints;

        bombaHeader = new JPanel();
        bombaHeader.setPreferredSize(new Dimension(230, 22));
        bombaHeader.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1, true));

        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.NORTH;
        gridConstraints.insets = new Insets(0, 0, 5, 0);

        add(bombaHeader, gridConstraints);

        bombaHeader.setLayout(new GridBagLayout());

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.EAST;
        gridConstraints.insets = new Insets(0, 0, 0, 190);

        onOff = new JCheckBox();

        onOff.setSelected(false);
        onOff.setIcon(offIcon);
        onOff.setToolTipText("LIGAR A BOMBA");
        onOff.setName(BombaCombustivel.DESLIGADA);
        onOff.setPreferredSize(new Dimension(26, 20));

        onOff.addActionListener(this::onOffButtonActionPerformed);

        bombaHeader.add(onOff, gridConstraints);
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(0, 0, 0, 60);
        headerLabel = new JLabel("BOMBA" + " " + bombaCombustivel.getId() + ", " + bombaCombustivel.getCombustivel().getNome());
        headerLabel.setFont(headerFont);
        bombaHeader.add(headerLabel, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(0, 210, 0, 0);
        wifiLabel = new JLabel();
        wifiLabel.setIcon(wifiIcon);
        wifiLabel.setPreferredSize(new Dimension(18, 18));
        bombaHeader.add(wifiLabel, gridConstraints);
        wifiLabel.setVisible(false);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        gridConstraints.anchor = GridBagConstraints.NORTH;
        gridConstraints.insets = new Insets(0, 5, 0, 5);

        bombaDisplaysEConsoleBomba = new JPanel();
        bombaDisplaysEConsoleBomba.setPreferredSize(new Dimension(190, 250));
        bombaDisplaysEConsoleBomba.setBackground(bombaDesligadaColor);

        bombaDisplaysEConsoleBomba.setBorder(borderBombaDesligada);

        add(bombaDisplaysEConsoleBomba, gridConstraints);

        bombaDisplaysEConsoleBomba.setLayout(new GridBagLayout());

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(10, 5, 0, 5);

        moedaLabel0 = new JLabel("R$");
        moedaLabel0.setForeground(bombaDesligadaForeground);
        Font displayFont = new Font(consoleFont.getName(), consoleFont.getStyle(), consoleFont.getSize() + 2);
        moedaLabel0.setFont(displayFont);
        bombaDisplaysEConsoleBomba.add(moedaLabel0, gridConstraints);

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(0, 5, 0, 5);

        try {
            abastecimentoManualWindow = new AbastecimentoManualWindow(this);
            abastecimentoManualWindow.configure();
        } catch (Exception e) {
            System.err.println("Algo excepcional aconteceu configurando o AbastecimentoManualWindow " + e.getLocalizedMessage());
        }

        displayTotalDinheiro = new DisplayDigital(0f, bombaDesligadaDisplayBackgroundColor, bombaDesligadaLedColor, BombaCombustivelUI.INFORMADO_DINHEIRO);

        displayTotalDinheiro.setToolTipText("CLIQUE PARA INFORMAR QUANTO EM DINHEIRO");

        displayTotalDinheiro.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {

                if (!getModelo().isLigada()) {

                }

                abastecimentoManualWindow.setOutPut(displayTotalDinheiro);
                abastecimentoManualWindow.clickPoint = e.getLocationOnScreen();

                if (!uIDelegator.isAnyAbastecimentoManualUIRaised()) {
                    if (getModelo().getModelDelegator().alocarBomba(bombaCombustivel)) {
                        abastecimentoManualWindow.getAbastecimentoManualUI().getTecladoManual().getClearButton().doClick();
                        abastecimentoManualWindow.raise();
                    }
                }

            }

        });
        bombaDisplaysEConsoleBomba.add(displayTotalDinheiro, gridConstraints);

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(5, 5, 0, 5);
        totalAPagarLabel0 = new JLabel("TOTAL A PAGAR");
        totalAPagarLabel0.setForeground(bombaDesligadaForeground);
        displayFont = new Font(consoleFont.getName(), consoleFont.getStyle(), consoleFont.getSize());
        totalAPagarLabel0.setFont(displayFont);
        bombaDisplaysEConsoleBomba.add(totalAPagarLabel0, gridConstraints);

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 2;
        gridConstraints.insets = new Insets(10, 5, 0, 5);

        displayTotalUnidadeCombustivel = new DisplayDigital(0f, bombaDesligadaDisplayBackgroundColor, bombaDesligadaLedColor, BombaCombustivelUI.INFORMADO_COMBUSTIVEL);

        displayTotalUnidadeCombustivel.setToolTipText("CLIQUE PARA INFORMAR QUANTO EM LITROS OU METROS CÚBICOS");

        displayTotalUnidadeCombustivel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                abastecimentoManualWindow.setOutPut(displayTotalUnidadeCombustivel);
                abastecimentoManualWindow.clickPoint = e.getLocationOnScreen();

                if (!uIDelegator.isAnyAbastecimentoManualUIRaised()) {
                    if (getModelo().getModelDelegator().alocarBomba(bombaCombustivel)) {
                        abastecimentoManualWindow.getAbastecimentoManualUI().getTecladoManual().getClearButton().doClick();
                        abastecimentoManualWindow.raise();
                    }
                }
            }

        });
        bombaDisplaysEConsoleBomba.add(displayTotalUnidadeCombustivel, gridConstraints);

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 3;
        gridConstraints.insets = new Insets(5, 5, 0, 5);

        String ss = combustivel.getNomeDaUnidade(2f);

        totalUnidades = new JLabel(ss);
        totalUnidades.setForeground(bombaDesligadaForeground);
        displayFont = new Font(consoleFont.getName(), consoleFont.getStyle(), consoleFont.getSize());
        totalUnidades.setFont(displayFont);
        bombaDisplaysEConsoleBomba.add(totalUnidades, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 4;
        gridConstraints.insets = new Insets(10, 5, 0, 5);

        moedaLabel = new JLabel("R$");
        moedaLabel.setForeground(bombaDesligadaForeground);
        displayFont = new Font(consoleFont.getName(), consoleFont.getStyle(), consoleFont.getSize() + 4);
        moedaLabel.setFont(displayFont);
        bombaDisplaysEConsoleBomba.add(moedaLabel, gridConstraints);

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 4;
        gridConstraints.insets = new Insets(0, 5, 0, 5);

        displayValorUnidadeCombustivel = new DisplayDigital(combustivel.getPrecoDaUnidade(), bombaDesligadaDisplayBackgroundColor, bombaDesligadaLedColor);

        displayValorUnidadeCombustivel.setToolTipText("CLIQUE PARA ATUALIZAR VALOR COMBUSTÍVEL");

        displayValorUnidadeCombustivel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                abastecimentoManualWindow.setOutPut(displayValorUnidadeCombustivel);
                abastecimentoManualWindow.clickPoint = e.getLocationOnScreen();

                if (!uIDelegator.isAnyAbastecimentoManualUIRaised()) {

                    if (getModelo().getModelDelegator().alocarBomba(bombaCombustivel)) {

                        abastecimentoManualWindow.getAbastecimentoManualUI().configureParaSetarPreçoCombustivel();
                        abastecimentoManualWindow.raise();

                    }

                }
            }

        });

        bombaDisplaysEConsoleBomba.add(displayValorUnidadeCombustivel, gridConstraints);

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 5;
        gridConstraints.insets = new Insets(5, 0, 0, 5);
        String s = "PREÇO POR " + combustivel.getNomeDaUnidade();
        if (s.length() > 18) {
            s = "PREÇO POR m3";
        }
        totalAPagarLabel = new JLabel(s);
        totalAPagarLabel.setForeground(bombaDesligadaForeground);
        displayFont = new Font(consoleFont.getName(), consoleFont.getStyle(), consoleFont.getSize() + 2);
        totalAPagarLabel.setFont(displayFont);
        bombaDisplaysEConsoleBomba.add(totalAPagarLabel, gridConstraints);

        fotoFrentista = new ImagePanel(new javax.swing.ImageIcon(getClass().getResource("/imagens/buda.png")).getImage());

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 6;
        gridConstraints.insets = new Insets(20, 5, 0, 0);

        fotoFrentista.setPreferredSize(new Dimension(31, 31));
        fotoFrentista.setBackground(bombaLigadaBackGroudColor);
        fotoFrentista.setBorder(borderBombaDesligada);
        fotoFrentista.setVisible(false);
        /**
         * muda imgagem fotoFrentista.setImage(new
         * javax.swing.ImageIcon(getClass().getResource("/imagens/jolie.jpg")).getImage());
         * labelNomeFrentita.setVisible(true);
         * labelNomeFrentita.setBackground(bombaLigadaBackGroudColor);
         * labelNomeFrentita.setForeground(bombaLigadaForeground);
         * labelNomeFrentita.setText("Jolie");
         */

        bombaDisplaysEConsoleBomba.add(fotoFrentista, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 6;
        gridConstraints.insets = new Insets(20, 5, 0, 0);

        bombaStateContainer = new JLabel(bombaReadyStateIcon);
        bombaStateContainer.setPreferredSize(new Dimension(ratio + 5, ratio));
        bombaStateContainer.setVisible(false);

        bombaDisplaysEConsoleBomba.add(bombaStateContainer, gridConstraints);

        labelNomeFrentita = new JLabel("URIÁ MICHAELIN");
        labelNomeFrentita.setFont(headerFont);
        labelNomeFrentita.setBackground(bombaDesligadaColor);
        labelNomeFrentita.setForeground(bombaDesligadaForeground);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 6;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(20, 10, 0, 10);

        bombaDisplaysEConsoleBomba.add(labelNomeFrentita, gridConstraints);
        labelNomeFrentita.setVisible(false);

        bombaRodape = new JPanel();

        bombaRodape.setPreferredSize(new Dimension(210, 30));
        bombaRodape.setBackground(bombaDesligadaColor);
        bombaRodape.setBorder(borderBombaDesligada);
        bombaRodape.setLayout(new GridBagLayout());
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        gridConstraints.anchor = GridBagConstraints.SOUTH;
        gridConstraints.insets = new Insets(0, 0, 0, 0);

        add(bombaRodape, gridConstraints);

        bombaRodape.setLayout(new GridBagLayout());

        labelConsole = new JLabel();
        labelConsole.setBackground(bombaDesligadaColor);
        labelConsole.setFont(consoleFont);
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.CENTER;
        gridConstraints.insets = new Insets(0, 0, 0, 0);
        bombaRodape.add(labelConsole, gridConstraints);
        labelConsole.setForeground(bombaDesligadaForeground);
        labelConsole.setText("DESLIGADA");

    }

    private void onOffOscilatorTimerActionPerformed(ActionEvent e) {

        if (onOff.getName().equals(BombaCombustivel.DESLIGADA)) {
            if (onOff.getIcon().equals(offIcon)) {
                onOff.setIcon(grayScaledOffIcon);
            } else if (onOff.getIcon().equals(grayScaledOffIcon)) {
                onOff.setIcon(offIcon);
            }
        }

    }

    private void bombaStateContainerTimerActionPerformed(ActionEvent e) {

        labelConsole.setForeground(bombaLigadaForeground);

        switch (getEstado()) {

            case BombaCombustivel.AGUARDANDO_O_CAIXA:
            case BombaCombustivel.EM_ESPERA:

                if (bombaStateContainer.getIcon().equals(bombaReadyStateIcon)) {

                    bombaStateContainer.setIcon(bombaWaitingStateIcon);

                } else {

                    bombaStateContainer.setIcon(bombaReadyStateIcon);

                }

                break;
            case (BombaCombustivel.AGUARDANDO_O_CAIXA_EM_NIVEL_CRITICO_COMBUSTIVEL):

                if (bombaStateContainer.getIcon().equals(bombaBadStateIcon)) {

                    bombaStateContainer.setIcon(bombaWaitingStateIcon);

                } else {

                    bombaStateContainer.setIcon(bombaBadStateIcon);

                }

                break;

            case BombaCombustivel.ABASTECENDO_EM_NIVEL_CRITICO:

                if (bombaStateContainer.getIcon().equals(bombaBadStateIcon)) {

                    bombaStateContainer.setIcon(bombaWaitingStateIcon);

                } else {

                    bombaStateContainer.setIcon(bombaBadStateIcon);

                }

                break;

            case BombaCombustivel.SEM_COMBUSTIVEL:

                if (bombaStateContainer.isVisible()) {
                    bombaStateContainer.setVisible(false);
                } else {
                    bombaStateContainer.setVisible(false);
                }

                break;
            default:
                break;
        }

    }

    private String getEstado() {
        return bombaCombustivel.getEstado();
    }

    public JCheckBox getOnOff() {
        return onOff;
    }

    public JLabel getLabelConsole() {
        return labelConsole;
    }

    public BombaCombustivel getModelo() {
        return bombaCombustivel;
    }

    public void setQuantidadeAbastecida(float quantidade) {
        displayTotalUnidadeCombustivel.setValor(quantidade);
    }

    public void setPrecoUnidadeCombustivel(float quantidade) {
        displayValorUnidadeCombustivel.setValor(quantidade);
    }

    public void setTotalAbastecido(float total) {
        displayTotalDinheiro.setValor(total);
    }

    public boolean isIsLigada() {
        return bombaCombustivel.isLigada();
    }

    private boolean estaTentandoDesligarABombaQueAindaEstaDesligada() {
        return bombaCombustivel.getEstado().equals(BombaCombustivel.DESLIGADA);
    }

    public void desligarBomba() {

        String toString = toString();

        SwingWorker worker = new SwingWorker() {

            @Override
            protected Object doInBackground() throws Exception {

                setBackground(Color.BLACK);
                bombaStateContainer.setVisible(false);
                bombaStateContainerTimer.stop();
                while (bombaStateContainerTimer.isRunning()) {
                    bombaRodape.setBackground(bombaLigadaBackGroudColor);
                    bombaStateContainer.setVisible(false);
                }
                bombaRodape.setBackground(bombaLigadaBackGroudColor);

                bombaCombustivel.desligar();

                while (bombaCombustivel.isLigada()) {
                }
                wifiLabel.setVisible(false);

                bombaStateContainer.setVisible(false);
                bombaRodape.setBackground(bombaDesligadaColor);
                labelConsole.setBackground(bombaDesligadaColor);
                labelConsole.setForeground(Color.white);

                bombaDisplaysEConsoleBomba.setBackground(bombaDesligadaColor);

                bombaDisplaysEConsoleBomba.setBorder(borderBombaDesligada);
                bombaRodape.setBorder(borderBombaDesligada);

                moedaLabel0.setForeground(bombaDesligadaForeground);
                moedaLabel.setForeground(bombaDesligadaForeground);
                totalAPagarLabel0.setForeground(bombaDesligadaForeground);
                totalAPagarLabel.setForeground(bombaDesligadaForeground);
                totalUnidades.setForeground(bombaDesligadaForeground);
                fotoFrentista.setBackground(bombaDesligadaColor);

                displayTotalDinheiro.setDisplayBackgroundColor(bombaDesligadaDisplayBackgroundColor);
                displayTotalUnidadeCombustivel.setDisplayBackgroundColor(bombaDesligadaDisplayBackgroundColor);
                displayValorUnidadeCombustivel.setDisplayBackgroundColor(bombaDesligadaDisplayBackgroundColor);

                displayTotalDinheiro.setLedColor(bombaDesligadaLedColor);
                displayTotalUnidadeCombustivel.setLedColor(bombaDesligadaLedColor);
                displayValorUnidadeCombustivel.setLedColor(bombaDesligadaLedColor);

                onOff.setIcon(offIcon);
                onOff.setToolTipText("LIGAR A BOMBA");
                onOff.setName(BombaCombustivel.DESLIGADA);

                onOffOscilatorTimer.start();

                bombaStateContainerTimer.stop();
                while (bombaStateContainerTimer.isRunning()) {

                }
                bombaRodape.setBackground(bombaDesligadaColor);
                labelConsole.setBackground(bombaDesligadaColor);
                labelConsole.setForeground(Color.white);

                labelConsole.setText(bombaCombustivel.getEstado());
                displayTotalDinheiro.setValor(0f);
                displayTotalUnidadeCombustivel.setValor(0f);

                setBackground(Color.BLACK);
                System.out.println("[" + toString + "] : DESligada");

                onOff.setEnabled(true);

                isLigada = false;

                return null;
            }
        };

        worker.execute();
    }

    private boolean estaTentandoLigarABombaQueAindaEstaLigada() {
        return bombaCombustivel.getEstado().equals(BombaCombustivel.PRONTA);
    }

    public void ligarBomba() {

        String toString = toString();

        SwingWorker worker = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {

                labelConsole.setForeground(Color.WHITE);
                setBackground(backgroundColor);

                bombaCombustivel.ligar();

                while (!bombaCombustivel.isLigada()) {
                }
                bombaStateContainer.setVisible(true);
                if (bombaCombustivel.isSemCombustivel() || bombaCombustivel.isEmEstadoCritico()) {
                    bombaStateContainer.setIcon(bombaBadStateIcon);
                } else {
                    bombaStateContainer.setIcon(bombaReadyStateIcon);
                }

                labelConsole.setForeground(Color.BLACK);
                labelConsole.setText(bombaCombustivel.getEstado());
                onOff.setIcon(onIcon);

                bombaRodape.setBackground(bombaLigadaBackGroudColor);

                bombaDisplaysEConsoleBomba.setBackground(bombaLigadaBackGroudColor);
                bombaDisplaysEConsoleBomba.setBorder(borderBombaLigada);

                moedaLabel0.setForeground(bombaLigadaForeground);
                moedaLabel.setForeground(bombaLigadaForeground);
                totalAPagarLabel0.setForeground(bombaLigadaForeground);
                totalAPagarLabel.setForeground(bombaLigadaForeground);
                totalUnidades.setForeground(bombaLigadaForeground);
                fotoFrentista.setBackground(bombaLigadaBackGroudColor);

                displayTotalDinheiro.setLedColor(bombaLigadaLedColor);
                displayTotalUnidadeCombustivel.setLedColor(bombaLigadaLedColor);
                displayValorUnidadeCombustivel.setLedColor(bombaLigadaLedColor);
                displayTotalDinheiro.setDisplayBackgroundColor(bombaLigadaDisplayBackgroundColor);
                displayTotalUnidadeCombustivel.setDisplayBackgroundColor(bombaLigadaDisplayBackgroundColor);
                displayValorUnidadeCombustivel.setDisplayBackgroundColor(bombaLigadaDisplayBackgroundColor);
                displayValorUnidadeCombustivel.setValor(0f);
                displayTotalUnidadeCombustivel.setValor(0f);
                displayValorUnidadeCombustivel.setValor(combustivel.getPrecoDaUnidade());

                bombaRodape.setBorder(borderBombaLigada);

                onOff.setToolTipText("DESLIGAR A BOMBA");
                onOff.setName(BombaCombustivel.LIGADA);

                onOffOscilatorTimer.stop();
                System.out.println("[" + toString + "] : ligada");

                onOff.setEnabled(true);

                isLigada = true;

                return null;
            }
        };

        worker.execute();
    }

    private void onOffButtonActionPerformed(ActionEvent e) {

        if (((JCheckBox) e.getSource()).isSelected()) {

            onOff.setEnabled(false);

            ligarBomba();

        } else {

            onOff.setEnabled(false);

            if (estaAbastecendo()) {

                if (JOptionPane.showConfirmDialog(this, "A bomba está abastecendo. Deseja mesmo desligá-la?", "Advertência ao Desligar", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

                    desligarBomba();

                } else {

                    onOff.setEnabled(true);

                }

            } else {

                desligarBomba();

            }

        }
    }

    public void ligarDisplayTotalDinheiro() {
        displayTotalDinheiro.setDisplayBackgroundColor(bombaLigadaDisplayBackgroundColor);
        displayTotalDinheiro.setLedColor(bombaLigadaLedColor);
    }

    public void desLigarDisplayTotalDinheiro() {
        displayTotalDinheiro.setDisplayBackgroundColor(bombaDesligadaDisplayBackgroundColor);
        displayTotalDinheiro.setLedColor(bombaDesligadaLedColor);
    }

    public void ligarDisplayTotalCombustivel() {
        displayTotalUnidadeCombustivel.setDisplayBackgroundColor(bombaLigadaDisplayBackgroundColor);
        displayTotalUnidadeCombustivel.setLedColor(bombaLigadaLedColor);
    }

    public void desLigarDisplayTotalCombustivel() {
        displayTotalUnidadeCombustivel.setDisplayBackgroundColor(bombaDesligadaDisplayBackgroundColor);
        displayTotalUnidadeCombustivel.setLedColor(bombaDesligadaLedColor);
    }

    public void ligarDisplayPrecoUnidadeCombustivel() {
        displayValorUnidadeCombustivel.setDisplayBackgroundColor(bombaLigadaDisplayBackgroundColor);
        displayValorUnidadeCombustivel.setLedColor(bombaLigadaLedColor);
    }

    public void desLigarDisplayPrecoUnidadeCombustivel() {
        displayValorUnidadeCombustivel.setDisplayBackgroundColor(bombaDesligadaDisplayBackgroundColor);
        displayValorUnidadeCombustivel.setLedColor(bombaDesligadaLedColor);
    }

    public void piscar() {

        if (isIsLigada()) {

            bombaStateContainerTimer.start();

        }

    }

    public void pararPiscarOkWarningBomba() {

        bombaStateContainerTimer.stop();
        while (bombaStateContainerTimer.isRunning()) {
        }

        bombaStateContainer.setIcon(bombaReadyStateIcon);

    }

    public void pararPulsarBombaBadWaitingState() {

        bombaStateContainerTimer.stop();
        while (bombaStateContainerTimer.isRunning()) {
        }

        bombaStateContainer.setIcon(bombaBadStateIcon);
    }

    private boolean estaAbastecendo() {
        return bombaCombustivel.isAbastecendo();
    }

    public void atualizarBombaStateContainer() {
        bombaStateContainer.setVisible(true);
        if (bombaCombustivel.isSemCombustivel() || bombaCombustivel.isEmEstadoCritico() || bombaCombustivel.naoAbasteceuEmNivelCritico() || bombaCombustivel.isAguardandoEncherReservatorio()) {
            bombaStateContainer.setIcon(bombaBadStateIcon);
        } else {
            bombaStateContainer.setIcon(bombaReadyStateIcon);
        }
    }

    public void setFrentista(Funcionario frentista) {

        //muda imgagem do frentista que está abastecendo com esta bomba
        try {
            fotoFrentista.setImage(new javax.swing.ImageIcon(getClass().getResource(frentista.getCaminhoPraFoto())).getImage());
            fotoFrentista.setVisible(true);
            labelNomeFrentita.setVisible(true);
            labelNomeFrentita.setBackground(bombaLigadaBackGroudColor);
            labelNomeFrentita.setForeground(bombaLigadaForeground);
            labelNomeFrentita.setText(frentista.getNome() + " (frentista)");
        } catch (Exception e) {
            System.err.println("com.undra.view.bombacombustivel.BombaCombustivelUI.setFrentista() " + e.getLocalizedMessage());
        }

    }

    public void liberarFrentista(Funcionario frentista) {
        //apaga a foto do frentista que estava abastecendo com essa bomba
        fotoFrentista.setVisible(false);
        labelNomeFrentita.setVisible(false);
    }

    public void ajustarConsoleAposPararPiscarConsole() {
        bombaRodape.setBackground(bombaLigadaBackGroudColor);
    }

    public void setConsoleBackgroundBombaAbastecendo() {
        bombaRodape.setBackground(bombaAbastecendoColor);
    }

    public void setConsoleBackgroundAbastecimentoTerminado() {
        bombaRodape.setBackground(bombaAbastecimentoTerminadoColor);
    }

    public void pulsarBombaOkWaitingState() {
        bombaStateContainer.setIcon(bombaReadyStateIcon);
        bombaStateContainerTimer.start();
    }

    public int confirmarAbastecerEmNivelCritico(String message) {

        new Thread(() -> {

            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                Logger.getLogger(MyMenuBar.class.getName()).log(Level.SEVERE, null, ex);
            }

            ReservatorioCombustiveisUIWindow window = ((ReservatorioCombustiveisUIWindow) getModelo().getUIDelegator().getUI(ReservatorioCombustiveisUIWindow.class));
            window.getReservatorioCombustiveisUI().setNivelTanques();

        }).start();

        Runnable runnable = () -> {

            uIDelegator.getBombasUIDesteCombustivel(getModelo().getCombustivel()).forEach((bombaUI) -> {
                bombaUI.getModelo().notificarAbastecerEmNivelCritico = false;
            });

            List<DialogoWindowUI> dialogos = DialogoPane.getTodosDialogosDesteCombustivel(getModelo().getCombustivel().getNome());

            dialogos.stream().map((dialogo) -> {

                dialogo.getDialogo().getCancelarButton().doClick();
                return dialogo;

            }).forEachOrdered((dialogo) -> {
                System.err.println("DIALOGO " + dialogo.getNaoMostrarEsseDialogoDeNovoCheckBox().getName() + " CANCELADO @ BombaCombustivelUI " + getModelo().toStringShorter());
            });

            PistaDasBombasUIWindow pistaDasBombasUIWindow = (PistaDasBombasUIWindow) uIDelegator.getUI(PistaDasBombasUIWindow.class);

            ((MyMenuBar) pistaDasBombasUIWindow.getJMenuBar()).reservatorioMenuItem.doClick();

            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(BombaCombustivelUI.class.getName()).log(Level.SEVERE, null, ex);
            }

            ReservatorioCombustiveisUIWindow reservatorioCombustiveisUIWindow = (ReservatorioCombustiveisUIWindow) uIDelegator.getUI(ReservatorioCombustiveisUIWindow.class);

            TanqueCombustivelUI tanqueUI = reservatorioCombustiveisUIWindow.getReservatorioCombustiveisUI().getTanqueUI(getModelo().getCombustivel().getNome());

            tanqueUI.getAbastecerJButton().doClick();

            while (tanqueUI.getNivelAsPorcentagem() <= 98f) {
            }

            ((MyMenuBar) reservatorioCombustiveisUIWindow.getJMenuBar()).pistaDasBombasMenuItem.doClick();

        };

        return DialogoPane.showDialogoConfirmarOutras(getModelo().toStringShorter() + " - AVISO DE NÍVEL CRÍTICO DE COMBUSTÍVEL", message, "reservatório", runnable, newNaoMostrarMaisODialogoCheckBox(), new Point(getBounds().x, getBounds().y));

    }

    private JCheckBox newNaoMostrarMaisODialogoCheckBox() {

        naoMostrarEsseDialogoDeNovoCheckBox = new JCheckBox();
        naoMostrarEsseDialogoDeNovoCheckBox.setSelected(false);
        naoMostrarEsseDialogoDeNovoCheckBox.setName(getModelo().getCombustivel().getNome());

        naoMostrarEsseDialogoDeNovoCheckBox.addActionListener((ActionEvent e) -> {

            if (naoMostrarEsseDialogoDeNovoCheckBox.isSelected()) {

                getModelo().notificarAbastecerEmNivelCritico = false;

            } else {

                getModelo().notificarAbastecerEmNivelCritico = true;

            }
        });

        naoMostrarEsseDialogoDeNovoCheckBox.setSelected(false);

        return naoMostrarEsseDialogoDeNovoCheckBox;
    }

    public void setVisibleStateBombaContainer(boolean b) {
        bombaStateContainer.setVisible(b);
    }

    public void pulsarBombaBadWaitingState() {
        bombaStateContainer.setIcon(bombaBadStateIcon);
        bombaStateContainerTimer.start();
    }

    public void notificarDesligamentoDaBombaSemCombustivel() {

        List<DialogoWindowUI> dialogos = DialogoPane.getTodosDialogosDesteCombustivel(getModelo().getCombustivel().getNome());

        dialogos.stream().map((dialogo) -> {

            dialogo.getDialogo().getCancelarButton().doClick();
            return dialogo;

        }).forEachOrdered((dialogo) -> {
            System.err.println("DIALOGO " + dialogo.getNaoMostrarEsseDialogoDeNovoCheckBox().getName() + " CANCELADO @ desligando bomba sem combustivel " + getModelo().toStringShorter());
        });

        JOptionPane.showConfirmDialog(null, "Esta bomba está sem combustível...\nAbasteça o reservatório.\nEla será DESLIGADA", getModelo().toStringShorter() + " SEM COMBUSTÍVEL", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE);
        getOnOff().doClick();

    }

    public void setWifiOn() {
        wifiLabel.setVisible(true);
    }

    public void setWifiOff() {
        wifiLabel.setVisible(false);
    }

    public JPanel getHeader() {
        return bombaHeader;
    }

    public UIDelegator getuIDelegator() {
        return uIDelegator;
    }

    public DisplayDigital getDisplayValorUnidadeCombustivel() {
        return displayValorUnidadeCombustivel;
    }

    public DisplayDigital getDisplayTotalDinheiro() {
        return displayTotalDinheiro;
    }

    public DisplayDigital getDisplayTotalUnidadeCombustivel() {
        return displayTotalUnidadeCombustivel;
    }

    @Override
    public String toString() {
        return "BombaCombustivel UI " + combustivel.getNome() + ", id=" + id;
    }

    public ModelDelegator getModelDelegator() {
        return modelDelegator;
    }

}

class ImagePanel extends JPanel {

    private Image img;

    public ImagePanel(Image img) {
        this.img = img;
    }

    @Override
    public void paintComponent(Graphics g) {
        g.drawImage(img, 0, 0, null);
    }

    public void setImage(Image img) {
        this.img = img;
        repaint();
    }

}
