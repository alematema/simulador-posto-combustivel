package com.undra.view.relatorios;

import com.undra.view.interfaces.FadableAndRaisableUI;
import com.undra.menu.MenuNavigator;
import com.undra.view.caixa.CaixaUI;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;

/**
 * Window do relatorio deste caixa.
 *
 * @author alexandre
 */
public final class RelatorioCaixaWindow extends JFrame implements FadableAndRaisableUI {

    private final CaixaUI ui;
    private RelatorioCaixaUI caixaRelatorioUI;

    //hacking para evitar mais dq uma chamada a um codigo durante windowClosing evento
    private final int numero_maximo_de_chamadas = 1;
    private int numero_de_chamadas = 0;

    public boolean wasOpenedFromMenu = false;

    public RelatorioCaixaWindow(CaixaUI ui) {
        this.ui = ui;
        configure();
    }

    public void configure() {

        addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent evt) {

                System.err.print("windowClosing EVENT , this window ");

                if (wasOpenedFromMenu) {
                    System.err.print(" WAS opened from menu, ");
                    if (numero_de_chamadas < numero_maximo_de_chamadas) {
                        System.err.println(" and will call MenuNavigator to navigate to " + MenuNavigator.getLastFrom());
                        MenuNavigator.setTo(MenuNavigator.getLastFrom());
                        MenuNavigator.navigate();
                        numero_de_chamadas++;
                    } else {
                        System.err.println(" but DIDNT CALL MenuNavigator");

                    }

                } else {
                    System.err.println(" WAS NOT OPENED FROM MENU ");
                }

                wasOpenedFromMenu = false;
                numero_de_chamadas = 0;

            }

        });

        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

        setTitle("RELATÓRIO DO CAIXA " + ui.getModelo().getId());

        setResizable(false);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        pack();

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2 + 60, getWidth(), getHeight());

    }

    public void configureAndShow() {
        configure();
        setVisible(true);

    }

    private void placeComponentsAtFrame() {

        caixaRelatorioUI = new RelatorioCaixaUI(ui);

        caixaRelatorioUI.limparEEAtualizar();

        getContentPane().add(caixaRelatorioUI);

    }

    public void limparEAtualizar() {
        caixaRelatorioUI.limparEEAtualizar();
    }

    public void atualizar() {
        caixaRelatorioUI.atualizar();
    }

    public RelatorioCaixaUI getCaixaRelatorioUI() {
        return caixaRelatorioUI;
    }

    @Override
    public void fade() {
        // faz nada
    }

    @Override
    public void raise() {
        // faz nada
    }

}
