package com.undra.view.relatorios;

import com.undra.delegator.UIDelegator;
import com.undra.modelo.recursoshumanos.Frentista;
import com.undra.view.interfaces.UI;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.text.DecimalFormat;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * UI do relatorio dos abastecimentos de um frentista
 *
 * @author alexandre
 */
public class RelatorioFrentistaAbastecimentosUI extends JPanel implements UI {

    private int id;
    private Frentista frentista;

    private JLabel quantoAbasteceuDeGNV;
    private JLabel quantoAbasteceuDeEtanol;
    private JLabel quantoAbasteceuDeGasolina;
    private JLabel quantoAbasteceuDeDiesel;

    private JLabel totalValorGeradoAbastecendo;
    private JLabel totalTempoAbastecendo;

    private UIDelegator uIDelegator;

    public RelatorioFrentistaAbastecimentosUI(Frentista frentista, UIDelegator uIDelegator) {

        if (frentista == null) {
            throw new NullPointerException("O frentista não pode ser null !!! ");
        }
        if (uIDelegator == null) {
            throw new NullPointerException("O UIDelegator não pode ser null !!! ");
        }

        this.frentista = frentista;
        this.uIDelegator = uIDelegator;

        id = frentista.getId();

        configure();

    }

    private void configure() {

        uIDelegator.registrarUI(this);

        Font font = new Font("Ubuntu", Font.BOLD, 16);

        setPreferredSize(new Dimension(950, 400));

        setBackground(Color.WHITE);

        setLayout(new GridBagLayout());

        GridBagConstraints gridConstraints;

        gridConstraints = new GridBagConstraints();

        JPanel fotoENomePanel = new JPanel(new GridBagLayout());
        fotoENomePanel.setBackground(this.getBackground());
        fotoENomePanel.setPreferredSize(new Dimension(this.getPreferredSize().width, 50));
       

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;

        ImageIcon icon = new ImageIcon(getClass().getResource(frentista.getCaminhoPraFoto()));
        Image scaleImage = icon.getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT);

        JLabel foto = new JLabel(new javax.swing.ImageIcon(scaleImage));
        foto.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY,3,true));

        fotoENomePanel.add(foto, gridConstraints);

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(0, 30, 0, 0);

        JLabel nome = new JLabel(frentista.getNome());
        nome.setFont(font);

        fotoENomePanel.add(nome, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.NORTH;
        gridConstraints.insets = new Insets(15, 10, 0, 720);

        add(fotoENomePanel, gridConstraints);
        
        
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(25, 30, 0, 0);
        gridConstraints.anchor = GridBagConstraints.WEST;
        totalTempoAbastecendo = new JLabel();
        totalTempoAbastecendo.setFont(font);
        totalTempoAbastecendo.setForeground(Color.BLUE);
        add(totalTempoAbastecendo, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        gridConstraints.insets = new Insets(30, 30, 0, 0);
        gridConstraints.anchor = GridBagConstraints.WEST;
        quantoAbasteceuDeGNV = new JLabel();
        quantoAbasteceuDeGNV.setFont(font);
        quantoAbasteceuDeGNV.setForeground(Color.BLUE);
        add(quantoAbasteceuDeGNV, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 3;
        gridConstraints.insets = new Insets(10, 30, 0, 0);
        gridConstraints.anchor = GridBagConstraints.WEST;
        quantoAbasteceuDeEtanol = new JLabel();
        quantoAbasteceuDeEtanol.setFont(font);
        quantoAbasteceuDeEtanol.setForeground(Color.BLUE);
        add(quantoAbasteceuDeEtanol, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 4;
        gridConstraints.insets = new Insets(10, 30, 0, 0);
        gridConstraints.anchor = GridBagConstraints.WEST;
        quantoAbasteceuDeGasolina = new JLabel();
        quantoAbasteceuDeGasolina.setFont(font);
        quantoAbasteceuDeGasolina.setForeground(Color.BLUE);
        add(quantoAbasteceuDeGasolina, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 5;
        gridConstraints.insets = new Insets(10, 30, 0, 0);
        gridConstraints.anchor = GridBagConstraints.WEST;
        quantoAbasteceuDeDiesel = new JLabel();
        quantoAbasteceuDeDiesel.setFont(font);
        quantoAbasteceuDeDiesel.setForeground(Color.BLUE);
        add(quantoAbasteceuDeDiesel, gridConstraints);
        
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 6;
        gridConstraints.insets = new Insets(10, 30, 0, 0);
        gridConstraints.anchor = GridBagConstraints.WEST;
        add(new JLabel("____________________________________________________________________________________________________________"), gridConstraints);

       
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 7;
        gridConstraints.insets = new Insets(30, 30, 10, 0);
        gridConstraints.anchor = GridBagConstraints.WEST;
        totalValorGeradoAbastecendo = new JLabel();
        totalValorGeradoAbastecendo.setFont(font);
        totalValorGeradoAbastecendo.setForeground(Color.BLUE);
        add(totalValorGeradoAbastecendo, gridConstraints);
        
        atualizarRelatorioDoFrentista();
    }

    

    public void atualizarRelatorioDoFrentista() {
        
        totalTempoAbastecendo.setText("TRABALHOU "+ getHMS(frentista.getTotalTempoAbastecendo())+ " e abasteceu " + String.format("%.2f", frentista.getTotalQuantoAbasteceu()) +" litro(s) e/ou m3, assim distribuídos ");
        
        quantoAbasteceuDeGNV.setText("       "+ String.format("%.2f", frentista.getQuantoAbasteceuDeGNV()) +      " m3,       GNV, " + frentista.getQuantosAbatecimentosGNV() + " abastecimentos.");
        quantoAbasteceuDeEtanol.setText("       "+String.format("%.2f", frentista.getQuantoAbasteceuDeEtanol()) +   " litro(s), ETANOL, " + frentista.getQuantosAbatecimentosEtanol() + " abastecimentos.");
        quantoAbasteceuDeGasolina.setText("       "+String.format("%.2f", frentista.getQuantoAbasteceuDeGasolina()) + " litro(s), GASOLINA, " + frentista.getQuantosAbatecimentosGasolina() + " abastecimentos.");
        quantoAbasteceuDeDiesel.setText("       "+String.format("%.2f", frentista.getQuantoAbasteceuDeDiesel()) +   " litro(s), DIESEL, " + frentista.getQuantosAbatecimentosDiesel() + " abastecimentos.");
   
        totalValorGeradoAbastecendo.setText("VENDEU R$ " + String.format("%.2f", frentista.getTotalValorGeradoAbastecendo()));
        
    }

    public Frentista getFrentista() {
        return frentista;
    }
    
    
    private String getHMS(long  tempoTrabalhado) {

        long tms = tempoTrabalhado;

        int h;
        int m;
        int s;
        double t;
        t = tms / 1000.0;
        // Break time down into hours, minutes, and seconds
        h = (int) (t / 3600);
        m = (int) ((t - h * 3600) / 60);
        s = (int) (t - h * 3600 - m * 60);

        // Format time as string
        return new DecimalFormat("00").format(h) + ":" + new DecimalFormat("00").format(m) + ":" + new DecimalFormat("00").format(s);
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final RelatorioFrentistaAbastecimentosUI other = (RelatorioFrentistaAbastecimentosUI) obj;
        return this.id == other.id;
    }
    
    
    
    
    @Override
    public String toString() {
        return "Relatorio Frentista Abastecimentos UI : " + frentista.getNome() + " " + frentista.getId();
    }

}
