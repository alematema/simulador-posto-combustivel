package com.undra.view.relatorios;

import com.undra.modelo.contabilidade.Caixa;
import com.undra.view.caixa.CaixaUI;
import com.undra.view.interfaces.UI;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

/**
 * UI do relatorio do caixa
 * @author alexandre
 */
public class RelatorioCaixaUI extends JPanel implements UI{

    private final CaixaUI caixaUi;
    private final Caixa modelo;
    private final CaixaUI relatorioUI;//reaproveita CaixaUI
    

    public RelatorioCaixaUI(CaixaUI ui) {
        this.caixaUi = ui;
        this.modelo = this.caixaUi.getModelo();
        relatorioUI = new CaixaUI();
        configure();
    }

    private void configure() {
        
        add(relatorioUI);
        setBorder(BorderFactory.createLineBorder(Color.BLACK,6,true));
        setBackground(Color.BLACK);
        setPreferredSize(new Dimension(565, 600));
        
    }
    
   public void limparEEAtualizar(){
       
       relatorioUI.limparEAtualizar("");
       atualizar();
       
   } 
    
   public void atualizar(){
       
       //SUBTOTAIS POR TIPO PAGAMENTO
       relatorioUI.escreverNoConsole("RECEBIDOS, "+caixaUi.getModelo().getPagamentos().size()+" pagamentos"+"\n\n");
       relatorioUI.escreverNoConsole("      DINHEIRO, R$"+String.format("%.2f",caixaUi.getModelo().getTotalRecebidoEmDinheiro())+ " - "+caixaUi.getModelo().getQuantosPgtosRecebidosEmDinheiro()+" pgtos"+"\n");
       relatorioUI.escreverNoConsole("      CHEQUE, R$"+String.format("%.2f",caixaUi.getModelo().getTotalRecebidoEmCheque())+ " - "+caixaUi.getModelo().getQuantosPgtosRecebidosEmCheque()+" pgtos"+"\n");
       relatorioUI.escreverNoConsole("      CARTÃO DÉBITO , R$"+String.format("%.2f",caixaUi.getModelo().getTotalRecebidoEmCartaoDebito())+ " - "+caixaUi.getModelo().getQuantosPgtosRecebidosEmCartaoDebito()+" pgtos"+"\n");
       relatorioUI.escreverNoConsole("      CARTÃO CRÉDITO, R$"+String.format("%.2f",caixaUi.getModelo().getTotalRecebidoEmCartaoCredito())+ " - "+caixaUi.getModelo().getQuantosPgtosRecebidosEmCartaoCredito()+" pgtos"+"\n");
       relatorioUI.escreverNoConsole("      OUTROS , R$"+String.format("%.2f",caixaUi.getModelo().getTotalRecebidoEmOutros())+ " - "+caixaUi.getModelo().getQuantosPgtosRecebidosEmOutros()+" pgtos"+"\n\n");
       relatorioUI.escreverNoConsole("TOTAL , R$"+String.format("%.2f",caixaUi.getModelo().getTotalRecebido())+"\n");
       relatorioUI.escreverNoConsole("---------------------------------------------------------------------------------------------------\n\n\n");
       
       //SUBTOTAIS POR COMBUSTÍVEL
       relatorioUI.escreverNoConsole("      VENDIDOS "+String.format("%.2f",caixaUi.getModelo().getQuantoAbasteceuDeGNV())+     " m3       de GNV - "+caixaUi.getModelo().getQuantosAbatecimentosGNV() +" abastecimento(s)"+"\n");
       relatorioUI.escreverNoConsole("      VENDIDOS "+String.format("%.2f",caixaUi.getModelo().getQuantoAbasteceuDeEtanol())+  " litro(s) de ETANOL - "+caixaUi.getModelo().getQuantosAbatecimentosEtanol()+" abastecimento(s)"+"\n");
       relatorioUI.escreverNoConsole("      VENDIDOS "+String.format("%.2f",caixaUi.getModelo().getQuantoAbasteceuDeGasolina())+" litro(s) de GASOLINA - "+caixaUi.getModelo().getQuantosAbatecimentosGasolina() +" abastecimento(s)"+"\n");
       relatorioUI.escreverNoConsole("      VENDIDOS "+String.format("%.2f",caixaUi.getModelo().getQuantoAbasteceuDeDiesel())+" litro(s) de DIESEL - "+caixaUi.getModelo().getQuantosAbatecimentosDiesel()+" abastecimento(s)"+"\n\n");
       relatorioUI.escreverNoConsole("TOTAL COMBUSTÍVEL, "+String.format("%.2f",caixaUi.getModelo().getTotalQuantoAbasteceu())+" litro(s) e/ou metro(s) cúbico(s)"+"\n");
   }
   
   public void clear(){
       relatorioUI.limparEAtualizar("");
   }

    public CaixaUI getRelatorioUI() {
        return relatorioUI;
    }
   
   
    
}
