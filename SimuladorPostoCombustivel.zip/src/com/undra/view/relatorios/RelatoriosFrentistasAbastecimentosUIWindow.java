/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.relatorios;

import com.undra.delegator.UIDelegator;
import com.undra.view.interfaces.FadableAndRaisableUI;
import com.undra.modelo.recursoshumanos.Frentista;
import com.undra.view.interfaces.UI;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * Window dos Relatorios de abastecimentos dos frentistas
 *
 * @author alexandre
 */
public class RelatoriosFrentistasAbastecimentosUIWindow extends JFrame implements UI, FadableAndRaisableUI {

    private JPanel abastecimentosHeader;
    private JCheckBox onOff;
    private JLabel headerLabel;
    private final Font headerFont = new Font("Ubuntu", Font.BOLD, 14);
    private final ImageIcon offIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/off.24x12.png"));
    private String tituloDaJanela;

    private UIDelegator uIDelegator;
    private Collection<Frentista> frentistas;
    private JTabbedPane frentistasTabbedPane;

    public RelatoriosFrentistasAbastecimentosUIWindow(UIDelegator uIDelegator) {

        if (uIDelegator == null) {
            throw new NullPointerException("O UIDelegator não pode ser null !!! ");
        }

        this.uIDelegator = uIDelegator;

        frentistas = new ArrayList();

        frentistasTabbedPane = new JTabbedPane();

    }

    public void configure() {

        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {

            if ("GTK+".equals(info.getName())) {
                try {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                    Logger.getLogger(RelatoriosFrentistasAbastecimentosUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
                break;

            }
        }

        uIDelegator.registrarUI(this);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }

        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

//        setTitle(getClass().getSimpleName() + " App");

        setResizable(false);

        setUndecorated(true);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        pack();
        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

        fade();
        
    }

    public void configureAndShow() {

        configure();
        
        setVisible(true);
        setOpacity(0.87f);

    }

    private void placeComponentsAtFrame() {

        getContentPane().setBackground(Color.LIGHT_GRAY);

        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints;

        abastecimentosHeader = new JPanel();
        abastecimentosHeader.setPreferredSize(new Dimension(950, 25));
        abastecimentosHeader.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1, true));
        abastecimentosHeader.setBackground(Color.WHITE);

        gridConstraints = new GridBagConstraints();

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.NORTH;
        gridConstraints.insets = new Insets(0, 0, 5, 0);

        add(abastecimentosHeader, gridConstraints);

        abastecimentosHeader.setLayout(new GridBagLayout());

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(5, 0, 5, 900);

        onOff = new JCheckBox();
        onOff.setToolTipText("CLIQUE PARA FECHAR");

        onOff.setSelected(false);
        onOff.setIcon(offIcon);
        onOff.setPreferredSize(new Dimension(26, 20));

        onOff.addActionListener(this::onOffButtonActionPerformed);

        abastecimentosHeader.add(onOff, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(0, 30, 0, 5);
        tituloDaJanela = "RELATÓRIO DOS ABASTECIMENTOS DOS FRENTISTAS";
        headerLabel = new JLabel(tituloDaJanela);
        headerLabel.setForeground(Color.BLACK);
        headerLabel.setFont(headerFont);
        abastecimentosHeader.add(headerLabel, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(15, 25, 30, 0);

        frentistasTabbedPane.setBackground(Color.LIGHT_GRAY);
        frentistasTabbedPane.setPreferredSize(new Dimension(900, 400));
        add(frentistasTabbedPane, gridConstraints);

    }

    public void atualizarRelatorioDoFrentista(Frentista frentista) {

        if (frentista == null) {
            throw new NullPointerException("O frentista não pode ser null !!! ");
        }

        for (Component c : frentistasTabbedPane.getComponents()) {

            if (((RelatorioFrentistaAbastecimentosUI) c).getFrentista().equals(frentista)) {
                ((RelatorioFrentistaAbastecimentosUI) c).atualizarRelatorioDoFrentista();
                break;
            }

        }

    }

    public void addFrentista(Frentista frentista) {

        if (frentista == null) {
            throw new NullPointerException("O frentista não pode ser null !!! ");
        }

        frentistas.add(frentista);

        rebuild();

    }

    public void removeFrentista(Frentista frentista) {

        if (frentista == null) {
            throw new NullPointerException("O frentista não pode ser null !!! ");
        }

        frentistas.remove(frentista);

        rebuild();

    }

    private void rebuild() {

        try {

            frentistasTabbedPane.removeAll();

            frentistas.forEach((frentista) -> {
                frentistasTabbedPane.addTab(frentista.getNome() + " " + frentista.getId(), new javax.swing.ImageIcon(getClass().getResource(frentista.getCaminhoPraFoto())), new RelatorioFrentistaAbastecimentosUI(frentista, uIDelegator));
            });

        } catch (Exception e) {

            System.err.println("Algo deu errado em rebuild windows relatorios frentistas " + e.getLocalizedMessage());

        }

    }

    private void onOffButtonActionPerformed(ActionEvent e) {
        fade();
    }

    private void exitForm(WindowEvent evt) {
//        System.exit(JFrame.NORMAL);
    }

    @Override
    public String toString() {
        return "Relatorios Frentistas Abastecimentos UIWindow UI";
    }

    public static void main(String[] args) {

        RelatoriosFrentistasAbastecimentosUIWindow relatoriosFrentistasAbastecimentosUIWindow = new RelatoriosFrentistasAbastecimentosUIWindow(new UIDelegator());
        relatoriosFrentistasAbastecimentosUIWindow.configureAndShow();
        

//        Frentista f1 = new Frentista(1, "JOLIE", "91273490", "329074", "/imagens/jolie+.jpg");
//        Frentista f2 = new Frentista(2, "FACEBOOK", "908345", "92374095", "/imagens/facebook+.jpg");
//        Frentista f3 = new Frentista(3, "JOINHA", "298374980", "245297", "/imagens/joinha+.jpg");
//
//        relatoriosFrentistasAbastecimentosUIWindow.addFrentista(f1);
//        relatoriosFrentistasAbastecimentosUIWindow.addFrentista(f2);
//        relatoriosFrentistasAbastecimentosUIWindow.addFrentista(f3);
//
//
//        try {
//            Thread.sleep(2000);
//
//            relatoriosFrentistasAbastecimentosUIWindow.atualizarRelatorioDoFrentista(f1);
//            relatoriosFrentistasAbastecimentosUIWindow.atualizarRelatorioDoFrentista(f2);
//            relatoriosFrentistasAbastecimentosUIWindow.atualizarRelatorioDoFrentista(f3);
//
//        } catch (InterruptedException ex) {
//            Logger.getLogger(RelatoriosFrentistasAbastecimentosUIWindow.class.getName()).log(Level.SEVERE, null, ex);
//        }

    }

    @Override
    public void fade() {

        new Thread(() -> {

            for (int i = 100; i > 1; i--) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(RelatoriosFrentistasAbastecimentosUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            setVisible(false);

        }).start();

    }

    @Override
    public void raise() {

        new Thread(() -> {

            setAlwaysOnTop(true);
            setOpacity(0.11f);
            setVisible(true);
            float opacity1 = 1.0f;

            for (int i = 0; i < 95; i++) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(RelatoriosFrentistasAbastecimentosUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            requestFocus();

        }).start();
    }

}
