
package com.undra.view.relatorios;

import com.undra.view.interfaces.FadableAndRaisableUI;
import com.undra.modelo.contabilidade.Abastecimento;
import com.undra.view.controleRemoto.bombaCombustivel.ControleRemotoBombaCombustivelUI;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 * O window para mostrar os abastecimentos de uma bomba
 *
 * @author alexandre
 */
public class RelatorioAbastecimentosDeUmaBombaWindow extends JFrame implements FadableAndRaisableUI{

    private ControleRemotoBombaCombustivelUI controleRemotoBombaCombustivelUI;
     private float totalCombustivelAbastecido = 0.0f;

    private JPanel abastecimentosHeader;
    private JCheckBox onOff;
    private JLabel headerLabel;
    private final Font headerFont = new Font("Ubuntu", Font.BOLD, 14);

    //DATE FORMATING
    String dateFormat = "HH:mm:ss";//"yyyy-MM-dd HH:mm:ss"
    SimpleDateFormat dateFormatter = new SimpleDateFormat(dateFormat);

    private final JLabel cabelhoAbastecimentoLabel = new JLabel();
    private final JScrollPane abastecimentosScrollPane = new JScrollPane();
    private final JList abastecimentosList = new JList();
    private final DefaultListModel abastecimentosListModel = new DefaultListModel();
    private String tituloDaJanela;
    private String cabecalhoBody;
    private String abastecimento;

    private final ImageIcon offIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/off.24x12.png"));

    public RelatorioAbastecimentosDeUmaBombaWindow(ControleRemotoBombaCombustivelUI controleRemotoBombaCombustivelUI) {

        if (controleRemotoBombaCombustivelUI == null) {
            throw new NullPointerException("O controle remoto da bomba não pode ser null");
        }

        this.controleRemotoBombaCombustivelUI = controleRemotoBombaCombustivelUI;

        configureAndShow();
    }

    public final void configureAndShow() {

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }

        });

        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

        setTitle("ABASTECIMENTOS DA " + controleRemotoBombaCombustivelUI.getModelo().toStringShorter());

        getContentPane().setBackground(new Color(255, 255, 192));

        setResizable(false);

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

        setUndecorated(true);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        pack();
        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());
        setVisible(false);

    }

    private void placeComponentsAtFrame() {

        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints;

        gridConstraints = new GridBagConstraints();

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;

        gridConstraints.anchor = GridBagConstraints.NORTH;

        abastecimentosHeader = new JPanel();
        abastecimentosHeader.setPreferredSize(new Dimension(700, 25));
        abastecimentosHeader.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1, true));

        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.NORTH;

        add(abastecimentosHeader, gridConstraints);

        abastecimentosHeader.setLayout(new GridBagLayout());

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.EAST;
        gridConstraints.insets = new Insets(0, 10, 0, 670);

        onOff = new JCheckBox();
        onOff.setToolTipText("CLIQUE PARA FECHAR");

        onOff.setSelected(false);
        onOff.setIcon(offIcon);
        onOff.setPreferredSize(new Dimension(26, 20));

        onOff.addActionListener(this::onOffButtonActionPerformed);

        abastecimentosHeader.add(onOff, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(0, 0, 0, 20);
        if(controleRemotoBombaCombustivelUI.isGNV())gridConstraints.insets = new Insets(0, 0, 0, 55);
        tituloDaJanela = "ABASTECIMENTOS DA " + controleRemotoBombaCombustivelUI.getModelo().toStringShorter() + " - (nenhum, totalizando 0)";
        headerLabel = new JLabel(tituloDaJanela);
        headerLabel.setForeground(Color.BLACK);
        headerLabel.setFont(headerFont);
        abastecimentosHeader.add(headerLabel, gridConstraints);

        cabecalhoBody = "HORÁRIO     LITROS       FRENTISTA                        DURAÇÃO";

        if (controleRemotoBombaCombustivelUI.isGNV()) {
            cabecalhoBody = "HORÁRIO   METROS CÚBLICOS          FRENTISTA              DURAÇÃO";
        }

        cabelhoAbastecimentoLabel.setText(cabecalhoBody);
        cabelhoAbastecimentoLabel.setFont(new Font("Courier New", Font.BOLD, 16));
        cabelhoAbastecimentoLabel.setForeground(Color.BLACK);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(10, 10, 5, 0);
        gridConstraints.anchor = GridBagConstraints.WEST;
        add(cabelhoAbastecimentoLabel, gridConstraints);

        abastecimentosScrollPane.setPreferredSize(new Dimension(700, 500));
        abastecimentosList.setFont(new Font("Courier New", Font.BOLD, 16));
        abastecimentosScrollPane.setViewportView(abastecimentosList);
        abastecimentosList.setModel(abastecimentosListModel);

        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        gridConstraints.gridheight = 3;
        gridConstraints.insets = new Insets(0, 0, 0, 0);
        gridConstraints.anchor = GridBagConstraints.NORTHWEST;

        add(abastecimentosScrollPane, gridConstraints);

    }

    private void onOffButtonActionPerformed(ActionEvent e) {
        
        fade();

//        float opacity = 1.0f;
//        new Thread(() -> {
//            for (int i = 100; i > 1; i--) {
//                setOpacity(i / 100.0f);
//                try {
//                    Thread.sleep(10);
//                } catch (InterruptedException ex) {
////                        Logger.getLogger(ControleRemotoBombaCombustivelUI.class.getName()).log(Level.SEVERE, null, ex);
//                }
//            }
//            
//            setVisible(false);
//            
//        }).start();

    }

    public void addAbastecimento(Abastecimento abastecimento) {

        if (abastecimento.isGNV()) {
            
            this.abastecimento = ajustarParaHeaderGNV(abastecimento);
            
        } else {
            
            this. abastecimento = ajustarParaHeaderNotGNV(abastecimento);
            
        }
        
        //TODO (MAS O SWING NÃO SETA FOREGROUND DOS ELEMENTEOS DA LIST SEPARADAMENTE... É ATOMICO. OU TODOS DE UMA COR OU TODOS DE OUTRA)
        //ajustar cor 
        //vermelha para abastecimentos feitos com bomba em nível critico de combustível
        //preta    para outros abastecimentos
        
//        abastecimentosList.setForeground(Color.BLUE);
//        if(abastecimento.bombaAbasteceuEmNivelCritico() || abastecimento.ficouSemCombustivelEnquantoAbastecia() || abastecimento.bombaDesligadaEnquantoAbastecia() ){
//            abastecimentosList.setForeground(Color.RED);
//        }

             
        String ABASTECIMENTO = new JLabel(this.abastecimento).getText();

        abastecimentosListModel.add(0, ABASTECIMENTO);
        abastecimentosListModel.setElementAt(ABASTECIMENTO, 0);
        
        totalCombustivelAbastecido+=abastecimento.getQuantidade();
        
        String unidadeCombustivel = "L";
        if(abastecimento.isGNV())unidadeCombustivel = "M3";
        
        this.tituloDaJanela = "ABASTECIMENTOS DA " + controleRemotoBombaCombustivelUI.getModelo().toStringShorter() + "   #( " + abastecimentosListModel.getSize() + " abastecimentos, totalizando " + String.format("%.2f", totalCombustivelAbastecido) + " "+ unidadeCombustivel+ " )";
        headerLabel.setText(tituloDaJanela);
        
        

    }

    private String ajustarParaHeaderNotGNV(Abastecimento abastecimento1) {
        
        if (abastecimento1.getQuantidade() >= 0 && abastecimento1.getQuantidade() <= 9.99) {
            //ok
            abastecimento = dateFormatter.format(abastecimento1.getHorarioInicio()) + "     " + String.format("%.2f", abastecimento1.getQuantidade()) + "          " + abastecimento1.getFrentista().getNome() + "                          " + getDuracaoAbastecimento(abastecimento1);
        } else if (abastecimento1.getQuantidade() <= 99.99) {
            //ok
            abastecimento = dateFormatter.format(abastecimento1.getHorarioInicio()) + "     " + String.format("%.2f", abastecimento1.getQuantidade()) + "         " + abastecimento1.getFrentista().getNome() + "                          " + getDuracaoAbastecimento(abastecimento1);
        } else if (abastecimento1.getQuantidade() <= 999.99) {
            abastecimento = dateFormatter.format(abastecimento1.getHorarioInicio()) + "     " + String.format("%.2f", abastecimento1.getQuantidade()) + "        " + abastecimento1.getFrentista().getNome() + "                          " + getDuracaoAbastecimento(abastecimento1);
        } else if (abastecimento1.getQuantidade() <= 9999.99) {
            abastecimento = dateFormatter.format(abastecimento1.getHorarioInicio()) + "     " + String.format("%.2f", abastecimento1.getQuantidade()) + "       " + abastecimento1.getFrentista().getNome() + "                          " + getDuracaoAbastecimento(abastecimento1);
        } else {
            abastecimento = dateFormatter.format(abastecimento1.getHorarioInicio()) + "     " + String.format("%.2f", abastecimento1.getQuantidade()) + "      " + abastecimento1.getFrentista().getNome() + "                          " + getDuracaoAbastecimento(abastecimento1);
        }
        
        return abastecimento;
        
    }

    private String ajustarParaHeaderGNV(Abastecimento abastecimento1) {
        if (abastecimento1.getQuantidade() >= 0 && abastecimento1.getQuantidade() <= 9.99) {
            //ok
            abastecimento = dateFormatter.format(abastecimento1.getHorarioInicio()) + "     " + String.format("%.2f", abastecimento1.getQuantidade()) + "                    " + abastecimento1.getFrentista().getNome() + "                " + getDuracaoAbastecimento(abastecimento1);
        } else if (abastecimento1.getQuantidade() <= 99.99) {
            //ok
            abastecimento = dateFormatter.format(abastecimento1.getHorarioInicio()) + "     " + String.format("%.2f", abastecimento1.getQuantidade()) + "                   " + abastecimento1.getFrentista().getNome() + "                " + getDuracaoAbastecimento(abastecimento1);
        } else if (abastecimento1.getQuantidade() <= 999.99) {
            abastecimento = dateFormatter.format(abastecimento1.getHorarioInicio()) + "     " + String.format("%.2f", abastecimento1.getQuantidade()) + "                  " + abastecimento1.getFrentista().getNome() + "                " + getDuracaoAbastecimento(abastecimento1);
        } else if (abastecimento1.getQuantidade() <= 9999.99) {
            abastecimento = dateFormatter.format(abastecimento1.getHorarioInicio()) + "     " + String.format("%.2f", abastecimento1.getQuantidade()) + "                 " + abastecimento1.getFrentista().getNome() + "                " + getDuracaoAbastecimento(abastecimento1);
        } else {
            abastecimento = dateFormatter.format(abastecimento1.getHorarioInicio()) + "     " + String.format("%.2f", abastecimento1.getQuantidade()) + "                " + abastecimento1.getFrentista().getNome() + "                " + getDuracaoAbastecimento(abastecimento1);
        }
        
        return abastecimento;
    }

    private void exitForm(WindowEvent evt) {
//        System.exit(JFrame.NORMAL);
    }

    private String getDuracaoAbastecimento(Abastecimento abastecimento) {

        long tms = abastecimento.getQuandoFinalizado().getTime() - abastecimento.getHorarioInicio().getTime();

        int h;
        int m;
        int s;
        double t;
        t = tms / 1000.0;
        // Break time down into hours, minutes, and seconds
        h = (int) (t / 3600);
        m = (int) ((t - h * 3600) / 60);
        s = (int) (t - h * 3600 - m * 60);

        // Format time as string
        return new DecimalFormat("00").format(h) + ":" + new DecimalFormat("00").format(m) + ":" + new DecimalFormat("00").format(s);
    }

    @Override
    public void fade() {
        
        new Thread(() -> {

            for (int i = 100; i > 1; i--) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(RelatorioAbastecimentosDeUmaBombaWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            setVisible(false);

        }).start();
    }

    @Override
    public void raise() {
        new Thread(() -> {

            setAlwaysOnTop(true);
            setOpacity(0.11f);
            setVisible(true);
            float opacity1 = 1.0f;

            for (int i = 0; i < 100; i++) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(RelatorioAbastecimentosDeUmaBombaWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            requestFocus();

        }).start();
    }

}
