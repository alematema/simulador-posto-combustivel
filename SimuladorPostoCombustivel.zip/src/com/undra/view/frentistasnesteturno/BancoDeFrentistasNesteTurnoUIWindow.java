/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.frentistasnesteturno;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.modelo.recursoshumanos.Frentista;
import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Arrays;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author alexandre
 */
public class BancoDeFrentistasNesteTurnoUIWindow extends JFrame {

    public static void main(String[] args) {
        new BancoDeFrentistasNesteTurnoUIWindow().configureAndShow();
    }

    public void configureAndShow() {

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }

        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setTitle(getClass().getSimpleName() + " App");

        getContentPane().setBackground(new Color(255, 255, 192));

        setResizable(false);

//        //sets frame's size to 1/4 screen area
//        setSize(new Dimension(Toolkit.getDefaultToolkit().getScreenSize().width / 2, Toolkit.getDefaultToolkit().getScreenSize().height / 2));
//
//        //centralizes the frame
//        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());
        setUndecorated(false);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        pack();

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

        setVisible(true);

    }

    private void placeComponentsAtFrame() {
        
        UIDelegator uIDelegator = new UIDelegator();

        Frentista f1 = new Frentista(1, "JOLIE", "91273490", "329074", "/imagens/jolie+.jpg",uIDelegator);
        Frentista f2 = new Frentista(2, "FACEBOOK", "908345", "92374095", "/imagens/facebook+.jpg",uIDelegator);
        Frentista f3 = new Frentista(3, "JOINHA", "298374980", "245297", "/imagens/joinha+.jpg",uIDelegator);
        Frentista f4 = new Frentista(4, "BONITO", "2349702198347", "7095732495", "/imagens/bonito+.jpg",uIDelegator);
        Frentista f5 = new Frentista(5, "VAMPIRO", "398274987", "9073495", "/imagens/vampiro+.jpg",uIDelegator);
        Frentista f6 = new Frentista(6, "PINTADA", "298374", "2908345", "/imagens/PINTADA+.jpg",uIDelegator);

        Collection<Frentista> frentistas = Arrays.asList(f1, f2, f3, f4, f5, f6);

        BancoDeFrentistasNesteTurnoUI bancoDeFrentistasNesteTurnoUI = new BancoDeFrentistasNesteTurnoUI(frentistas, new UIDelegator());

        getContentPane().add(bancoDeFrentistasNesteTurnoUI);

        new Thread(() -> {

            try {

                
                int sleep = 800;
                
                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.borrowFrentistaDoBancoReserva(f6);

                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.borrowFrentistaDoBancoReserva(f1);

                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.borrowFrentistaDoBancoReserva(f5);

                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.devolverFrentistaAoBancoDeReserva(f5);

                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.devolverFrentistaAoBancoDeReserva(f1);

                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.devolverFrentistaAoBancoDeReserva(f6);
                
                
                
                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.borrowFrentistaDoBancoReserva(f6);

                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.borrowFrentistaDoBancoReserva(f1);

                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.borrowFrentistaDoBancoReserva(f5);

                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.devolverFrentistaAoBancoDeReserva(f5);

                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.devolverFrentistaAoBancoDeReserva(f1);

                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.devolverFrentistaAoBancoDeReserva(f6);
                
                Thread.sleep(sleep);
                

                bancoDeFrentistasNesteTurnoUI.borrowFrentistaDoBancoReserva(f6);

                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.borrowFrentistaDoBancoReserva(f1);

                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.borrowFrentistaDoBancoReserva(f5);

                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.devolverFrentistaAoBancoDeReserva(f5);

                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.devolverFrentistaAoBancoDeReserva(f1);

                Thread.sleep(sleep);

                bancoDeFrentistasNesteTurnoUI.devolverFrentistaAoBancoDeReserva(f6);

            } catch (InterruptedException ex) {
                Logger.getLogger(BancoDeFrentistasNesteTurnoUIWindow.class.getName()).log(Level.SEVERE, null, ex);
            }
        }).start();

    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }

}
