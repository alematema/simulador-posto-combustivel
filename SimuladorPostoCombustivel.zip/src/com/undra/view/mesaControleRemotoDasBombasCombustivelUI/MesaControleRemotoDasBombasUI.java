package com.undra.view.mesaControleRemotoDasBombasCombustivelUI;

import com.undra.delegator.UIDelegator;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.view.controleRemoto.bombaCombustivel.ControleRemotoBombaCombustivelUI;
import com.undra.view.interfaces.UI;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;

/**
 * UI da mesa de controle remoto das bombas
 *
 * @author alexandre
 */
public final class MesaControleRemotoDasBombasUI extends JPanel implements UI{

    private final UIDelegator uIDelegator;

    private List<ControleRemotoBombaCombustivelUI> modeloMesaControleRemoto;

    private List<BombaCombustivel> modeloPistaDasBombas;

    private ControleRemotoBombaCombustivelUI controleBomba0;
    private ControleRemotoBombaCombustivelUI controleBomba1;
    private ControleRemotoBombaCombustivelUI controleBomba2;
    private ControleRemotoBombaCombustivelUI controleBomba3;
    private ControleRemotoBombaCombustivelUI controleBomba4;
    private ControleRemotoBombaCombustivelUI controleBomba5;
    private ControleRemotoBombaCombustivelUI controleBomba6;
    private ControleRemotoBombaCombustivelUI controleBomba7;

    public MesaControleRemotoDasBombasUI(List<BombaCombustivel> modeloPistaDasBombas, UIDelegator uIDelegator) {

        this.uIDelegator = uIDelegator;

        if (modeloPistaDasBombas == null) {
            throw new NullPointerException("O modelo da pista de bombas não pode ser null !!!");
        }

        if (modeloPistaDasBombas.size() != 8) {
            throw new IllegalArgumentException("O modelo da pista de bombas deve ter 8 bombas de combustível !!!");
        }

        this.modeloPistaDasBombas = modeloPistaDasBombas;

        modeloMesaControleRemoto = new ArrayList();

        construirMesaControleRemotoDasBombasCombustivel();
        
        apagarLuz();

    }

    private void construirMesaControleRemotoDasBombasCombustivel() {

        GridBagConstraints gridConstraints;

        setPreferredSize(new Dimension(Toolkit.getDefaultToolkit().getScreenSize().width, Toolkit.getDefaultToolkit().getScreenSize().height - 20));
        setBackground(new Color(192, 192, 255));
        setLayout(new GridBagLayout());
        setBackground(Color.WHITE);

        gridConstraints = new GridBagConstraints();

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(0, 0, 1, 15);

        controleBomba0 = new ControleRemotoBombaCombustivelUI(modeloPistaDasBombas.get(0), uIDelegator);
        add(controleBomba0, gridConstraints);

        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(1, 0, 0, 15);

        controleBomba1 = new ControleRemotoBombaCombustivelUI(modeloPistaDasBombas.get(1), uIDelegator);
        add(controleBomba1, gridConstraints);

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(0, 15, 1, 15);

        controleBomba2 = new ControleRemotoBombaCombustivelUI(modeloPistaDasBombas.get(2), uIDelegator);
        add(controleBomba2, gridConstraints);

        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(1, 15, 0, 15);

        controleBomba3 = new ControleRemotoBombaCombustivelUI(modeloPistaDasBombas.get(3), uIDelegator);
        add(controleBomba3, gridConstraints);

        gridConstraints.gridx = 2;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(0, 15, 1, 15);

        controleBomba4 = new ControleRemotoBombaCombustivelUI(modeloPistaDasBombas.get(4), uIDelegator);
        add(controleBomba4, gridConstraints);

        gridConstraints.gridx = 2;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(1, 15, 0, 15);

        controleBomba5 = new ControleRemotoBombaCombustivelUI(modeloPistaDasBombas.get(5), uIDelegator);
        add(controleBomba5, gridConstraints);

        gridConstraints.gridx = 3;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(0, 15, 1, 15);

        controleBomba6 = new ControleRemotoBombaCombustivelUI(modeloPistaDasBombas.get(6), uIDelegator);
        add(controleBomba6, gridConstraints);

        gridConstraints.gridx = 3;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(1, 15, 0, 15);

        controleBomba7 = new ControleRemotoBombaCombustivelUI(modeloPistaDasBombas.get(7), uIDelegator);
        add(controleBomba7, gridConstraints);

        modeloMesaControleRemoto.add(controleBomba0);
        modeloMesaControleRemoto.add(controleBomba1);
        modeloMesaControleRemoto.add(controleBomba2);
        modeloMesaControleRemoto.add(controleBomba3);
        modeloMesaControleRemoto.add(controleBomba4);
        modeloMesaControleRemoto.add(controleBomba5);
        modeloMesaControleRemoto.add(controleBomba6);
        modeloMesaControleRemoto.add(controleBomba7);
        

    }

    public void acenderLuz() {
        setBackground(Color.WHITE);
        modeloMesaControleRemoto.forEach((controle)->{controle.setBackground(controle.luzAcesaColor);controle.updateStyle();});
    }

    public void apagarLuz() {
        setBackground(Color.DARK_GRAY);
        modeloMesaControleRemoto.forEach((controle)->{controle.setBackground(controle.luzApagadaColor);controle.updateStyle();});
    }

}
