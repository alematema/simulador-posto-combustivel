/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.undra.view.mesaControleRemotoDasBombasCombustivelUI;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.combustivel.bomba.excetion.BombaCombustivelException;
import com.undra.modelo.combustivel.reservatorio.Reservatorio;
import com.undra.modelo.combustivel.reservatorio.exception.NivelCriticoDeCombustivelException;
import com.undra.modelo.combustivel.reservatorio.exception.ReservatorioExeption;
import com.undra.modelo.contabilidade.Caixa;
import com.undra.modelo.recursoshumanos.DepartamentoRecursosHumanos;
import com.undra.view.pistaDasBombas.PistaDasBombasUIWindow;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alexandre
 */
public class Teste {
    
    
    
    public static void main(String[] args) {
        
        List<BombaCombustivel> modeloPistaBombasCombustivel = new ArrayList();
        
        Combustivel gasolina = new Combustivel(Combustivel.GASOLINA, 2.55f, Combustivel.LITRO);
        Combustivel etanol = new Combustivel(Combustivel.ETANOL, 1.99f, Combustivel.LITRO);
        Combustivel diesel = new Combustivel(Combustivel.DIESEL, 3.04f, Combustivel.LITRO);
        Combustivel gnv = new Combustivel(Combustivel.GNV, 1.5f, Combustivel.METRO_CUBICO);

        Reservatorio reservatorio = new Reservatorio(10000f, 100f);

        try {

            reservatorio.abastecer(gasolina, reservatorio.getNIVEL_MAX_TANQUE());
            reservatorio.abastecer(etanol, reservatorio.getNIVEL_MAX_TANQUE());
            reservatorio.abastecer(diesel, reservatorio.getNIVEL_MAX_TANQUE());
            reservatorio.abastecer(gnv, reservatorio.getNIVEL_MAX_TANQUE());

        } catch (NivelCriticoDeCombustivelException ex) {
            Logger.getLogger(PistaDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
        }

        Caixa caixa = new Caixa();
        ModelDelegator businessDelegator = new ModelDelegator(reservatorio, caixa);
        caixa.setDelegator(businessDelegator);
        DepartamentoRecursosHumanos recursosHumanos = new DepartamentoRecursosHumanos();

        BombaCombustivel bombaGasolina;
        try {
            bombaGasolina = new BombaCombustivel(gasolina, 1, businessDelegator);
            modeloPistaBombasCombustivel.add(bombaGasolina);

            BombaCombustivel bombaEtanol = new BombaCombustivel(etanol, 2, businessDelegator);
            modeloPistaBombasCombustivel.add(bombaEtanol);

            BombaCombustivel bombaDiesel = new BombaCombustivel(diesel, 3, businessDelegator);
            modeloPistaBombasCombustivel.add(bombaDiesel);

            BombaCombustivel bombaGasolina2 = new BombaCombustivel(gasolina, 4, businessDelegator);
            modeloPistaBombasCombustivel.add(bombaGasolina2);

            BombaCombustivel bombaEtanol2 = new BombaCombustivel(etanol, 5, businessDelegator);
            modeloPistaBombasCombustivel.add(bombaEtanol2);

            BombaCombustivel bombaDiesel2 = new BombaCombustivel(diesel, 6, businessDelegator);
            modeloPistaBombasCombustivel.add(bombaDiesel2);

            BombaCombustivel bombaGnv = new BombaCombustivel(gnv, 7, businessDelegator);
            modeloPistaBombasCombustivel.add(bombaGnv);

            BombaCombustivel bombaGnv2 = new BombaCombustivel(gnv, 8, businessDelegator);
            modeloPistaBombasCombustivel.add(bombaGnv2);

        } catch (BombaCombustivelException ex) {
            Logger.getLogger(PistaDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
        }

        
        new MesaControleRemotoDasBombasUIWindow(modeloPistaBombasCombustivel, new UIDelegator());
        
    }

}
