/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.mesaControleRemotoDasBombasCombustivelUI;

import com.undra.delegator.UIDelegator;
import com.undra.view.interfaces.FadableAndRaisableUI;
import com.undra.menu.MyMenuBar;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import java.awt.Color;
import java.awt.HeadlessException;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * Window da mesa de controle remoto das bombas.
 *
 * @author alexandre
 */
public final class MesaControleRemotoDasBombasUIWindow extends JFrame implements FadableAndRaisableUI {

    List<BombaCombustivel> modeloPistaBombasCombustivel;
    MesaControleRemotoDasBombasUI mesaControleRemotoDasBombasUI;
    UIDelegator uIDelegator;

    public MesaControleRemotoDasBombasUIWindow(List<BombaCombustivel> modeloPistaBombasCombustivel, UIDelegator uIDelegator) throws HeadlessException {
        this.modeloPistaBombasCombustivel = modeloPistaBombasCombustivel;
        this.uIDelegator = uIDelegator;
//        configureAndShow();
    }

    public void configureAndShow() {

        configure();
        setVisible(true);

    }

    public void configure() {

        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {

            if ("GTK+".equals(info.getName())) {
                try {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                    Logger.getLogger(MesaControleRemotoDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
                break;

            }
        }

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }

        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        getContentPane().setBackground(new Color(255, 255, 192));
        
        setTitle("Controle Remoto Das Bombas - SIMULADOR POSTO COMBUSTÍVEL");

        setResizable(false);

        setUndecorated(true);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {

                try {

                    super.mouseReleased(e);
                    toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());

                    setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());

                } catch (Exception ex) {
                    System.err.println("Algo deu errando em MesaControleRemotoDasBombasUIWindow.mouseReleased");
                }

            }
        });

        placeComponentsAtFrame();

        pack();

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

    }

    private void placeComponentsAtFrame() {

        mesaControleRemotoDasBombasUI = new MesaControleRemotoDasBombasUI(modeloPistaBombasCombustivel, uIDelegator);
        getContentPane().add(mesaControleRemotoDasBombasUI);

    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }

    public MesaControleRemotoDasBombasUI getMesaControleRemotoDasBombasUI() {
        return mesaControleRemotoDasBombasUI;
    }

    @Override
    public void fade() {

        new Thread(() -> {
            for (int i = 100; i > 1; i--) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(MesaControleRemotoDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            setVisible(false);
            transferFocus();

        }).start();

    }

    @Override
    public void raise() {

        new Thread(() -> {

            ((MyMenuBar)getJMenuBar()).setVisibleInvisibleMenus();

            setOpacity(0.11f);
            setVisible(true);
            float opacity1 = 1.0f;
            for (int i = 0; i < 100; i++) {
                setOpacity(i / 100.0f);
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(MesaControleRemotoDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            requestFocus();
        }).start();

    }

    @Override
    public String toString() {
        return "MesaControleRemotoDasBombasUIWindow UI";
    }

}
