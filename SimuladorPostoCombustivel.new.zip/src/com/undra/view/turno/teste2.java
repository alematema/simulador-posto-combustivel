/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.turno;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author alexandre
 */
public class teste2 extends JFrame {

    public static void main(String[] args) {
        new teste2().configureAndShow();
    }

    public void configureAndShow() {

        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
            if ("GTK+".equals(info.getName())) {
                try {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(teste.class.getName()).log(Level.SEVERE, null, ex);
                } catch (InstantiationException ex) {
                    Logger.getLogger(teste.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IllegalAccessException ex) {
                    Logger.getLogger(teste.class.getName()).log(Level.SEVERE, null, ex);
                } catch (UnsupportedLookAndFeelException ex) {
                    Logger.getLogger(teste.class.getName()).log(Level.SEVERE, null, ex);
                }
                break;
            }
        }

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }

        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setTitle(getClass().getSimpleName() + " App");

        getContentPane().setBackground(new Color(255, 255, 192));

        setResizable(false);

        //sets frame's size to 1/4 screen area
        setSize(new Dimension(Toolkit.getDefaultToolkit().getScreenSize().width / 2, Toolkit.getDefaultToolkit().getScreenSize().height / 2));

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

        setUndecorated(false);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        //pack();
        //centralizes the frame
        //setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());
        setVisible(true);

    }

    private void placeComponentsAtFrame() {

        JList<String> myList = new JList();
        
        String[] data = {"one", "two_2_duo_dois", "three", "four"};
        DefaultListModel model = new DefaultListModel();
        myList.setModel(model);
        
        model.addElement(data[0]);
        model.addElement(data[1]);
        model.addElement(data[2]);
        model.addElement(data[3]);

        myList.setCellRenderer(new MyCellRenderer2());

        MouseListener mouseListener = new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                
                if (e.getClickCount() == 1) {
                    
                    int index = myList.locationToIndex(e.getPoint());
                    System.out.println("Single clicked on Item " + index);
                    
                    
                    
                    
                }
                
            }
        };
        myList.addMouseListener(mouseListener);

        getContentPane().add(myList);

        new Thread(new Runnable() {
            @Override
            public void run() {

                try {

                    Thread.sleep(1500);
                    
                    model.set(0, "ubuntu is cool");

                } catch (InterruptedException ex) {
                    Logger.getLogger(teste.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        }).start();

    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }

}

class MyCellRenderer2 extends JLabel implements ListCellRenderer<Object> {

    final ImageIcon selectedIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/selectedbox.png"));
    final ImageIcon unselectedIcon = new javax.swing.ImageIcon(getClass().getResource("/imagens/unselectedbox.png"));
    final JCheckBox checkBox = new JCheckBox();

    public MyCellRenderer2() {
        
        setLayout(new GridBagLayout());
        
        GridBagConstraints bagConstraints = new GridBagConstraints();
        
        bagConstraints.gridx = 1;
        bagConstraints.gridy = 0;
        
        bagConstraints.insets = new Insets(0, 10, 0, 0);
        
        checkBox.addActionListener((ActionEvent e) -> {
            
            System.err.println(" check box clicked ");
            
        });
        
        checkBox.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.err.println(" check box clicked ");
            }
            
            
            
});
        
        add(checkBox,bagConstraints);
        
        
    }

    
    
    // This is the only method defined by ListCellRenderer.
    // We just reconfigure the JLabel each time we're called.
    @Override
    public Component getListCellRendererComponent(
            JList<?> list, // the list
            Object value, // value to display
            int index, // cell index
            boolean isSelected, // is the cell selected
            boolean cellHasFocus) // does the cell have focus
    {
        String s = value.toString();
        setText(s);
        setIcon((s.contains(", no turno")) ? selectedIcon : unselectedIcon);
        
        if (isSelected) {
            
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
            
        } else {
            
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }
        
        
        
        
        
        setEnabled(list.isEnabled());
        setFont(list.getFont());
        setOpaque(true);
        return this;
    }
}

