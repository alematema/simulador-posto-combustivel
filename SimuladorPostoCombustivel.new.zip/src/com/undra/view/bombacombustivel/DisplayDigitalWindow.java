/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.bombacombustivel;

import java.awt.Color;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author alexandre
 */
public class DisplayDigitalWindow extends JFrame {

    private DisplayDigital displayDigital;
    private int sleep = 500;

    public DisplayDigitalWindow(int sleep) {
        if (sleep >= 0) {
            this.sleep = sleep;
        }
    }

    public void configureAndShow() throws DisplayDigitalException {

        addWindowListener(new WindowAdapterImpl());

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setTitle(getClass().getSimpleName() + " App");

        getContentPane().setBackground(new Color(255, 255, 192));

        setResizable(false);

        setUndecorated(true);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        pack();

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

        setVisible(true);

        new Thread(() -> {

            //testa setting de todos os valores possiveis q o display pode assumir
            for (int i = 0; i <= 99999; i++) {

                if (i % 100 < 10) {

                    displayDigital.setValor(Float.parseFloat(i / 100 + ".0" + i % 100));

                } else {

                    displayDigital.setValor(Float.parseFloat(i / 100 + "." + i % 100));

                }

                System.out.println(displayDigital.getValor());

                try {

                    Thread.sleep(sleep);

                } catch (InterruptedException ex) {
                    Logger.getLogger(DisplayDigitalWindow.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        }).start();

    }

    private void placeComponentsAtFrame() throws DisplayDigitalException {

        displayDigital = new DisplayDigital();

        getContentPane().add(displayDigital);

        displayDigital.setValor(9.99f);

    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }

    private class WindowAdapterImpl extends WindowAdapter {

        public WindowAdapterImpl() {
        }

        public void windowClosing(WindowEvent evt) {
            exitForm(evt);
        }
    }

    public static void main(String[] args) throws DisplayDigitalException {

        int sleep = -1;

        try {
            sleep = Integer.parseInt(args[0]);
        } catch (Exception e) {
        }

        new DisplayDigitalWindow(sleep).configureAndShow();
    }

}
