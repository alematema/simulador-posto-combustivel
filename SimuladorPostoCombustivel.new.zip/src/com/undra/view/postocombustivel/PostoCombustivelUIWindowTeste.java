/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.postocombustivel;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.modelo.combustivel.bomba.excetion.BombaCombustivelException;
import com.undra.modelo.combustivel.reservatorio.Reservatorio;
import com.undra.modelo.combustivel.reservatorio.exception.ReservatorioExeption;
import com.undra.modelo.contabilidade.exception.CaixaException;
import com.undra.modelo.postocombustivel.PostoCombustivel;
import com.undra.modelo.postocombustivel.PostoGasolinaException;
import com.undra.view.splash.SplashWindowUI;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alexandre
 */
public class PostoCombustivelUIWindowTeste {

    public static void main(String[] args) {

        new Thread(() -> {

            try {//100f,50f

                SplashWindowUI splash = new SplashWindowUI();

                ModelDelegator modelDelegator = new ModelDelegator();
                UIDelegator uIDelegator = new UIDelegator();

                uIDelegator.registrarUI(splash);
                splash.setVisible(true);
//                Thread.sleep(1000);

                PostoCombustivelUIWindow postoCombustivelUIWindow = new PostoCombustivelUIWindow(new PostoCombustivel(new Reservatorio(10000f, 100f, modelDelegator, uIDelegator)));

                postoCombustivelUIWindow.configure();
                Thread.sleep(500);
                uIDelegator.atualizarSplash("INICIANDO");
                Thread.sleep(500);
                uIDelegator.atualizarSplash("INICIANDO.");
                Thread.sleep(500);
                uIDelegator.atualizarSplash("INICIANDO..");
                Thread.sleep(500);
                uIDelegator.atualizarSplash("INICIANDO...");
                Thread.sleep(700);
                uIDelegator.atualizarSplash("LANÇANDO");
                Thread.sleep(500);
                uIDelegator.atualizarSplash("LANÇANDO.");
                Thread.sleep(500);
                uIDelegator.atualizarSplash("LANÇANDO..");
                Thread.sleep(500);
                uIDelegator.atualizarSplash("LANÇANDO...");
                uIDelegator.atualizarSplash("LANÇANDO...");
                uIDelegator.atualizarSplash("LANÇANDO...");
                uIDelegator.atualizarSplash("LANÇANDO...");
                uIDelegator.atualizarSplash("LANÇANDO...");

                uIDelegator.atualizarSplash("LANÇANDO...");

                Thread.sleep(800);
                splash.setVisible(false);
                postoCombustivelUIWindow.raise();

            } catch (PostoGasolinaException | ReservatorioExeption | CaixaException | BombaCombustivelException ex) {
                Logger.getLogger(PostoCombustivelUIWindowTeste.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InterruptedException ex) {
                Logger.getLogger(PostoCombustivelUIWindowTeste.class.getName()).log(Level.SEVERE, null, ex);
            }
        }).start();

    }

}
