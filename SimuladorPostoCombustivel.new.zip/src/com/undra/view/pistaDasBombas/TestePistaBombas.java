/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.undra.view.pistaDasBombas;

import com.undra.delegator.ModelDelegator;
import com.undra.delegator.UIDelegator;
import com.undra.modelo.combustivel.Combustivel;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.combustivel.bomba.excetion.BombaCombustivelException;
import com.undra.modelo.combustivel.reservatorio.Reservatorio;
import com.undra.modelo.combustivel.reservatorio.exception.NivelCriticoDeCombustivelException;
import com.undra.modelo.combustivel.reservatorio.exception.ReservatorioExeption;
import com.undra.modelo.contabilidade.Caixa;
import com.undra.modelo.recursoshumanos.Frentista;
import com.undra.modelo.recursoshumanos.DepartamentoRecursosHumanos;
import com.undra.view.bombacombustivel.BombaCombustivelUI;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JMenu;
import javax.swing.JMenuBar;

/**
 *
 * @author alexandre
 */
public class TestePistaBombas {

    public static void main(String[] args) {

        List<BombaCombustivel> modeloPistaBombasCombustivel = new ArrayList();
        PistaDasBombasUI pistaDasBombasUI;

        UIDelegator uIDelegator;

        Combustivel gasolina = new Combustivel(Combustivel.GASOLINA, 2.55f, Combustivel.LITRO);
        Combustivel etanol = new Combustivel(Combustivel.ETANOL, 1.99f, Combustivel.LITRO);
        Combustivel diesel = new Combustivel(Combustivel.DIESEL, 3.04f, Combustivel.LITRO);
        Combustivel gnv = new Combustivel(Combustivel.GNV, 1.5f, Combustivel.METRO_CUBICO);

        Reservatorio reservatorio = new Reservatorio(10000f, 100f);

        try {

            reservatorio.abastecer(gasolina, reservatorio.getNIVEL_MAX_TANQUE());
            reservatorio.abastecer(etanol, reservatorio.getNIVEL_MAX_TANQUE());
            reservatorio.abastecer(diesel, reservatorio.getNIVEL_MAX_TANQUE());
            reservatorio.abastecer(gnv, reservatorio.getNIVEL_MAX_TANQUE());

        } catch (NivelCriticoDeCombustivelException ex) {
            Logger.getLogger(PistaDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
        }

        Caixa caixa = new Caixa();
        ModelDelegator businessDelegator = new ModelDelegator(reservatorio, caixa);
        caixa.setDelegator(businessDelegator);
        List<Caixa> modelo = new ArrayList();
        modelo.add(caixa);
        DepartamentoRecursosHumanos recursosHumanos = new DepartamentoRecursosHumanos();

        BombaCombustivel bombaGasolina;
        try {
            bombaGasolina = new BombaCombustivel(gasolina, 1, businessDelegator);
            modeloPistaBombasCombustivel.add(bombaGasolina);

            BombaCombustivel bombaEtanol = new BombaCombustivel(etanol, 2, businessDelegator);
            modeloPistaBombasCombustivel.add(bombaEtanol);

            BombaCombustivel bombaDiesel = new BombaCombustivel(diesel, 3, businessDelegator);
            modeloPistaBombasCombustivel.add(bombaDiesel);

            BombaCombustivel bombaGasolina2 = new BombaCombustivel(gasolina, 4, businessDelegator);
            modeloPistaBombasCombustivel.add(bombaGasolina2);

            BombaCombustivel bombaEtanol2 = new BombaCombustivel(etanol, 5, businessDelegator);
            modeloPistaBombasCombustivel.add(bombaEtanol2);

            BombaCombustivel bombaDiesel2 = new BombaCombustivel(diesel, 6, businessDelegator);
            modeloPistaBombasCombustivel.add(bombaDiesel2);

            BombaCombustivel bombaGnv = new BombaCombustivel(gnv, 7, businessDelegator);
            modeloPistaBombasCombustivel.add(bombaGnv);

            BombaCombustivel bombaGnv2 = new BombaCombustivel(gnv, 8, businessDelegator);
            modeloPistaBombasCombustivel.add(bombaGnv2);

        } catch (BombaCombustivelException ex) {
            Logger.getLogger(PistaDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
        }

        PistaDasBombasUIWindow window = new PistaDasBombasUIWindow(modeloPistaBombasCombustivel, modelo, new UIDelegator());
        window.configureAndShow();
        
        pistaDasBombasUI = window.getPistaDasBombasUI();
        
        //algumas quantidades de combustivel
        float[] quantidades = {10.63f, 80f, 75f, 70f, 40f, 55f, 75f, 20.78f, 78f, 60f, 20f, 7.89f, 5.21f, 89f, 32.43f, 67f, 10.5f, 21.67f, 45.67f, 11.67f, 12.5f, 13.5f};

        //os cumbustiveis deste posto de gasolina
        Combustivel[] combustiveis = {
            new Combustivel(Combustivel.GASOLINA, 2.99f, Combustivel.LITRO),
            new Combustivel(Combustivel.ETANOL, 1.99f, Combustivel.LITRO),
            new Combustivel(Combustivel.DIESEL, 3.69f, Combustivel.LITRO),
            new Combustivel(Combustivel.GNV, 1.69f, Combustivel.METRO_CUBICO)

        };

        SecureRandom myRandom = new SecureRandom();

        pistaDasBombasUI.getBombasCombustivelUI().stream().map((bombaView) -> {
            bombaView.getOnOff().doClick();
            return bombaView;
        }).forEachOrdered((_item) -> {
            try {
                Thread.sleep(589);
            } catch (InterruptedException ex) {
                Logger.getLogger(PistaDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        JMenuBar mainMenuBar = new JMenuBar();
        JMenu iniciarMenu = new JMenu("Iniciar");
//        setJMenuBar(mainMenuBar);
        mainMenuBar.add(iniciarMenu);

        //Simula uma solicitação de abastecimento a cada alguns segundos
        //Tando o combustivel quando o valor quanto o frentista a realizar o abastecimento sao aleatoriamente escolhidos
        int i = 0;
        while (true) {

            Combustivel combustivel = combustiveis[myRandom.nextInt(4)];
            float quantidadeCombustivel = quantidades[myRandom.nextInt(quantidades.length)];

            Frentista frentista = (Frentista) pistaDasBombasUI.getFrentistaLivre();
            BombaCombustivelUI bomba = pistaDasBombasUI.getBombaCombustivelUILivre(combustivel);

            if (frentista != null && bomba != null) {

                frentista.abasteceComABomba(bomba.getModelo()).aQuantidade(quantidadeCombustivel);

                while (bomba.getModelo().isLiberada()) {
                }

                try {
                    Thread.sleep(1800);
                } catch (InterruptedException ex) {
                    Logger.getLogger(PistaDasBombasUIWindow.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

            i++;

        }
    }

}
