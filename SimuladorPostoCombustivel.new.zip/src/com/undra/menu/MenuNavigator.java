package com.undra.menu;

import com.undra.delegator.UIDelegator;
import com.undra.view.interfaces.FadableAndRaisableUI;
import java.util.ArrayList;
import java.util.List;

/**
 * Navigator do menu.
 *
 * @author alexandre
 */
public class MenuNavigator {

    private static final List<FadableAndRaisableUI> UIS= new ArrayList();
    public static final List<MyMenuBar> MY_MENu_BAR_LIST= new ArrayList();
    
    static private UIDelegator uIDelegator;

    static private FadableAndRaisableUI from;
    static private FadableAndRaisableUI to;
    static private FadableAndRaisableUI lastFrom;
    static private FadableAndRaisableUI lastTo;

    
    
    
    static public void registerUI(FadableAndRaisableUI ui) {

        if (UIS.contains(ui)) {
            System.err.println("[MENU NAVIGATOR] : NOT REGISTERED UI " + ui);
        } else {
            UIS.add(ui);
            System.out.println("[MENU NAVIGATOR] : REGISTERED UI " + ui);
            uIDelegator.atualizarSplash("[MENU NAVIGATOR] : REGISTERED UI " + ui);
        }

    }
    static public void registerMYMENUBAR(MyMenuBar myMenuBar) {

        if (MY_MENu_BAR_LIST.contains(myMenuBar)) {
            System.err.println("[MENU NAVIGATOR] : NOT REGISTERED MY MENU BAR " + myMenuBar);
        } else {
            MY_MENu_BAR_LIST.add(myMenuBar);
            System.out.println("[MENU NAVIGATOR] : REGISTERED MY MENU BAR " + myMenuBar);
            uIDelegator.atualizarSplash("[MENU NAVIGATOR] : REGISTERED MY MENU BAR " + myMenuBar);
        }

    }

    
    static public FadableAndRaisableUI getUI(String ui) {

        FadableAndRaisableUI fadableAndRaisableUI = null;

        try {

            for (FadableAndRaisableUI UI : UIS) {
                if (UI.getClass().getSimpleName().equals(ui)) {
                    fadableAndRaisableUI = UI;
                    break;
                }
            }

        } catch (Exception e) {
            System.err.println("[MENU NAVIGATOR] : something went wrong getting " + ui + " : " + e.getLocalizedMessage());
        }

        return fadableAndRaisableUI;

    }

    static public void setFrom(String ui) {
        setFrom(getUI(ui));
    }

    static public void setTo(String ui) {
        setTo(getUI(ui));
    }
    static public void setFrom(FadableAndRaisableUI  ui) {
        from = ui;
    }

    static public void setTo(FadableAndRaisableUI ui) {
        to = ui;
    }

    static public void hide(String ui){
        FadableAndRaisableUI toHide = getUI(ui);
        toHide.fade();
    }
    
    static public void show(String ui){
        FadableAndRaisableUI toShow = getUI(ui);
        toShow.raise();
    }

    public static FadableAndRaisableUI getLastFrom() {
        return lastFrom;
    }

    public static FadableAndRaisableUI getLastTo() {
        return lastTo;
    }
    
    /**
         from = anchieta
         to  = sao pedro
         navigate
         from = sao pedro
         last from = anchieta
         last to = sao pedro
     */
    
    static public void navigate() {

        try {
            
            if(to.equals(from)){
                return;
            }
            
            from.fade();
            
            Thread.sleep(50);
            
            to.raise();
            
            lastFrom = from;
            lastTo = to;
            
            setFrom(to);
            
        } catch (Exception e) {
            System.err.println("[MENU NAVIGATOR] : something went wrong navigating from " + from + " to " + to + " : "+e.getLocalizedMessage());
        }

    }

    public static void setUiDelegator(UIDelegator uIDelegator) {
       MenuNavigator.uIDelegator = uIDelegator;
    }

}
