/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.undra.modelo.combustivel.reservatorio.exception;

/**
 *
 * @author alexandre
 */
public class SemCombustivelException extends Exception {
    
    public float quantidadeSolicitada;
    public float quantidadeNoTanque;

    public SemCombustivelException(String msg) {
        super(msg);
    }

}
