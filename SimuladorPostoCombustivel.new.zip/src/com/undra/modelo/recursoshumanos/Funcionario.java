
package com.undra.modelo.recursoshumanos;

import com.undra.delegator.UIDelegator;
import java.util.Date;
import java.util.Objects;

/**
 * Classe modela um funcionário
 *
 * @author alexandre
 */
public class Funcionario {

    private Integer id;
    private String nome;
    private String rg;
    private String cpf;
    private TipoFuncioinario tipo;
    private String caminhoPraFoto;

    private Date dataAdmissao;
    private Date dataDemissao;
    private String motivoDemissao;

    private String observacoes;

    private float salario;
    private float bonificacao;
    
    private UIDelegator uIDelegator;

    static public String PRONTO = "PRONTO";
    static public String EM_ESPERA = "EM_ESPERA";
    private volatile String estado; // volatile forces memory barrier crossing
    
    private volatile boolean demitido = false; // volatile forces memory barrier crossing

    public Funcionario(Integer id, String nome, String rg, String cpf, TipoFuncioinario tipo) {
        this.id = id;
        this.nome = nome;
        this.rg = rg;
        this.cpf = cpf;
        this.tipo = tipo;
        estado = PRONTO;
    }
    
    public Funcionario(Integer id, String nome, String rg, String cpf, TipoFuncioinario tipo, String caminhoPraFoto, UIDelegator uIDelegator) {
        this(id, nome, rg, cpf, tipo);
        if(uIDelegator==null) throw new NullPointerException("O UIDelegator não pode ser null");
        this.uIDelegator = uIDelegator;
        this.caminhoPraFoto = caminhoPraFoto;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public TipoFuncioinario getTipo() {
        return tipo;
    }

    public void setTipo(TipoFuncioinario tipo) {
        this.tipo = tipo;
    }

    public Date getDataAdmissao() {
        return dataAdmissao;
    }

    public void setDataAdmissao(Date dataAdmissao) {
        this.dataAdmissao = dataAdmissao;
    }

    public Date getDataDemissao() {
        return dataDemissao;
    }

    public void setDataDemissao(Date dataDemissao) {
        this.dataDemissao = dataDemissao;
    }

    public String getMotivoDemissao() {
        return motivoDemissao;
    }

    public void setMotivoDemissao(String motivoDemissao) {
        this.motivoDemissao = motivoDemissao;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public float getBonificacao() {
        return bonificacao;
    }

    public void setBonificacao(float bonificacao) {
        this.bonificacao = bonificacao;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCaminhoPraFoto() {
        return caminhoPraFoto;
    }

    public void setCaminhoPraFoto(String caminhoPraFoto) {
        this.caminhoPraFoto = caminhoPraFoto;
    }

    public boolean isDemitido() {
        return demitido;
    }

    public void setDemitido(boolean isDemitido) {
        this.demitido = isDemitido;
    }

    public UIDelegator getuIDelegator() {
        return uIDelegator;
    }

    public void setuIDelegator(UIDelegator uIDelegator) {
        if(uIDelegator==null) throw new NullPointerException("O UIDelegator não pode ser null");
        this.uIDelegator = uIDelegator;
    }
    
    
    public boolean isOcupado(){
        return estado.equals(EM_ESPERA);
    }
    
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.id);
        hash = 67 * hash + Objects.hashCode(this.nome);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {

        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }

        final Funcionario other = (Funcionario) obj;

        if (this.id != null && other.id != null) {// só compara se ids nao nulos.Eles podem ser nulos no caso do Banco de dados ser o responsãvel por gerar o id dpois d

            if (Objects.equals(this.nome, other.nome) && Objects.equals(this.rg, other.rg)&&Objects.equals(this.cpf, other.cpf)&&this.tipo == other.tipo) {
                return true;
            }
            return false;

        } else {

            if (!Objects.equals(this.nome, other.nome)) {
                return false;
            }
            if (!Objects.equals(this.rg, other.rg)) {
                return false;
            }
            if (!Objects.equals(this.cpf, other.cpf)) {
                return false;
            }

            return this.tipo == other.tipo;
        }

    }
    
    public Boolean isFrentista(){
        return getTipo()==TipoFuncioinario.FRENTISTA;
    }

    public Boolean estaLiberado(){
        return getEstado().equals(PRONTO);
    }
    
    @Override
    public String toString() {
        return "Funcionario{" + "id=" + id + ", nome=" + nome + ", rg=" + rg + ", cpf=" + cpf + ", tipo=" + tipo + ", dataAdmissao=" + dataAdmissao + ", dataDemissao=" + dataDemissao + ", motivoDemissao=" + motivoDemissao + ", observacoes=" + observacoes + ", salario=" + salario + ", bonificacao=" + bonificacao + ", estado=" + estado + '}';
    }

    public String toStringShort() {
        return getTipo() + ", " + getNome();
    }

}
