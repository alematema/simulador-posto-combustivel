
package com.undra.modelo.recursoshumanos;

import com.undra.delegator.UIDelegator;
import com.undra.modelo.combustivel.bomba.BombaCombustivel;
import com.undra.modelo.combustivel.bomba.excetion.BombaCombustivelException;
import com.undra.modelo.contabilidade.Abastecimento;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Classe que particulariza um funcionario<br>
 * Dá fluencia e semântica às invocações de frentista.
 *
 * @author alexandre
 */
public class Frentista extends Funcionario {

    private BombaCombustivel bombaCombustivel;
    private float quantidadeCombustivel;
    private float quantoAbasteceuDeGNV;
    private int quantosAbatecimentosGNV;
    private int quantosAbatecimentosEtanol;
    private int quantosAbatecimentosGasolina;
    private int quantosAbatecimentosDiesel;
    private float quantoAbasteceuDeEtanol;
    private float quantoAbasteceuDeGasolina;
    private float quantoAbasteceuDeDiesel;
    private float totalQuantoAbasteceu;
    private float totalValorGeradoAbastecendo;
    private long totalTempoAbastecendo;

    private final Collection<Abastecimento> abastecimentos;

    public Frentista(Integer id, String nome, String rg, String cpf) {
        super(id, nome, rg, cpf, TipoFuncioinario.FRENTISTA);
        this.abastecimentos = new ArrayList();
    }

    public Frentista(Integer id, String nome, String rg, String cpf, String caminhoPraFoto, UIDelegator uIDelegator) {
        super(id, nome, rg, cpf, TipoFuncioinario.FRENTISTA);
        this.abastecimentos = new ArrayList();
        super.setCaminhoPraFoto(caminhoPraFoto);
        super.setuIDelegator(uIDelegator);
    }

    public void alocar() {
        setEstado(EM_ESPERA);
    }
    
    public Frentista abasteceComABomba(BombaCombustivel bombaCombustivel) {

        if (bombaCombustivel == null) {
            throw new NullPointerException("A bomba de combustível não pode ser null!!!");
        }
        this.bombaCombustivel = bombaCombustivel;
        return this;

    }

    public void aQuantidade(float quantidadeCombustivel) {

        if (quantidadeCombustivel <= 0) {
            throw new IllegalArgumentException("A quantidade a ser abastecida deve ser maior ou igual do que zero !!!");
        }

        Thread worker;

        worker = new Thread(() -> {
            try {
                bombaCombustivel.abastecer(this, quantidadeCombustivel);
            } catch (BombaCombustivelException ex) {
                Logger.getLogger(Frentista.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        worker.start();

    }

    public void oValor(float valorAbastecimento) throws BombaCombustivelException {

        if (valorAbastecimento <= 0) {
            throw new IllegalArgumentException("O valor a ser abastecido deve ser maior ou igual do que zero !!!");
        }

        quantidadeCombustivel = valorAbastecimento / bombaCombustivel.getCombustivel().getPrecoDaUnidade();

        Thread worker;

        worker = new Thread(() -> {
            try {
                bombaCombustivel.abastecer(this, quantidadeCombustivel);
            } catch (BombaCombustivelException ex) {
                Logger.getLogger(Frentista.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        worker.start();

    }

    public synchronized void addAbastecimento(Abastecimento abastecimento) {

        if (abastecimento == null) {
            throw new NullPointerException("O abastecimento não pode ser null !!!");
        }

        abastecimentos.add(abastecimento);
        
        if (abastecimento.isGNV()) {
            quantoAbasteceuDeGNV += abastecimento.getQuantidade();
            quantosAbatecimentosGNV++;
        }
        if (abastecimento.isEtanol()) {
            quantoAbasteceuDeEtanol += abastecimento.getQuantidade();
            quantosAbatecimentosEtanol++;
        }
        if (abastecimento.isGasolina()) {
            quantoAbasteceuDeGasolina += abastecimento.getQuantidade();
            quantosAbatecimentosGasolina++;
        }
        if (abastecimento.isDiesel()) {
            quantoAbasteceuDeDiesel += abastecimento.getQuantidade();
            quantosAbatecimentosDiesel++;
        }
        
        totalQuantoAbasteceu+=abastecimento.getQuantidade();
        totalValorGeradoAbastecendo+=abastecimento.getValorAbastecimento();
        
        long fim = abastecimento.getQuandoFinalizado().getTime();
        long inicio = abastecimento.getHorarioInicio().getTime();
        long duracaoDesteAbastecimento = fim-inicio;
        
        totalTempoAbastecendo+=duracaoDesteAbastecimento;
        
        //MUDOU ESTADO -> ATUALIZA VIEW
        getuIDelegator().atualizarFrentistaNoRelatoriosFrentistasAbastecimentosWindow(this);
        
    }

    public float getQuantoAbasteceuDeGNV() {
        return quantoAbasteceuDeGNV;
    }

    public float getQuantoAbasteceuDeEtanol() {
        return quantoAbasteceuDeEtanol;
    }

    public float getQuantoAbasteceuDeGasolina() {
        return quantoAbasteceuDeGasolina;
    }

    public float getQuantoAbasteceuDeDiesel() {
        return quantoAbasteceuDeDiesel;
    }

    public float getTotalQuantoAbasteceu() {
        return totalQuantoAbasteceu;
    }

    public float getTotalValorGeradoAbastecendo() {
        return totalValorGeradoAbastecendo;
    }

    public long getTotalTempoAbastecendo() {
        return totalTempoAbastecendo;
    }

    public Collection<Abastecimento> getAbastecimentos() {
        return abastecimentos;
    }

    public int getQuantosAbatecimentosGNV() {
        return quantosAbatecimentosGNV;
    }

    public int getQuantosAbatecimentosEtanol() {
        return quantosAbatecimentosEtanol;
    }

    public int getQuantosAbatecimentosGasolina() {
        return quantosAbatecimentosGasolina;
    }

    public int getQuantosAbatecimentosDiesel() {
        return quantosAbatecimentosDiesel;
    }

    @Override
    public String toString() {
        return getNome() + " " + getId() + ",FEZ "+abastecimentos.size()+" ABASTECIMENTOS, DISTRIBUIDOS ASSIM:"+"\n\tGNV "+getQuantoAbasteceuDeGNV() +" m3, "+getQuantosAbatecimentosGNV()+" abastecimentos"+ "\n\tETANOL " + getQuantoAbasteceuDeEtanol()+" LITROS, "+getQuantosAbatecimentosEtanol()+" abastecimentos"+"\n\tGASOLINA "+getQuantoAbasteceuDeGasolina()+" LITROS, "+getQuantosAbatecimentosGasolina()+" abastecimentos"+"\n\tDIESEL "+getQuantoAbasteceuDeDiesel()+" LITROS, "+getQuantosAbatecimentosDiesel()+" abastecimentos"+"\n\tTOTAL QUANTO ABASTECEU "+getTotalQuantoAbasteceu()+"\n\tTOTAL TEMPO ABASTECENDO "+getTotalTempoAbastecendo();
    }

    
    
    
    
}
